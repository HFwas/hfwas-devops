-- Demo Application Initialization SQL
-- This script is executed by the demo-init Job before the app starts.
--
-- The actual execution is simulated by the demo-init container;
-- in production this would run against a real database via psql.

-- Create the items table for demo
CREATE TABLE IF NOT EXISTS demo_items (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(32) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create an index for faster lookups
CREATE INDEX IF NOT EXISTS idx_demo_items_status ON demo_items (status);

-- Seed initial data
INSERT INTO demo_items (name, description, status)
VALUES
    ('交付运维平台', '演示应用的初始数据记录', 'active'),
    ('服务部署演示', '通过 delivery-platform 部署的服务', 'active'),
    ('SQL 初始化演示', 'init job 自动执行的数据库初始化', 'active')
ON CONFLICT DO NOTHING;