-- =============================================================================
-- Cornerstone SSO 用户种子数据
-- 已废弃: sso_user 及相关映射表已由 Keycloak 替代
-- 用户初始化现在由 keycloak-init 脚本完成
-- =============================================================================

\connect beebot_platform

-- (no-op: all legacy sso_user / cs_*_mapping seed data removed)
