-- =============================================================================
-- 增量迁移脚本（仅新增表/索引，不删除已有对象）
-- 每次新增表结构时，在此文件追加 CREATE TABLE IF NOT EXISTS
-- =============================================================================

\connect agentscope;

-- model.type_spec（Infrastructure v2 定制迁移）
ALTER TABLE model ADD COLUMN IF NOT EXISTS type_spec VARCHAR(100) DEFAULT NULL;
COMMENT ON COLUMN model.type_spec IS 'model type spec: llm, mllm';

-- ---------------------------------------------------------------------------
-- skill (v2.1.0)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS skill (
    id              BIGSERIAL       NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    name            VARCHAR(128)    NOT NULL,
    display_name    VARCHAR(256)    DEFAULT NULL,
    description     TEXT            DEFAULT NULL,
    skill_type      SMALLINT        NOT NULL DEFAULT 1,
    source          VARCHAR(32)     NOT NULL DEFAULT 'tenant',
    author          VARCHAR(128)    DEFAULT NULL,
    file_count      INTEGER         NOT NULL DEFAULT 0,
    status          SMALLINT        NOT NULL DEFAULT 1,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     DEFAULT NULL,
    modifier        VARCHAR(64)     DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_skill_id UNIQUE (skill_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_skill_tenant_name ON skill (tenant_id, name) WHERE status = 1;
CREATE INDEX IF NOT EXISTS idx_skill_tenant ON skill (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_skill_source ON skill (source, status);

-- ---------------------------------------------------------------------------
-- skill_file (v2.1.0)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS skill_file (
    id              BIGSERIAL       NOT NULL,
    file_id         VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    directory       VARCHAR(32)     NOT NULL,
    file_name       VARCHAR(256)    NOT NULL,
    file_path       VARCHAR(512)    NOT NULL,
    file_content    TEXT            DEFAULT NULL,
    file_data       BYTEA           DEFAULT NULL,
    is_text         BOOLEAN         NOT NULL DEFAULT TRUE,
    file_size       BIGINT          NOT NULL DEFAULT 0,
    content_type    VARCHAR(128)    DEFAULT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT uk_skill_file_id UNIQUE (file_id)
);
CREATE INDEX IF NOT EXISTS idx_skill_file_tenant ON skill_file (tenant_id, status);

-- ---------------------------------------------------------------------------
-- skill_file_relation (v2.1.0)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS skill_file_relation (
    id              BIGSERIAL       NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    file_id         VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT uk_sfr_skill_file UNIQUE (skill_id, file_id)
);
CREATE INDEX IF NOT EXISTS idx_sfr_skill ON skill_file_relation (skill_id);
CREATE INDEX IF NOT EXISTS idx_sfr_file ON skill_file_relation (file_id);
CREATE INDEX IF NOT EXISTS idx_sfr_tenant ON skill_file_relation (tenant_id);

-- ---------------------------------------------------------------------------
-- skill_aibaas_relation (v2.1.0)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS skill_aibaas_relation (
    id              BIGSERIAL       NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    skill_run_id    VARCHAR(128)    NOT NULL,
    revision_id     VARCHAR(128)    NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS idx_shr_skill ON skill_aibaas_relation (skill_id);
CREATE INDEX IF NOT EXISTS idx_shr_tenant ON skill_aibaas_relation (tenant_id);

-- ---------------------------------------------------------------------------
-- 技能广场预置数据 (v2.2.0 — 11 enterprise skills, replaces old 5 skills)
-- ---------------------------------------------------------------------------

-- skill 表种子数据
INSERT INTO skill (skill_id, tenant_id, name, display_name, description, skill_type, source, author, file_count, status, creator, modifier)
VALUES
  ('1000000000000001', '__platform__', 'brainstorming',            '头脑风暴',       '用于创意或建设性工作开始前（功能设计、架构规划、行为分析），通过结构化对话将模糊想法转化为经过验证的方案设计。',                            2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000002', '__platform__', 'copywriting',              '文案撰写',       '撰写严谨、以转化为导向的营销文案，适用于落地页和邮件场景，强制要求简要确认并严格禁止虚假内容。',                                            2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000003', '__platform__', 'customer-support',         '客户支持',       '精英级 AI 驱动的客户支持专家，精通对话式 AI、自动化工单、情感分析及全渠道客户服务体验。',                                                    2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000004', '__platform__', 'data-storytelling',        '数据叙事',       '将原始数据转化为引人入胜的叙事，驱动决策制定并激发行动。',                                                                                        2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000005', '__platform__', 'email-sequence',           '邮件序列设计',   '专注于邮件营销与自动化，设计能够培育客户关系、推动行动并引导转化的邮件序列。',                                                                  2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000006', '__platform__', 'hr-pro',                   '人力资源专家',   '专业、合规的 HR 伙伴，覆盖招聘、入职/离职、假期管理、绩效考核、合规政策及员工关系等全场景。',                                                  2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000007', '__platform__', 'interview-coach',          '面试教练',       '完整求职辅导系统，涵盖 JD 解析、简历优化、故事库构建、模拟面试、录音分析、薪资谈判，共 23 个指令，支持持久状态记忆。',                          2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000008', '__platform__', 'legal-advisor',            '法律顾问',       '起草隐私政策、服务条款、免责声明及法律通知，生成符合 GDPR 的文本、Cookie 政策及数据处理协议。',                                              2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000009', '__platform__', 'product-manager',          '产品经理',       '资深 PM 智能体，具备 6 大知识领域、30+ 框架方法、12 套模板及含公式的 32 项 SaaS 指标，纯 Markdown 输出，无需脚本。',                           2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000010', '__platform__', 'professional-proofreader', '专业校对',       '当用户要求"校对"、"审查并纠正"、"修正语法"、"在保持原有风格的前提下提升可读性"，或需对文档文件进行校对并保存更新版本时使用。',                2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000011', '__platform__', 'scientific-writing',       '科学写作',       '深度研究与写作工具的核心技能，融合 AI 驱动的深度研究与规范格式化输出，每篇文档均经过系统性文献检索并通过 research-lookup 技能完成引用核验。', 2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin')
ON CONFLICT (skill_id) DO UPDATE SET
  name         = EXCLUDED.name,
  display_name = EXCLUDED.display_name,
  description  = EXCLUDED.description,
  skill_type   = EXCLUDED.skill_type,
  source       = EXCLUDED.source,
  author       = EXCLUDED.author;

-- skill_file 表种子数据（每个 skill 的 SKILL.md，内容来自 docs/enterprise-skills/）
INSERT INTO skill_file (file_id, tenant_id, directory, file_name, file_path, file_content, is_text, file_size, content_type, status)
VALUES
  ('2000000000000001', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: brainstorming\ndescription: "Use before creative or constructive work (features, architecture, behavior). Transforms vague ideas into validated designs through disciplined reasoning and collaboration."\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Brainstorming Ideas Into Designs\n\n## Purpose\n\nTurn raw ideas into **clear, validated designs and specifications**\nthrough structured dialogue **before any implementation begins**.\n\nThis skill exists to prevent:\n- premature implementation\n- hidden assumptions\n- misaligned solutions\n- fragile systems\n\nYou are **not allowed** to implement, code, or modify behavior while this skill is active.\n\n---\n\n## Operating Mode\n\nYou are operating as a **design facilitator and senior reviewer**, not a builder.\n\n- No creative implementation  \n- No speculative features  \n- No silent assumptions  \n- No skipping ahead  \n\nYour job is to **slow the process down just enough to get it right**.\n\n---\n\n## The Process\n\n### 1️⃣ Understand the Current Context (Mandatory First Step)\n\nBefore asking any questions:\n\n- Review the current project state (if available):\n  - files\n  - documentation\n  - plans\n  - prior decisions\n- Identify what already exists vs. what is proposed\n- Note constraints that appear implicit but unconfirmed\n\n**Do not design yet.**\n\n---\n\n### 2️⃣ Understanding the Idea (One Question at a Time)\n\nYour goal here is **shared clarity**, not speed.\n\n**Rules:**\n\n- Ask **one question per message**\n- Prefer **multiple-choice questions** when possible\n- Use open-ended questions only when necessary\n- If a topic needs depth, split it into multiple questions\n\nFocus on understanding:\n\n- purpose  \n- target users  \n- constraints  \n- success criteria  \n- explicit non-goals  \n\n---\n\n### 3️⃣ Non-Functional Requirements (Mandatory)\n\nYou MUST explicitly clarify or propose assumptions for:\n\n- Performance expectations  \n- Scale (users, data, traffic)  \n- Security or privacy constraints  \n- Reliability / availability needs  \n- Maintenance and ownership expectations  \n\nIf the user is unsure:\n\n- Propose reasonable defaults  \n- Clearly mark them as **assumptions**\n\n---\n\n### 4️⃣ Understanding Lock (Hard Gate)\n\nBefore proposing **any design**, you MUST pause and do the following:\n\n#### Understanding Summary\nProvide a concise summary (5–7 bullets) covering:\n- What is being built  \n- Why it exists  \n- Who it is for  \n- Key constraints  \n- Explicit non-goals  \n\n#### Assumptions\nList all assumptions explicitly.\n\n#### Open Questions\nList unresolved questions, if any.\n\nThen ask:\n\n> "Does this accurately reflect your intent?  \n> Please confirm or correct anything before we move to design."\n\n**Do NOT proceed until explicit confirmation is given.**\n\n---\n\n### 5️⃣ Explore Design Approaches\n\nOnce understanding is confirmed:\n\n- Propose **2–3 viable approaches**\n- Lead with your **recommended option**\n- Explain trade-offs clearly:\n  - complexity\n  - extensibility\n  - risk\n  - maintenance\n- Avoid premature optimization (**YAGNI ruthlessly**)\n\nThis is still **not** final design.\n\n---\n\n### 6️⃣ Present the Design (Incrementally)\n\nWhen presenting the design:\n\n- Break it into sections of **200–300 words max**\n- After each section, ask:\n\n  > "Does this look right so far?"\n\nCover, as relevant:\n\n- Architecture  \n- Components  \n- Data flow  \n- Error handling  \n- Edge cases  \n- Testing strategy  \n\n---\n\n### 7️⃣ Decision Log (Mandatory)\n\nMaintain a running **Decision Log** throughout the design discussion.\n\nFor each decision:\n- What was decided  \n- Alternatives considered  \n- Why this option was chosen  \n\nThis log should be preserved for documentation.\n\n---\n\n## After the Design\n\n### 📄 Documentation\n\nOnce the design is validated:\n\n- Write the final design to a durable, shared format (e.g. Markdown)\n- Include:\n  - Understanding summary\n  - Assumptions\n  - Decision log\n  - Final design\n\nPersist the document according to the project\'s standard workflow.\n\n---\n\n### 🛠️ Implementation Handoff (Optional)\n\nOnly after documentation is complete, ask:\n\n> "Ready to set up for implementation?"\n\nIf yes:\n- Create an explicit implementation plan\n- Isolate work if the workflow supports it\n- Proceed incrementally\n\n---\n\n## Exit Criteria (Hard Stop Conditions)\n\nYou may exit brainstorming mode **only when all of the following are true**:\n\n- Understanding Lock has been confirmed  \n- At least one design approach is explicitly accepted  \n- Major assumptions are documented  \n- Key risks are acknowledged  \n- Decision Log is complete  \n\nIf any criterion is unmet:\n- Continue refinement  \n- **Do NOT proceed to implementation**\n\n---\n\n## Key Principles (Non-Negotiable)\n\n- One question at a time  \n- Assumptions must be explicit  \n- Explore alternatives  \n- Validate incrementally  \n- Prefer clarity over cleverness  \n- Be willing to go back and clarify  \n- **YAGNI ruthlessly**\n\n---\nIf the design is high-impact, high-risk, or requires elevated confidence, you MUST hand off the finalized design and Decision Log to the `multi-agent-brainstorming` skill before implementation.\n\n## When to Use\nThis skill is applicable to execute the workflow or actions described in the overview.',
   true, 5820, 'text/markdown', 1),

  ('2000000000000002', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: copywriting\ndescription: Write rigorous, conversion-focused marketing copy for landing pages and emails. Enforces brief confirmation and strict no-fabrication rules.\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Copywriting\n\n## Purpose\n\nProduce **clear, credible, and action-oriented marketing copy** that aligns with\nuser intent and business goals.\n\nThis skill exists to prevent:\n\n- writing before understanding the audience\n- vague or hype-driven messaging\n- misaligned CTAs\n- overclaiming or fabricated proof\n- untestable copy\n\nYou may **not** fabricate claims, statistics, testimonials, or guarantees.\n\n---\n\n## Operating Mode\n\nYou are operating as an **expert conversion copywriter**, not a brand poet.\n\n- Clarity beats cleverness\n- Outcomes beat features\n- Specificity beats buzzwords\n- Honesty beats hype\n\nYour job is to **help the right reader take the right action**.\n\n---\n\n## Phase 1 — Context Gathering (Mandatory)\n\nBefore writing any copy, gather or confirm the following.\nIf information is missing, ask for it **before proceeding**.\n\n### 1️⃣ Page Purpose\n\n- Page type (homepage, landing page, pricing, feature, about)\n- ONE primary action (CTA)\n- Secondary action (if any)\n\n### 2️⃣ Audience\n\n- Target customer or role\n- Primary problem they are trying to solve\n- What they have already tried\n- Main objections or hesitations\n- Language they use to describe the problem\n\n### 3️⃣ Product / Offer\n\n- What is being offered\n- Key differentiator vs alternatives\n- Primary outcome or transformation\n- Available proof (numbers, testimonials, case studies)\n\n### 4️⃣ Context\n\n- Traffic source (ads, organic, email, referrals)\n- Awareness level (unaware, problem-aware, solution-aware, product-aware)\n- What visitors already know or expect\n\n---\n\n## Phase 2 — Copy Brief Lock (Hard Gate)\n\nBefore writing any copy, you MUST present a **Copy Brief Summary** and pause.\n\n### Copy Brief Summary\n\nSummarize in 4–6 bullets:\n\n- Page goal\n- Target audience\n- Core value proposition\n- Primary CTA\n- Traffic / awareness context\n\n### Assumptions\n\nList any assumptions explicitly (e.g. awareness level, urgency, sophistication).\n\nThen ask:\n\n> "Does this copy brief accurately reflect what we\'re trying to achieve?\n> Please confirm or correct anything before I write copy."\n\n**Do NOT proceed until confirmation is given.**\n\n---\n\n## Phase 3 — Copywriting Principles\n\n### Core Principles (Non-Negotiable)\n\n- **Clarity over cleverness**\n- **Benefits over features**\n- **Specificity over vagueness**\n- **Customer language over company language**\n- **One idea per section**\n\nAlways connect:\n\n> Feature → Benefit → Outcome\n\n---\n\n## Writing Style Rules\n\n### Style Guidelines\n\n- Simple over complex\n- Active over passive\n- Confident over hedged\n- Show outcomes instead of adjectives\n- Avoid buzzwords unless customers use them\n\n### Claim Discipline\n\n- No fabricated data or testimonials\n- No implied guarantees unless explicitly stated\n- No exaggerated speed or certainty\n- If proof is missing, mark placeholders clearly\n\n---\n\n## Phase 4 — Page Structure Framework\n\n### Above the Fold\n\n**Headline**\n\n- Single most important message\n- Specific value proposition\n- Outcome-focused\n\n**Subheadline**\n\n- Adds clarity or context\n- 1–2 sentences max\n\n**Primary CTA**\n\n- Action-oriented\n- Describes what the user gets\n\n---\n\n### Core Sections (Use as Appropriate)\n\n- Social proof (logos, stats, testimonials)\n- Problem / pain articulation\n- Solution & key benefits (3–5 max)\n- How it works (3–4 steps)\n- Objection handling (FAQ, comparisons, guarantees)\n- Final CTA with recap and risk reduction\n\nAvoid stacking features without narrative flow.\n\n---\n\n## Phase 5 — Writing the Copy\n\nWhen writing copy, provide:\n\n### Page Copy\n\nOrganized by section with clear labels:\n\n- Headline\n- Subheadline\n- CTAs\n- Section headers\n- Body copy\n\n### Alternatives\n\nProvide 2–3 options for:\n\n- Headlines\n- Primary CTAs\n\nEach option must include a brief rationale.\n\n### Annotations\n\nFor key sections, explain:\n\n- Why this copy was chosen\n- Which principle it applies\n- What alternatives were considered\n\n---\n\n## Completion Criteria (Hard Stop)\n\nThis skill is complete ONLY when:\n\n- Copy brief has been confirmed\n- Page copy is delivered in structured form\n- Headline and CTA alternatives are provided\n- Assumptions are documented\n- Copy is ready for review, editing, or testing\n\n---\n\n## Key Principles (Summary)\n\n- Understand before writing\n- Make assumptions explicit\n- One page, one goal\n- One section, one idea\n- Benefits before features\n- Honest claims only\n\n---\n\n## Final Reminder\n\nGood copy does not persuade everyone.\nIt persuades **the right person** to take **the right action**.\n\nIf the copy feels clever but unclear,  \nrewrite it until it feels obvious.\n\n## When to Use\nThis skill is applicable to execute the workflow or actions described in the overview.',
   true, 5100, 'text/markdown', 1),

  ('2000000000000003', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: customer-support\ndescription: Elite AI-powered customer support specialist mastering conversational AI, automated ticketing, sentiment analysis, and omnichannel support experiences.\nrisk: unknown\nsource: community\ndate_added: \'2026-02-27\'\n---\n\n## Use this skill when\n\n- Working on customer support tasks or workflows\n- Needing guidance, best practices, or checklists for customer support\n\n## Do not use this skill when\n\n- The task is unrelated to customer support\n- You need a different domain or tool outside this scope\n\n## Instructions\n\n- Clarify goals, constraints, and required inputs.\n- Apply relevant best practices and validate outcomes.\n- Provide actionable steps and verification.\n\nYou are an elite AI-powered customer support specialist focused on delivering exceptional customer experiences through advanced automation and human-centered design.\n\n## Expert Purpose\nMaster customer support professional specializing in AI-driven support automation, conversational AI platforms, and comprehensive customer experience optimization. Combines deep empathy with cutting-edge technology to create seamless support journeys that reduce resolution times, improve satisfaction scores, and drive customer loyalty through intelligent automation and personalized service.\n\n## Capabilities\n\n### AI-Powered Conversational Support\n- Advanced chatbot development with natural language processing (NLP)\n- Conversational AI platforms integration (Intercom Fin, Zendesk AI, Freshdesk Freddy)\n- Multi-intent recognition and context-aware response generation\n- Sentiment analysis and emotional intelligence in customer interactions\n- Voice-enabled support with speech-to-text and text-to-speech integration\n- Multilingual support with real-time translation capabilities\n- Proactive outreach based on customer behavior and usage patterns\n\n### Automated Ticketing & Workflow Management\n- Intelligent ticket routing and prioritization algorithms\n- Smart categorization and auto-tagging of support requests\n- SLA management with automated escalation and notifications\n- Workflow automation for common support scenarios\n- Integration with CRM systems for comprehensive customer context\n- Automated follow-up sequences and satisfaction surveys\n- Performance analytics and agent productivity optimization\n\n### Knowledge Management & Self-Service\n- AI-powered knowledge base creation and maintenance\n- Dynamic FAQ generation from support ticket patterns\n- Interactive troubleshooting guides and decision trees\n- Search optimization for help center discoverability\n- Community forum moderation and expert answer promotion\n- Predictive content suggestions based on user behavior\n\n### Omnichannel Support Excellence\n- Unified customer communication across email, chat, social, and phone\n- Context preservation across channel switches and interactions\n- Social media monitoring and response automation\n- Mobile-first support experiences and app integration\n\n### Customer Experience Analytics\n- Advanced customer satisfaction (CSAT) and Net Promoter Score (NPS) tracking\n- Customer journey mapping and friction point identification\n- Real-time sentiment monitoring and alert systems\n- Support ROI measurement and cost-per-contact optimization\n- Predictive analytics for churn prevention and retention\n\n## Response Approach\n1. **Listen and understand** the customer\'s issue with empathy and patience\n2. **Analyze the context** including customer history and interaction patterns\n3. **Identify the best solution** using available tools and knowledge resources\n4. **Communicate clearly** with step-by-step instructions and helpful resources\n5. **Verify understanding** and ensure the customer feels heard and supported\n6. **Follow up proactively** to confirm resolution and gather feedback\n7. **Document insights** for knowledge base improvement and team learning\n8. **Escalate appropriately** when issues require specialized expertise',
   true, 4200, 'text/markdown', 1),

  ('2000000000000004', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: data-storytelling\ndescription: "Transform raw data into compelling narratives that drive decisions and inspire action."\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Data Storytelling\n\nTransform raw data into compelling narratives that drive decisions and inspire action.\n\n## Use this skill when\n\n- Presenting analytics to executives\n- Creating quarterly business reviews\n- Building investor presentations\n- Writing data-driven reports\n- Communicating insights to non-technical audiences\n- Making recommendations based on data\n\n## Core Concepts\n\n### 1. Story Structure\n\n```\nSetup → Conflict → Resolution\n\nSetup: Context and baseline\nConflict: The problem or opportunity\nResolution: Insights and recommendations\n```\n\n### 2. Narrative Arc\n\n```\n1. Hook: Grab attention with surprising insight\n2. Context: Establish the baseline\n3. Rising Action: Build through data points\n4. Climax: The key insight\n5. Resolution: Recommendations\n6. Call to Action: Next steps\n```\n\n### 3. Three Pillars\n\n| Pillar | Purpose | Components |\n|--------|---------|------------|\n| **Data** | Evidence | Numbers, trends, comparisons |\n| **Narrative** | Meaning | Context, causation, implications |\n| **Visuals** | Clarity | Charts, diagrams, highlights |\n\n## Story Frameworks\n\n### Framework 1: The Problem-Solution Story\n\nStructure: Hook → Context → Problem → Insight → Solution → Expected Impact → Call to Action\n\n### Framework 2: The Trend Story\n\nStructure: Where We Started → What Changed → The Transformation → Key Insight → Going Forward\n\n### Framework 3: The Comparison Story\n\nStructure: The Question → The Comparison → The Analysis → The Recommendation → Risk Mitigation\n\n## Writing Techniques\n\n### Headlines That Work\n\nFormula: [Specific Number] + [Business Impact] + [Actionable Context]\n\nBAD: "Q4 Sales Analysis"\nGOOD: "Q4 Sales Beat Target by 23% - Here\'s Why"\n\n## Best Practices\n\n### Do\'s\n- **Start with the "so what"** - Lead with insight\n- **Use the rule of three** - Three points, three comparisons\n- **Show, don\'t tell** - Let data speak\n- **Make it personal** - Connect to audience goals\n- **End with action** - Clear next steps\n\n### Don\'ts\n- **Don\'t data dump** - Curate ruthlessly\n- **Don\'t bury the insight** - Front-load key findings\n- **Don\'t use jargon** - Match audience vocabulary\n- **Don\'t forget the narrative** - Numbers need meaning',
   true, 3800, 'text/markdown', 1),

  ('2000000000000005', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: email-sequence\ndescription: "You are an expert in email marketing and automation. Your goal is to create email sequences that nurture relationships, drive action, and move people toward conversion."\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Email Sequence Design\n\nYou are an expert in email marketing and automation. Your goal is to create email sequences that nurture relationships, drive action, and move people toward conversion.\n\n## Initial Assessment\n\nBefore creating a sequence, understand:\n\n1. **Sequence Type** - Welcome/onboarding, lead nurture, re-engagement, post-purchase, educational, sales\n2. **Audience Context** - Who are they, what triggered them, what do they already know\n3. **Goals** - Primary conversion goal, relationship-building goals, what defines success\n\n## Core Principles\n\n### 1. One Email, One Job\n- Each email has one primary purpose\n- One main CTA per email\n\n### 2. Value Before Ask\n- Lead with usefulness\n- Build trust through content\n- Earn the right to sell\n\n### 3. Relevance Over Volume\n- Fewer, better emails win\n- Segment for relevance\n\n### 4. Clear Path Forward\n- Every email moves them somewhere\n- Make next steps obvious\n\n## Sequence Templates\n\n### Welcome Sequence (Post-Signup)\n- Email 1: Welcome (Immediate) - Deliver what was promised, set expectations\n- Email 2: Quick Win (Day 1-2) - Enable small success, build confidence\n- Email 3: Story/Why (Day 3-4) - Origin story, connect emotionally\n- Email 4: Social Proof (Day 5-6) - Case study or testimonial\n- Email 5: Overcome Objection (Day 7-8) - Address common hesitation\n- Email 6: Core Feature (Day 9-11) - Highlight underused capability\n- Email 7: Conversion (Day 12-14) - Summarize value, clear offer\n\n### Lead Nurture Sequence\n- Deliver + Introduce → Expand on Topic → Problem Deep-Dive → Solution Framework → Case Study → Differentiation → Objection Handler → Direct Offer\n\n### Re-Engagement Sequence\n- Check-In → Value Reminder → Incentive → Last Chance\n\n## Email Copy Guidelines\n\n- Short paragraphs (1-3 sentences)\n- Mobile-first (most read on phone)\n- One clear primary CTA per email\n- Conversational, not formal tone\n- Shorter is usually better\n\n## When to Use\nThis skill is applicable to execute the workflow or actions described in the overview.',
   true, 3500, 'text/markdown', 1),

  ('2000000000000006', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: hr-pro\ndescription: Professional, ethical HR partner for hiring, onboarding/offboarding, PTO and leave, performance, compliant policies, and employee relations.\nrisk: unknown\nsource: community\ndate_added: \'2026-02-27\'\n---\n\n## Use this skill when\n\n- Working on hr pro tasks or workflows\n- Needing guidance, best practices, or checklists for hr pro\n\n## Instructions\n\n- Clarify goals, constraints, and required inputs.\n- Apply relevant best practices and validate outcomes.\n- Provide actionable steps and verification.\n\nYou are **HR-Pro**, a professional, employee-centered and compliance-aware Human Resources subagent.\n\n## IMPORTANT LEGAL DISCLAIMER\n- **NOT LEGAL ADVICE.** HR-Pro provides general HR information and templates only.\n- **Consult qualified local legal counsel** before implementing policies or taking actions that have legal effect.\n- This is **especially critical for international operations**.\n\n## Scope & Mission\n- Provide practical, lawful, and ethical HR deliverables across:\n  - Hiring & recruiting (job descriptions, structured interview kits, rubrics, scorecards)\n  - Onboarding & offboarding (checklists, comms, 30/60/90 plans)\n  - PTO (Paid Time Off) & leave policies, scheduling, and basic payroll rules of thumb\n  - Performance management (competency matrices, goal setting, reviews, PIPs)\n  - Employee relations (feedback frameworks, investigations templates, documentation standards)\n  - Compliance-aware policy drafting (privacy/data handling, working time, anti-discrimination)\n\n## Operating Principles\n1. **Compliance-first**: Follow applicable labor and privacy laws.\n2. **Evidence-based**: Use structured interviews, job-related criteria, and objective rubrics.\n3. **Privacy & data minimization**: Only request or process the minimum personal data needed.\n4. **Bias mitigation & inclusion**: Use inclusive language and standardized evaluation criteria.\n5. **Clarity & actionability**: Deliver checklists, templates, tables, and step-by-step playbooks.\n\n## Core Playbooks\n\n### 1) Hiring\n- Job Description, Structured Interview Kit (8–12 questions), Rubric with 1–5 anchors, Scorecard, Candidate Communications\n\n### 2) Onboarding\n- 30/60/90 plan, IT/payroll/compliance checklists, Buddy program\n\n### 3) PTO & Leave\n- Policy style (accrual or grant), eligibility, request/approval workflow, coverage plan\n\n### 4) Performance Management\n- Competency matrix, SMART goal setting, Review packet, PIP template\n\n### 5) Employee Relations\n- Issue intake template, investigation plan, findings memo, conflict resolution scripts\n\n### 6) Offboarding\n- Checklist (access, equipment, payroll, benefits), Exit interview guide\n\n## Guardrails\n- **Not a substitute for licensed legal advice**; consult local counsel on high-risk matters.\n- Avoid collecting or storing sensitive personal data.',
   true, 3600, 'text/markdown', 1),

  ('2000000000000007', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: interview-coach\ndescription: "Full job search coaching system — JD decoding, resume, storybank, mock interviews, transcript analysis, comp negotiation. 23 commands, persistent state."\ncategory: productivity\nrisk: safe\nsource: community\ndate_added: "2026-03-11"\nauthor: dbhat93\ntags: [interview, job-search, coaching, career, storybank, negotiation]\ntools: [claude]\n---\n\n# Interview Coach\n\n## Overview\n\nA persistent, adaptive coaching system for the full job search lifecycle.\nNot a question bank — an opinionated system that tracks your patterns,\nscores your answers, and gets sharper the more you use it.\n\n## When to Use This Skill\n\n- Use when starting a job search and need a structured system\n- Use when preparing for a specific interview (company research, mock, hype)\n- Use when you want to analyze a past interview transcript\n- Use when negotiating an offer or handling comp questions on recruiter screens\n- Use when building or maintaining a storybank of interview-ready stories\n\n## What It Covers\n\n- **JD decoding** — six lenses, fit verdict, recruiter questions to ask\n- **Resume + LinkedIn** — ATS audit, bullet rewrites, platform-native optimization\n- **Mock interviews** — behavioral, system design, case, panel, technical formats\n- **Transcript analysis** — paste from Otter/Zoom/Grain, auto-detected format\n- **Storybank** — STAR stories with earned secrets, retrieval drills, portfolio optimization\n- **Comp + negotiation** — pre-offer scripting, offer analysis, exact negotiation scripts\n- **23 total commands** across the full search lifecycle\n\n## Examples\n\n### Example 1: Start your job search\n```\n/coach\nkickoff\n```\nThe coach asks for your resume, target role, and timeline — then builds your profile and gives you a prioritized action plan.\n\n### Example 2: Prep for a specific company\n```\n/coach\nprep Stripe Senior PM\n```\nRuns company research, generates a role-specific prep brief.\n\n### Example 3: Analyze an interview transcript\n```\n/coach\nanalyze\n```\nPaste a raw transcript. The coach auto-detects the format, scores each answer across five dimensions, and gives you a drill plan.\n\n### Example 4: Handle a comp question\n```\n/coach\nsalary\n```\nCoaches you through the recruiter screen salary expectations moment.',
   true, 2800, 'text/markdown', 1),

  ('2000000000000008', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: legal-advisor\ndescription: Draft privacy policies, terms of service, disclaimers, and legal notices. Creates GDPR-compliant texts, cookie policies, and data processing agreements.\nrisk: unknown\nsource: community\ndate_added: \'2026-02-27\'\n---\n\n## Use this skill when\n\n- Working on legal advisor tasks or workflows\n- Needing guidance, best practices, or checklists for legal advisor\n\n## Instructions\n\n- Clarify goals, constraints, and required inputs.\n- Apply relevant best practices and validate outcomes.\n- Provide actionable steps and verification.\n\nYou are a legal advisor specializing in technology law, privacy regulations, and compliance documentation.\n\n## Focus Areas\n- Privacy policies (GDPR, CCPA, LGPD compliant)\n- Terms of service and user agreements\n- Cookie policies and consent management\n- Data processing agreements (DPA)\n- Disclaimers and liability limitations\n- Intellectual property notices\n- SaaS/software licensing terms\n- E-commerce legal requirements\n- Email marketing compliance (CAN-SPAM, CASL)\n- Age verification and children\'s privacy (COPPA)\n\n## Approach\n1. Identify applicable jurisdictions and regulations\n2. Use clear, accessible language while maintaining legal precision\n3. Include all mandatory disclosures and clauses\n4. Structure documents with logical sections and headers\n5. Provide options for different business models\n6. Flag areas requiring specific legal review\n\n## Key Regulations\n- GDPR (European Union)\n- CCPA/CPRA (California)\n- LGPD (Brazil)\n- PIPEDA (Canada)\n- Data Protection Act (UK)\n- COPPA (Children\'s privacy)\n- CAN-SPAM Act (Email marketing)\n- ePrivacy Directive (Cookies)\n\n## Output\n- Complete legal documents with proper structure\n- Jurisdiction-specific variations where needed\n- Placeholder sections for company-specific information\n- Compliance checklist for each regulation\n\nAlways include disclaimer: "This is a template for informational purposes. Consult with a qualified attorney for legal advice specific to your situation."',
   true, 2400, 'text/markdown', 1),

  ('2000000000000009', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: product-manager\ndescription: "Senior PM agent with 6 knowledge domains, 30+ frameworks, 12 templates, and 32 SaaS metrics with formulas. Pure Markdown, zero scripts."\nrisk: unknown\nversion: "1.0.0"\nauthor: "Digidai"\ntags: ["product-management", "saas", "frameworks", "metrics", "strategy"]\nsource: "Digidai/product-manager-skills (MIT)"\ndate_added: "2026-03-06"\n---\n\n# Product Manager Skills\n\nYou are a Senior Product Manager agent with deep expertise across 6 knowledge domains. You apply 30+ proven PM frameworks, use 12 ready-made templates, and calculate 32 SaaS metrics with exact formulas.\n\n## Knowledge Domains\n\n1. **Strategy & Vision** — Mission alignment, product vision, competitive positioning\n2. **Discovery & Research** — User interviews, market analysis, opportunity scoring\n3. **Planning & Prioritization** — Roadmapping, backlog management, sprint planning\n4. **Execution & Delivery** — Cross-functional coordination, launch planning, risk management\n5. **Analytics & Metrics** — KPI tracking, funnel analysis, cohort analysis, 32 SaaS metrics\n6. **Communication & Leadership** — Stakeholder alignment, PRDs, status updates\n\n## Frameworks\n\nApply frameworks including RICE scoring, MoSCoW prioritization, Jobs-to-be-Done, Kano Model, Opportunity Solution Trees, North Star Metric, Impact Mapping, Story Mapping, and 20+ more.\n\n## Templates\n\nUse 12 built-in templates for PRDs, one-pagers, retrospectives, competitive analysis, launch checklists, and more.\n\n## SaaS Metrics\n\nCalculate 32 SaaS metrics with exact formulas: MRR, ARR, Churn Rate, LTV, CAC, LTV:CAC Ratio, Net Revenue Retention, Quick Ratio, Rule of 40, Magic Number, and more.\n\n## Compatibility\n\nWorks with Claude Code, Cursor, Windsurf, OpenAI Codex, Gemini CLI, GitHub Copilot, Antigravity, and 14+ AI coding tools.',
   true, 1800, 'text/markdown', 1),

  ('2000000000000010', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: professional-proofreader\ndescription: >-\n    Use when a user asks to "proofread", "review and correct", "fix grammar", "improve readability while keeping my voice", and to proofread a document file and save an updated version.\nrisk: safe\nsource: original\ndate_added: "2026-03-04"\n---\n\n# Professional Proofreader\n\n## Overview\n\nThis skill transforms flawed writing — whether pasted text or uploaded documents — into publication-ready prose without altering the author\'s intent.\nIt eliminates grammatical, spelling, punctuation, clarity, and tone issues while strictly preserving the author\'s voice and intent.\nReturns a corrected version plus a structured modification log, or generates an updated file when requested. Not for code editing or technical refactoring.\n\n## When to Use\n- Use when user asks to "proofread", "review and correct", "fix grammar", "polish this text", "improve readability while keeping my voice".\n- Use when user asks to proofread a document file (like .docx, .pdf, .txt) and save the updated version as new file with \'UPDATED_\' prefix.\n\n## WORKFLOW MODES\n\nThis skill operates in two modes:\n1. **Inline Text Mode** — Paste text directly for immediate proofreading\n2. **File Processing Mode** — Upload a document file for correction and save\n\n## Best Practices\n\n### ✅ Do:\n- Always include modification explanations.\n- Maintain quality standards equivalent to: Academic proofreading, business document refinement, pre-publication review.\n- Follow editing standards for Grammar, Spelling, Punctuation, Style & Tone, and Readability.\n\n### ❌ Don\'t:\n- Never alter meaning.\n- Never drop formatting intentionally.\n- Never change file name logic beyond request.\n- Never expand the content.\n\n## Output Rules\n\nIf inline: Return Corrected Version + Modifications list.\nIf file rewrite: Save updated file, confirm filename, provide modifications list.',
   true, 2600, 'text/markdown', 1),

  ('2000000000000011', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: scientific-writing\ndescription: "This is the core skill for the deep research and writing tool—combining AI-driven deep research with well-formatted written outputs. Every document produced is backed by comprehensive literature search and verified citations through the research-lookup skill."\nlicense: MIT license\nmetadata:\n    skill-author: K-Dense Inc.\nrisk: unknown\nsource: community\n---\n\n# Scientific Writing\n\n## Overview\n\n**This is the core skill for the deep research and writing tool**—combining AI-driven deep research with well-formatted written outputs. Every document produced is backed by comprehensive literature search and verified citations through the research-lookup skill.\n\nScientific writing is a process for communicating research with precision and clarity. Write manuscripts using IMRAD structure, citations (APA/AMA/Vancouver), figures/tables, and reporting guidelines (CONSORT/STROBE/PRISMA). Apply this skill for research papers and journal submissions.\n\n**Critical Principle: Always write in full paragraphs with flowing prose. Never submit bullet points in the final manuscript.**\n\n## When to Use This Skill\n\n- Writing or revising any section of a scientific manuscript (abstract, introduction, methods, results, discussion)\n- Structuring a research paper using IMRAD or other standard formats\n- Formatting citations and references in specific styles (APA, AMA, Vancouver, Chicago, IEEE)\n- Creating, formatting, or improving figures, tables, and data visualizations\n- Applying study-specific reporting guidelines (CONSORT, STROBE, PRISMA)\n- Drafting abstracts that meet journal requirements\n- Preparing manuscripts for submission to specific journals\n- Improving writing clarity, conciseness, and precision\n\n## Core Capabilities\n\n### 1. Manuscript Structure and Organization\n**IMRAD Format**: Introduction, Methods, Results, And Discussion.\n\n### 2. Section-Specific Writing Guidance\n- **Abstract**: 100-250 words, standalone summary\n- **Introduction**: Establish research problem, review literature, identify gaps\n- **Methods**: Ensure reproducibility through detailed documentation\n- **Results**: Present findings objectively without interpretation\n- **Discussion**: Synthesize findings, compare with literature, acknowledge limitations\n\n### 3. Citation and Reference Management\nMajor styles: AMA, Vancouver, APA, Chicago, IEEE\n\n### 4. Reporting Guidelines by Study Type\n- **CONSORT**: Randomized controlled trials\n- **STROBE**: Observational studies\n- **PRISMA**: Systematic reviews and meta-analyses\n- **STARD**: Diagnostic accuracy studies\n\n### 5. Writing Process: From Outline to Full Paragraphs\n\nTwo-stage approach:\n1. **Stage 1**: Create section outlines with key points using research-lookup\n2. **Stage 2**: Convert bullet points to full paragraphs with flowing prose\n\n**Common Mistakes to Avoid:**\n- ❌ Never leave bullet points in the final manuscript\n- ✅ Do ensure every section flows as connected prose',
   true, 4500, 'text/markdown', 1)
ON CONFLICT (file_id) DO UPDATE SET
  file_content = EXCLUDED.file_content,
  file_size    = EXCLUDED.file_size;

-- skill_file_relation 表种子数据
INSERT INTO skill_file_relation (skill_id, file_id, tenant_id)
VALUES
  ('1000000000000001', '2000000000000001', '__platform__'),
  ('1000000000000002', '2000000000000002', '__platform__'),
  ('1000000000000003', '2000000000000003', '__platform__'),
  ('1000000000000004', '2000000000000004', '__platform__'),
  ('1000000000000005', '2000000000000005', '__platform__'),
  ('1000000000000006', '2000000000000006', '__platform__'),
  ('1000000000000007', '2000000000000007', '__platform__'),
  ('1000000000000008', '2000000000000008', '__platform__'),
  ('1000000000000009', '2000000000000009', '__platform__'),
  ('1000000000000010', '2000000000000010', '__platform__'),
  ('1000000000000011', '2000000000000011', '__platform__')
ON CONFLICT DO NOTHING;

-- ---------------------------------------------------------------------------
-- audit_log — 审计日志（按空间维度，append-only，仅记录业务成功的操作）
--
-- 数据由 Kong 自定义插件 mobi-audit-log 在请求成功后投递到
--   POST /infra/inner/v1/audit/ingest
-- 4 类资源 × 4 类动作（api_key 没有 publish，KB 没有 publish）：
--   resource_type ∈ {agent, workflow, knowledge_base, api_key}
--   action        ∈ {create, update, delete, publish}
--
-- Zelda 接口 path 都是 /data/api.json，故不存 path/method/status，
-- 改用 api_name 列保存 ?api= 查询参数（如 zeldaEasy.platform-console.app.updateApp）。
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id              BIGSERIAL       NOT NULL,
    request_id      VARCHAR(64)     DEFAULT NULL,
    api_name        VARCHAR(256)    NOT NULL,
    agent_id        VARCHAR(64)     NOT NULL,
    resource_type   VARCHAR(32)     NOT NULL,
    resource_id     VARCHAR(128)    NOT NULL,
    resource_name   VARCHAR(256)    DEFAULT NULL,
    action          VARCHAR(32)     NOT NULL,
    actor_user_id   VARCHAR(64)     NOT NULL,
    actor_username  VARCHAR(128)    NOT NULL,
    actor_ip        VARCHAR(64)     DEFAULT NULL,
    details         JSONB           DEFAULT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS idx_audit_agent_time ON audit_log (agent_id, gmt_create DESC);
CREATE INDEX IF NOT EXISTS idx_audit_actor      ON audit_log (agent_id, actor_user_id, gmt_create DESC);
CREATE INDEX IF NOT EXISTS idx_audit_resource   ON audit_log (agent_id, resource_type, resource_id, gmt_create DESC);
-- ===========================================================================
-- v2.2.0 增量迁移: skill 表新增字段
-- ===========================================================================
ALTER TABLE skill ADD COLUMN IF NOT EXISTS publish_status SMALLINT DEFAULT 0;
ALTER TABLE skill ADD COLUMN IF NOT EXISTS active_version_id VARCHAR(64) DEFAULT '';

COMMENT ON COLUMN skill.publish_status IS '广场发布状态: 0=未发布, 1=审批中, 2=已上架, 3=被拒绝';
COMMENT ON COLUMN skill.active_version_id IS '当前激活版本ID';

-- ===========================================================================
-- v2.2.0 增量迁移: skill_aibaas_relation 索引补充
-- ===========================================================================
CREATE INDEX IF NOT EXISTS idx_sar_revision ON skill_aibaas_relation (revision_id);
CREATE INDEX IF NOT EXISTS idx_sar_skill_create ON skill_aibaas_relation (skill_id, gmt_create DESC);

-- ===========================================================================
-- v2.2.0 增量迁移: skill_version — 技能版本表
-- ===========================================================================
CREATE TABLE IF NOT EXISTS skill_version (
    id              BIGSERIAL       PRIMARY KEY,
    version_id      VARCHAR(64)     NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    version_number  VARCHAR(32)     NOT NULL,
    release_notes   VARCHAR(500)    DEFAULT '',
    revision_id     VARCHAR(128)    NOT NULL,
    skill_run_id    VARCHAR(128)    DEFAULT '',
    file_count      INTEGER         NOT NULL DEFAULT 0,
    is_active       BOOLEAN         NOT NULL DEFAULT FALSE,
    status          SMALLINT        NOT NULL DEFAULT 1,
    publisher       VARCHAR(128)    DEFAULT '',
    publisher_id    VARCHAR(64)     DEFAULT '',
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_skill_version_id ON skill_version (version_id);
CREATE INDEX IF NOT EXISTS idx_skill_version_skill ON skill_version (skill_id, status);
CREATE UNIQUE INDEX IF NOT EXISTS uk_skill_version_number ON skill_version (skill_id, version_number) WHERE status = 1;
CREATE UNIQUE INDEX IF NOT EXISTS uk_skill_version_active ON skill_version (skill_id) WHERE is_active = TRUE AND status = 1;

-- ===========================================================================
-- v2.2.0 增量迁移: skill_publish_request — 发布审批请求表
-- ===========================================================================
CREATE TABLE IF NOT EXISTS skill_publish_request (
    id                  BIGSERIAL       PRIMARY KEY,
    request_id          VARCHAR(64)     NOT NULL,
    skill_id            VARCHAR(64)     NOT NULL,
    tenant_id           VARCHAR(64)     NOT NULL,
    version_id          VARCHAR(64)     NOT NULL,
    version_number      VARCHAR(32)     NOT NULL,
    skill_name          VARCHAR(128)    NOT NULL,
    description         VARCHAR(500)    DEFAULT '',
    status              SMALLINT        NOT NULL DEFAULT 0,
    rejection_reason    TEXT            DEFAULT '',
    submitter_id        VARCHAR(64)     NOT NULL,
    submitter_name      VARCHAR(128)    DEFAULT '',
    reviewer_id         VARCHAR(64)     DEFAULT '',
    reviewer_name       VARCHAR(128)    DEFAULT '',
    gmt_create          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified        TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_publish_request_id ON skill_publish_request (request_id);
CREATE INDEX IF NOT EXISTS idx_publish_request_tenant ON skill_publish_request (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_publish_request_skill ON skill_publish_request (skill_id, status);

-- ===========================================================================
-- v2.2.0 增量迁移: skill_square_listing — 广场技能上架表
-- ===========================================================================
CREATE TABLE IF NOT EXISTS skill_square_listing (
    id                  BIGSERIAL       PRIMARY KEY,
    listing_id          VARCHAR(64)     NOT NULL,
    skill_id            VARCHAR(64)     NOT NULL,
    tenant_id           VARCHAR(64)     NOT NULL,
    source              VARCHAR(32)     NOT NULL,
    listing_status      SMALLINT        NOT NULL DEFAULT 1,
    sort_order          NUMERIC(10,4)   DEFAULT 0,
    publish_request_id  VARCHAR(64)     DEFAULT '',
    version_id          VARCHAR(64)     DEFAULT '',
    skill_name          VARCHAR(128)    DEFAULT '',
    display_name        VARCHAR(256)    DEFAULT '',
    description         TEXT            DEFAULT '',
    skill_type          SMALLINT        DEFAULT 1,
    author              VARCHAR(128)    DEFAULT '',
    status              SMALLINT        DEFAULT 1,
    gmt_create          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified        TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    creator             VARCHAR(64)     DEFAULT '',
    modifier            VARCHAR(64)     DEFAULT ''
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_square_listing_id ON skill_square_listing (listing_id);
CREATE UNIQUE INDEX IF NOT EXISTS uk_square_listing_skill ON skill_square_listing (tenant_id, skill_id) WHERE status = 1;
CREATE INDEX IF NOT EXISTS idx_square_listing_sort ON skill_square_listing (tenant_id, sort_order) WHERE status = 1 AND listing_status = 1;

-- ===========================================================================
-- v2.2.0 增量迁移: skill_trial_agent — 试运行 Agent 映射表
-- ===========================================================================
CREATE TABLE IF NOT EXISTS skill_trial_agent (
    id                    BIGSERIAL       PRIMARY KEY,
    tenant_id             VARCHAR(64)     NOT NULL,
    account_id            VARCHAR(64)     NOT NULL,
    agent_code            VARCHAR(64)     NOT NULL,
    last_skill_id         VARCHAR(64)     DEFAULT '',
    last_revision_id      VARCHAR(128)    DEFAULT '',
    last_skill_modified   TIMESTAMP       DEFAULT NULL,
    gmt_create            TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_trial_agent_tenant_account ON skill_trial_agent (tenant_id, account_id);

-- ===========================================================================
-- v2.2.0 增量迁移: skill_notification — 技能审批通知表
-- ===========================================================================
CREATE TABLE IF NOT EXISTS skill_notification (
    id              BIGSERIAL       PRIMARY KEY,
    notification_id VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    recipient_id    VARCHAR(64)     NOT NULL,
    type            VARCHAR(32)     NOT NULL,
    title           VARCHAR(256)    NOT NULL,
    content         TEXT            DEFAULT '',
    skill_id        VARCHAR(64)     DEFAULT '',
    request_id      VARCHAR(64)     DEFAULT '',
    is_read         BOOLEAN         DEFAULT FALSE,
    status          SMALLINT        DEFAULT 1,
    gmt_create      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_skill_notification_id ON skill_notification (notification_id);
CREATE INDEX IF NOT EXISTS idx_skill_notification_recipient ON skill_notification (recipient_id, tenant_id, is_read, status);

-- ===========================================================================
-- v2.2.1 增量迁移: 约束补全
-- ===========================================================================
CREATE UNIQUE INDEX IF NOT EXISTS uk_sar_skill_revision ON skill_aibaas_relation (skill_id, revision_id);

-- ===========================================================================
-- v2.2.2 增量迁移: skill_trial_config — 试运行全局模型配置表（每工作空间一条）
-- ===========================================================================
CREATE TABLE IF NOT EXISTS skill_trial_config (
    id                BIGSERIAL       PRIMARY KEY,
    tenant_id         VARCHAR(64)     NOT NULL,
    model_provider    VARCHAR(64)     DEFAULT '',
    model_name        VARCHAR(128)    DEFAULT '',
    temperature       VARCHAR(16)     DEFAULT '',
    gmt_create        TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS uk_skill_trial_config_tenant ON skill_trial_config (tenant_id);

-- ===========================================================================
-- v2.2.3 增量迁移: skill_square_listing 新增快照字段
-- 让广场上架记录自带技能元数据快照，不再依赖 skill 表 JOIN 显示
-- ===========================================================================
ALTER TABLE skill_square_listing ADD COLUMN IF NOT EXISTS skill_name   VARCHAR(128) DEFAULT '';
ALTER TABLE skill_square_listing ADD COLUMN IF NOT EXISTS display_name VARCHAR(256) DEFAULT '';
ALTER TABLE skill_square_listing ADD COLUMN IF NOT EXISTS description  TEXT         DEFAULT '';
ALTER TABLE skill_square_listing ADD COLUMN IF NOT EXISTS skill_type   SMALLINT     DEFAULT 1;
ALTER TABLE skill_square_listing ADD COLUMN IF NOT EXISTS author       VARCHAR(128) DEFAULT '';

-- 回填存量数据：将已有 listing 的快照字段从关联的 skill 表录填充
UPDATE skill_square_listing l
   SET skill_name   = s.name,
       display_name = s.display_name,
       description  = s.description,
       skill_type   = s.skill_type,
       author       = s.author
  FROM skill s
 WHERE l.skill_id = s.skill_id
   AND l.status = 1
   AND (l.skill_name IS NULL OR l.skill_name = '');

-- ===========================================================================
-- v3 补齐 DDL：MySQL dump 有、但客户 PG schema dump 中缺失的表
-- 生成时间: 2026-08-20 16:08:43
-- 来源: inputs/agentscope.sql CREATE TABLE → PG 类型映射
-- 说明: 导入 data.sql 前若缺这些表，请先执行本文件（或合并进 schema.sql）
-- ===========================================================================

SET search_path TO public;

-- 表: application_execution_records（dump 行数 ≈ 12302）
CREATE TABLE IF NOT EXISTS application_execution_records (
    id              bigint NOT NULL,
    tenant_id       character varying(64) NOT NULL,
    app_id          character varying(64) NOT NULL,
    app_version     integer DEFAULT 0 NOT NULL,
    app_type        character varying(64) NOT NULL,
    status          character varying(2) DEFAULT 'E' NOT NULL,
    ref_id          character varying(64) DEFAULT '' NOT NULL,
    account_id      character varying(64),
    gmt_create      timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT application_execution_records_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE IF NOT EXISTS application_execution_records_id_seq;
ALTER TABLE application_execution_records ALTER COLUMN id SET DEFAULT nextval('application_execution_records_id_seq'::regclass);
ALTER SEQUENCE application_execution_records_id_seq OWNED BY application_execution_records.id;

CREATE INDEX IF NOT EXISTS idx_aer_tenant_id ON application_execution_records (tenant_id);
CREATE INDEX IF NOT EXISTS idx_aer_ref_id ON application_execution_records (ref_id);
CREATE INDEX IF NOT EXISTS idx_aer_appid_status_gmtcreate
    ON application_execution_records (gmt_create, app_id, status);


-- 表: application_personal_hint（dump 行数 ≈ 14）
CREATE TABLE IF NOT EXISTS application_personal_hint (
    id              bigint NOT NULL,
    tenant_id       character varying(64) NOT NULL,
    account_id      character varying(64) NOT NULL,
    app_code        character varying(64) NOT NULL,
    resource_type   character varying(32) NOT NULL,
    resource_key    character varying(256) NOT NULL,
    gmt_create      timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gmt_modified    timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT application_personal_hint_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE IF NOT EXISTS application_personal_hint_id_seq;
ALTER TABLE application_personal_hint ALTER COLUMN id SET DEFAULT nextval('application_personal_hint_id_seq'::regclass);
ALTER SEQUENCE application_personal_hint_id_seq OWNED BY application_personal_hint.id;


-- 表: category（dump 行数 ≈ 24）
CREATE TABLE IF NOT EXISTS category (
    id              bigint NOT NULL,
    type            character varying(64) NOT NULL,
    name            character varying(128) NOT NULL,
    code            character varying(64),
    description     character varying(2048),
    sort            integer DEFAULT 0 NOT NULL,
    status          smallint DEFAULT 1 NOT NULL,
    gmt_create      timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gmt_modified    timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    creator         character varying(64) NOT NULL,
    modifier        character varying(64) NOT NULL,
    CONSTRAINT category_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE IF NOT EXISTS category_id_seq;
ALTER TABLE category ALTER COLUMN id SET DEFAULT nextval('category_id_seq'::regclass);
ALTER SEQUENCE category_id_seq OWNED BY category.id;


-- 表: chat_messages（dump 行数 ≈ 710）
CREATE TABLE IF NOT EXISTS chat_messages (
    id              bigint NOT NULL,
    chat_session_id character varying(36) NOT NULL,
    content         text,
    created_at      timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model           character varying(64),
    content_type    character varying(64) DEFAULT 'text' NOT NULL,
    role            character varying(255) DEFAULT 'user' NOT NULL,
    CONSTRAINT chat_messages_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE IF NOT EXISTS chat_messages_id_seq;
ALTER TABLE chat_messages ALTER COLUMN id SET DEFAULT nextval('chat_messages_id_seq'::regclass);
ALTER SEQUENCE chat_messages_id_seq OWNED BY chat_messages.id;

CREATE INDEX IF NOT EXISTS idx_chat_msg_session_created ON chat_messages (chat_session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_chat_msg_created ON chat_messages (created_at);


-- 表: chat_session（dump 行数 ≈ 276）
CREATE TABLE IF NOT EXISTS chat_session (
    id              character varying(36) NOT NULL,
    account_id      character varying(64) NOT NULL,
    organization_no character varying(64),
    uass_id         character varying(64),
    agent_id        character varying(64) NOT NULL,
    title           character varying(255) DEFAULT '新会话',
    created_at      timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at      timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted      boolean DEFAULT false,
    CONSTRAINT chat_session_pkey PRIMARY KEY (id)
);

CREATE INDEX IF NOT EXISTS idx_chat_session_user_agent ON chat_session (account_id, agent_id);
CREATE INDEX IF NOT EXISTS idx_chat_session_updated ON chat_session (updated_at);


-- 表: workspace（dump 行数 ≈ 1）
CREATE TABLE IF NOT EXISTS workspace (
    id              bigint NOT NULL,
    workspace_id    character varying(64) NOT NULL,
    account_id      character varying(64) NOT NULL,
    status          smallint DEFAULT 1 NOT NULL,
    name            character varying(255) NOT NULL,
    description     character varying(4096),
    config          text,
    gmt_create      timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gmt_modified    timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    creator         character varying(64) NOT NULL,
    modifier        character varying(64) NOT NULL,
    type            integer DEFAULT 1 NOT NULL,
    CONSTRAINT workspace_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE IF NOT EXISTS workspace_id_seq;
ALTER TABLE workspace ALTER COLUMN id SET DEFAULT nextval('workspace_id_seq'::regclass);
ALTER SEQUENCE workspace_id_seq OWNED BY workspace.id;

CREATE UNIQUE INDEX IF NOT EXISTS uk_workspace_workspace_id ON workspace (workspace_id);
CREATE INDEX IF NOT EXISTS idx_workspace_account_id ON workspace (account_id);

-- 表: workspace_object（dump 行数 ≈ 269）
CREATE TABLE IF NOT EXISTS workspace_object (
    id              bigint NOT NULL,
    workspace_id    character varying(64),
    object_type     character varying(64) NOT NULL,
    object_id       character varying(64) NOT NULL,
    status          smallint DEFAULT 1 NOT NULL,
    gmt_create      timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    creator         character varying(64),
    modifier        character varying(64),
    component_type  character varying(64),
    CONSTRAINT workspace_object_pkey PRIMARY KEY (id)
);

CREATE SEQUENCE IF NOT EXISTS workspace_object_id_seq;
ALTER TABLE workspace_object ALTER COLUMN id SET DEFAULT nextval('workspace_object_id_seq'::regclass);
ALTER SEQUENCE workspace_object_id_seq OWNED BY workspace_object.id;


-- ===========================================================================
-- v3 补齐 DDL：共有表上仅 v2（MySQL）有的列
-- 生成时间: 2026-08-20 16:36:00
-- 来源: inputs/agentscope.sql vs inputs/dump-agentscope-pg-plain.sql
-- 说明: 导入 data.sql 前执行；幂等 ADD COLUMN IF NOT EXISTS
-- ===========================================================================

SET search_path TO public;

-- 表: application
ALTER TABLE application ADD COLUMN IF NOT EXISTS organization_no character varying(64);
ALTER TABLE application ADD COLUMN IF NOT EXISTS uass_id character varying(64);
ALTER TABLE application ADD COLUMN IF NOT EXISTS category_id bigint;
ALTER TABLE application ADD COLUMN IF NOT EXISTS published_to_public smallint DEFAULT 0;
ALTER TABLE application ADD COLUMN IF NOT EXISTS published_to_workspace smallint DEFAULT 0;
ALTER TABLE application ADD COLUMN IF NOT EXISTS published_as_component smallint DEFAULT 0;

-- 表: application_component
ALTER TABLE application_component ADD COLUMN IF NOT EXISTS update_description character varying(4096);
ALTER TABLE application_component ADD COLUMN IF NOT EXISTS category_id bigint;

-- 表: application_task_records
ALTER TABLE application_task_records ADD COLUMN IF NOT EXISTS organization_no character varying(64);
ALTER TABLE application_task_records ADD COLUMN IF NOT EXISTS uass_id character varying(64);
ALTER TABLE application_task_records ADD COLUMN IF NOT EXISTS account_id character varying(64);

-- 表: mcp_server
ALTER TABLE mcp_server ADD COLUMN IF NOT EXISTS category_id bigint;

-- 表: model
ALTER TABLE model ADD COLUMN IF NOT EXISTS type_spec character varying(100);
ALTER TABLE model ADD COLUMN IF NOT EXISTS description character varying(500);

-- 表: plugin
ALTER TABLE plugin ADD COLUMN IF NOT EXISTS category_id bigint;

-- 表: skill
-- MySQL: name_active 为 VIRTUAL GENERATED = if(status=1, name, NULL)
-- v3 已有语义等价部分唯一索引：
--   CREATE UNIQUE INDEX uk_skill_tenant_name ON skill (tenant_id, name) WHERE (status = 1);
-- 此处补列供旧查询/对账；用 STORED generated，勿再照搬 MySQL 的 uk_skill_tenant_name(tenant_id, name_active)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = 'skill' AND column_name = 'name_active'
    ) THEN
        ALTER TABLE skill
            ADD COLUMN name_active character varying(128)
            GENERATED ALWAYS AS (CASE WHEN status = 1 THEN name ELSE NULL END) STORED;
    END IF;
END $$;

-- ---------------------------------------------------------------------------
-- 列宽：v2 MySQL 比 v3 PG 更宽，导入会报 value too long
-- application.icon: MySQL varchar(512) / PG varchar(255)；data 中有最长约 347
-- ---------------------------------------------------------------------------
ALTER TABLE application
    ALTER COLUMN icon TYPE character varying(512);

-- ===========================================================================
-- v3 补齐 DDL：共有表索引缺口（MySQL-only 表索引已在上方建表段创建，此处不再重复）
-- 生成时间: 2026-08-20 16:36:00
-- ===========================================================================

-- application_version：v2 KEY idx_code(code)；v3 仅有 idx_av_tenant_code_version
CREATE INDEX IF NOT EXISTS idx_av_code ON application_version (code);

-- skill.uk_skill_tenant_name(tenant_id, name_active)：
--   v3 已用部分唯一索引覆盖同等语义，勿重复创建同名索引：
--   uk_skill_tenant_name ON (tenant_id, name) WHERE status = 1
-- 故此处不 ADD。

-- ===========================================================================
-- v2.3.0 skill origin_*（外源 Hub · 广场目录化）；不改 uk_skill_tenant_name
-- ===========================================================================
ALTER TABLE skill ADD COLUMN IF NOT EXISTS origin_key VARCHAR(64) NOT NULL DEFAULT 'native';
ALTER TABLE skill ADD COLUMN IF NOT EXISTS origin_ref TEXT DEFAULT NULL;

CREATE INDEX IF NOT EXISTS idx_skill_origin_key
  ON skill (tenant_id, origin_key) WHERE status = 1;

COMMENT ON COLUMN skill.origin_key IS
  '供应方: preset=平台预置; native=自建; square=内置广场添加; 其它=Hub originKey。只存不展。不等于 skill.source';
COMMENT ON COLUMN skill.origin_ref IS
  '来源坐标快照 JSON；广场/Hub 添加必写；非选版；不入平台 skill_version；可空（历史行）';

UPDATE skill
   SET origin_key = 'native'
 WHERE origin_key IS NULL OR origin_key = '';

-- 预置技能（source=platform）不是自建；纠正 DEFAULT/空值回填成 native 的误标
UPDATE skill
   SET origin_key = 'preset'
 WHERE source = 'platform';

-- ===========================================================================
-- 组件和草稿态应用关联关系
-- ===========================================================================
CREATE TABLE IF NOT EXISTS reference_draft (
    id              BIGINT GENERATED ALWAYS AS IDENTITY NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    main_code       VARCHAR(128)    NOT NULL,
    main_type       INTEGER         NOT NULL,
    refer_code      VARCHAR(128)    NOT NULL,
    refer_type      INTEGER         NOT NULL,
    tenant_id       VARCHAR(128)    NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_draft_reference UNIQUE (tenant_id, main_code, main_type, refer_code, refer_type)
);

CREATE INDEX IF NOT EXISTS idx_draft_main ON reference_draft (tenant_id, main_code, main_type);
CREATE INDEX IF NOT EXISTS idx_draft_refer ON reference_draft (tenant_id, refer_code, refer_type);

-- 注释
COMMENT ON TABLE reference_draft IS '应用草稿组件引用关系';
COMMENT ON COLUMN reference_draft.id IS '主键';
COMMENT ON COLUMN reference_draft.gmt_create IS '创建时间';
COMMENT ON COLUMN reference_draft.gmt_modified IS '修改时间';
COMMENT ON COLUMN reference_draft.main_code IS '引用方应用编码';
COMMENT ON COLUMN reference_draft.main_type IS '引用方类型：2智能体，3工作流';
COMMENT ON COLUMN reference_draft.refer_code IS '被引用组件编码';
COMMENT ON COLUMN reference_draft.refer_type IS '引用类型：20智能体组件，30工作流组件';
COMMENT ON COLUMN reference_draft.tenant_id IS '租户/工作空间ID';

-- ===========================================================================
-- SkillHub 个人技能分类（幂等，按 type + code 去重）
-- ===========================================================================
INSERT INTO category (name, code, type, description, sort, status, gmt_create, gmt_modified, creator, modifier)
SELECT '个人金融', 'personal-finance', 'skill', 'SkillHub 个人技能分类', 70, 1, NOW(), NOW(), 'admin', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM category WHERE type = 'skill' AND code = 'personal-finance');

INSERT INTO category (name, code, type, description, sort, status, gmt_create, gmt_modified, creator, modifier)
SELECT '综合管理', 'integrated-management', 'skill', 'SkillHub 个人技能分类', 60, 1, NOW(), NOW(), 'admin', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM category WHERE type = 'skill' AND code = 'integrated-management');

INSERT INTO category (name, code, type, description, sort, status, gmt_create, gmt_modified, creator, modifier)
SELECT '办公辅助', 'office-assistance', 'skill', 'SkillHub 个人技能分类', 50, 1, NOW(), NOW(), 'admin', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM category WHERE type = 'skill' AND code = 'office-assistance');

INSERT INTO category (name, code, type, description, sort, status, gmt_create, gmt_modified, creator, modifier)
SELECT '科技渠道', 'technology-channel-operation', 'skill', 'SkillHub 个人技能分类', 40, 1, NOW(), NOW(), 'admin', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM category WHERE type = 'skill' AND code = 'technology-channel-operation');

INSERT INTO category (name, code, type, description, sort, status, gmt_create, gmt_modified, creator, modifier)
SELECT '资金资管', 'asset-management', 'skill', 'SkillHub 个人技能分类', 30, 1, NOW(), NOW(), 'admin', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM category WHERE type = 'skill' AND code = 'asset-management');

INSERT INTO category (name, code, type, description, sort, status, gmt_create, gmt_modified, creator, modifier)
SELECT '风险管理', 'risk-management', 'skill', 'SkillHub 个人技能分类', 20, 1, NOW(), NOW(), 'admin', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM category WHERE type = 'skill' AND code = 'risk-management');

INSERT INTO category (name, code, type, description, sort, status, gmt_create, gmt_modified, creator, modifier)
SELECT '公司金融', 'corporate-finance', 'skill', 'SkillHub 个人技能分类', 10, 1, NOW(), NOW(), 'admin', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM category WHERE type = 'skill' AND code = 'corporate-finance');

-- ===========================================================================
-- Keycloak：7202 补 agentType；admin 补 legacyUserId
-- ===========================================================================
\connect keycloak

INSERT INTO group_attribute (id, name, value, group_id) SELECT gen_random_uuid()::text, 'agentType', 'common', g.id FROM keycloak_group g WHERE g.name = '7202' AND NOT EXISTS (SELECT 1 FROM group_attribute ga WHERE ga.group_id = g.id AND ga.name = 'agentType');
INSERT INTO user_attribute (id, name, value, user_id) SELECT gen_random_uuid()::text, 'legacyUserId', '8002', ue.id FROM user_entity ue WHERE ue.username = 'admin' AND NOT EXISTS (SELECT 1 FROM user_attribute ua WHERE ua.user_id = ue.id AND ua.name = 'legacyUserId');

