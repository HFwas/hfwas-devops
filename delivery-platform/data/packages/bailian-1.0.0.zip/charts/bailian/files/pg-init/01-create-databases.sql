-- ============================================================================
-- Bailian — PostgreSQL 数据库初始化（幂等）
-- ============================================================================

SELECT 'CREATE DATABASE agentscope' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'agentscope')\gexec
SELECT 'CREATE DATABASE beebot_platform' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'beebot_platform')\gexec
SELECT 'CREATE DATABASE pairag' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'pairag')\gexec
SELECT 'CREATE DATABASE kong' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'kong')\gexec
-- Temporal Server 依赖的两个库（schema 由 auto-setup 镜像首次启动时自动建立）
SELECT 'CREATE DATABASE temporal' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'temporal')\gexec
SELECT 'CREATE DATABASE temporal_visibility' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'temporal_visibility')\gexec

GRANT ALL PRIVILEGES ON DATABASE agentscope TO :pg_user;
GRANT ALL PRIVILEGES ON DATABASE beebot_platform TO :pg_user;
GRANT ALL PRIVILEGES ON DATABASE pairag TO :pg_user;
GRANT ALL PRIVILEGES ON DATABASE kong TO :pg_user;
GRANT ALL PRIVILEGES ON DATABASE temporal TO :pg_user;
GRANT ALL PRIVILEGES ON DATABASE temporal_visibility TO :pg_user;

\connect agentscope
GRANT ALL ON SCHEMA public TO :pg_user;

\connect beebot_platform
GRANT ALL ON SCHEMA public TO :pg_user;

\connect pairag
GRANT ALL ON SCHEMA public TO :pg_user;

\connect kong
GRANT ALL ON SCHEMA public TO :pg_user;

\connect temporal
GRANT ALL ON SCHEMA public TO :pg_user;

\connect temporal_visibility
GRANT ALL ON SCHEMA public TO :pg_user;
