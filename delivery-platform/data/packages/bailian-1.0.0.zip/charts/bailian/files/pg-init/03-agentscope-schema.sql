-- =============================================================================
-- AgentScope Database Schema (PostgreSQL 16)
-- Source: docker/agentscope.sql (MySQL 8.0 dump, 27 tables)
-- Conversion: MySQL DDL → PostgreSQL DDL
-- =============================================================================

\connect agentscope

-- ---------------------------------------------------------------------------
-- Shared trigger function for ON UPDATE CURRENT_TIMESTAMP emulation
-- Used by: app_task_event, application_task_records, model, provider
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.gmt_modified = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- 1. account
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS account;
CREATE TABLE account (
    id              BIGSERIAL       NOT NULL,
    account_id      VARCHAR(64)     NOT NULL,
    username        VARCHAR(255)    NOT NULL,
    email           VARCHAR(255)    DEFAULT NULL,
    mobile          VARCHAR(255)    DEFAULT NULL,
    password        VARCHAR(255)    NOT NULL,
    nickname        VARCHAR(255)    DEFAULT NULL,
    icon            VARCHAR(255)    DEFAULT NULL,
    type            VARCHAR(64)     NOT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_last_login  TIMESTAMP       DEFAULT NULL,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_account_id UNIQUE (account_id)
);
CREATE INDEX idx_email_password ON account (username);

COMMENT ON TABLE account IS 'account info';
COMMENT ON COLUMN account.id IS 'pk';
COMMENT ON COLUMN account.account_id IS 'account id';
COMMENT ON COLUMN account.username IS 'account name';
COMMENT ON COLUMN account.email IS 'account email';
COMMENT ON COLUMN account.mobile IS 'account mobile';
COMMENT ON COLUMN account.password IS 'password';
COMMENT ON COLUMN account.nickname IS 'nickname';
COMMENT ON COLUMN account.icon IS 'account icon';
COMMENT ON COLUMN account.type IS 'type: basic, admin';
COMMENT ON COLUMN account.status IS 'status: 0- deleted, 1- normal';
COMMENT ON COLUMN account.gmt_last_login IS 'account last login time';
COMMENT ON COLUMN account.creator IS 'creator uid';
COMMENT ON COLUMN account.modifier IS 'modifier uid';

-- ---------------------------------------------------------------------------
-- 2. api_key
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS api_key;
CREATE TABLE api_key (
    id              BIGSERIAL       NOT NULL,
    account_id      VARCHAR(64)     NOT NULL,
    api_key         VARCHAR(512)    NOT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    description     VARCHAR(4096)   DEFAULT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_api_key UNIQUE (api_key)
);
CREATE INDEX idx_api_key_account_id ON api_key (account_id);

COMMENT ON TABLE api_key IS 'api key info';
COMMENT ON COLUMN api_key.id IS 'pk';
COMMENT ON COLUMN api_key.account_id IS 'uid';
COMMENT ON COLUMN api_key.api_key IS 'api key';
COMMENT ON COLUMN api_key.status IS 'status: 0-deleted, 1-normal';
COMMENT ON COLUMN api_key.description IS 'api key description';
COMMENT ON COLUMN api_key.creator IS 'creator uid';
COMMENT ON COLUMN api_key.modifier IS 'creator uid';

-- ---------------------------------------------------------------------------
-- 3. app_task_event  (ON UPDATE CURRENT_TIMESTAMP → trigger)
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS app_task_event;
CREATE TABLE app_task_event (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    tenant_id       VARCHAR(64)     NOT NULL,
    task_id         VARCHAR(64)     NOT NULL,
    event_type      VARCHAR(64)     DEFAULT NULL,
    event_id        VARCHAR(128)    NOT NULL,
    event_identity  TEXT            DEFAULT NULL,
    event_result    TEXT            DEFAULT NULL,
    status          VARCHAR(20)     NOT NULL,
    remark          VARCHAR(500)    DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_event_ UNIQUE (event_id, event_type)
);
CREATE INDEX idx_ate_tenant_task_id ON app_task_event (tenant_id, task_id);

CREATE TRIGGER trg_app_task_event_update_gmt_modified
    BEFORE UPDATE ON app_task_event
    FOR EACH ROW
    EXECUTE FUNCTION update_modified_column();

COMMENT ON TABLE app_task_event IS '应用任务记录事件管理表';
COMMENT ON COLUMN app_task_event.id IS '主键ID';
COMMENT ON COLUMN app_task_event.gmt_create IS '创建时间';
COMMENT ON COLUMN app_task_event.gmt_modified IS '修改时间';
COMMENT ON COLUMN app_task_event.tenant_id IS '租户id';
COMMENT ON COLUMN app_task_event.task_id IS '任务ID';
COMMENT ON COLUMN app_task_event.event_type IS '事件类型';
COMMENT ON COLUMN app_task_event.event_id IS '异步任务id';
COMMENT ON COLUMN app_task_event.event_identity IS '事件主体';
COMMENT ON COLUMN app_task_event.event_result IS '事件结果，存储JSON字符串';
COMMENT ON COLUMN app_task_event.status IS '事件状态：WAITING、COMPLETED、TIMEOUT';
COMMENT ON COLUMN app_task_event.remark IS '备注信息';

-- ---------------------------------------------------------------------------
-- 4. application
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS application;
CREATE TABLE application (
    id                          BIGSERIAL       NOT NULL,
    tenant_id                   VARCHAR(64)     NOT NULL,
    code                        VARCHAR(64)     NOT NULL,
    name                        VARCHAR(255)    NOT NULL,
    description                 VARCHAR(4096)   DEFAULT NULL,
    icon                        VARCHAR(255)    DEFAULT NULL,
    source                      VARCHAR(64)     NOT NULL,
    type                        SMALLINT        NOT NULL,
    sub_type                    VARCHAR(64)     NOT NULL,
    status                      SMALLINT        NOT NULL,
    gmt_create                  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified                TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator                     VARCHAR(64)     NOT NULL,
    modifier                    VARCHAR(64)     NOT NULL,
    telemetry_status            SMALLINT        NOT NULL DEFAULT 0,
    history_telemetry_status    SMALLINT        NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    CONSTRAINT uk_code UNIQUE (code)
);
CREATE INDEX idx_app_tenant_type ON application (tenant_id, type);

COMMENT ON TABLE application IS 'app info';
COMMENT ON COLUMN application.id IS 'pk';
COMMENT ON COLUMN application.tenant_id IS 'tenant_id';
COMMENT ON COLUMN application.code IS 'app code';
COMMENT ON COLUMN application.name IS 'app name';
COMMENT ON COLUMN application.description IS 'app description';
COMMENT ON COLUMN application.icon IS 'app icon';
COMMENT ON COLUMN application.source IS 'app source';
COMMENT ON COLUMN application.type IS '5-agent; 7-workflow';
COMMENT ON COLUMN application.sub_type IS 'agent: base_agent;';
COMMENT ON COLUMN application.status IS '1-published; 2-deleted; 3-draft; 4-published_editing';
COMMENT ON COLUMN application.creator IS '创建者uid';
COMMENT ON COLUMN application.modifier IS '修改者uid';
COMMENT ON COLUMN application.telemetry_status IS '0-disable,1-enable';
COMMENT ON COLUMN application.history_telemetry_status IS '0-disable,1-enable';

-- ---------------------------------------------------------------------------
-- 5. application_component
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS application_component;
CREATE TABLE application_component (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    code            VARCHAR(64)     NOT NULL,
    name            VARCHAR(128)    NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    type            VARCHAR(64)     NOT NULL,
    app_id          VARCHAR(64)     DEFAULT NULL,
    config          TEXT            DEFAULT NULL,
    description     VARCHAR(4096)   DEFAULT NULL,
    status          SMALLINT        DEFAULT NULL,
    creator         VARCHAR(64)     DEFAULT NULL,
    modifier        VARCHAR(64)     DEFAULT NULL,
    need_update     SMALLINT        DEFAULT NULL,
    PRIMARY KEY (id)
);
CREATE INDEX idx_ac_tenant_type_status_appcode ON application_component (tenant_id, type, app_id);

COMMENT ON TABLE application_component IS 'app component info';
COMMENT ON COLUMN application_component.id IS 'pk';
COMMENT ON COLUMN application_component.gmt_create IS 'create time';
COMMENT ON COLUMN application_component.gmt_modified IS 'modified time';
COMMENT ON COLUMN application_component.code IS 'component code';
COMMENT ON COLUMN application_component.name IS 'name';
COMMENT ON COLUMN application_component.tenant_id IS 'tenant id';
COMMENT ON COLUMN application_component.type IS 'type, agent, workflow';
COMMENT ON COLUMN application_component.config IS 'component config';
COMMENT ON COLUMN application_component.description IS 'description';
COMMENT ON COLUMN application_component.status IS 'status：0-deleted, 1, normal, 2-published';
COMMENT ON COLUMN application_component.creator IS 'creator uid';
COMMENT ON COLUMN application_component.modifier IS 'modifier uid';
COMMENT ON COLUMN application_component.need_update IS '0-no need update, 1-need update';

-- ---------------------------------------------------------------------------
-- 6. application_task_records  (ON UPDATE CURRENT_TIMESTAMP → trigger)
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS application_task_records;
CREATE TABLE application_task_records (
    id                  BIGSERIAL       NOT NULL,
    tenant_id           VARCHAR(64)     NOT NULL,
    gmt_create          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified        TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    batch_task_id       VARCHAR(64)     DEFAULT NULL,
    task_id             VARCHAR(64)     NOT NULL,
    task_type           VARCHAR(64)     NOT NULL,
    task_source_type    VARCHAR(64)     NOT NULL,
    task_status         VARCHAR(64)     NOT NULL,
    task_output         TEXT            DEFAULT NULL,
    task_duration       BIGINT          DEFAULT NULL,
    task_start_time     TIMESTAMP       DEFAULT NULL,
    task_complete_time  TIMESTAMP       DEFAULT NULL,
    app_id              VARCHAR(64)     NOT NULL,
    app_type            VARCHAR(64)     NOT NULL,
    app_config_version  BIGINT          DEFAULT NULL,
    task_input          TEXT            DEFAULT NULL,
    PRIMARY KEY (id)
);
CREATE INDEX idx_atr_task_id ON application_task_records (task_id);
CREATE INDEX idx_atr_batch_task_id ON application_task_records (batch_task_id);
CREATE INDEX idx_atr_app_id ON application_task_records (app_id);
CREATE INDEX idx_atr_task_status ON application_task_records (task_status);
CREATE INDEX idx_atr_task_start_time ON application_task_records (task_start_time);
CREATE INDEX idx_atr_tenant_id ON application_task_records (tenant_id);

CREATE TRIGGER trg_application_task_records_update_gmt_modified
    BEFORE UPDATE ON application_task_records
    FOR EACH ROW
    EXECUTE FUNCTION update_modified_column();

COMMENT ON TABLE application_task_records IS 'application task execution records';
COMMENT ON COLUMN application_task_records.id IS 'pk';
COMMENT ON COLUMN application_task_records.tenant_id IS 'tenant id';
COMMENT ON COLUMN application_task_records.gmt_create IS 'create time';
COMMENT ON COLUMN application_task_records.gmt_modified IS 'modified time';
COMMENT ON COLUMN application_task_records.batch_task_id IS 'batch task identifier';
COMMENT ON COLUMN application_task_records.task_id IS 'task identifier';
COMMENT ON COLUMN application_task_records.task_type IS 'task type (async, sync, batch)';
COMMENT ON COLUMN application_task_records.task_source_type IS 'task source type (console, api)';
COMMENT ON COLUMN application_task_records.task_status IS 'task status';
COMMENT ON COLUMN application_task_records.task_output IS 'task output';
COMMENT ON COLUMN application_task_records.task_duration IS 'task duration in milliseconds';
COMMENT ON COLUMN application_task_records.task_start_time IS 'task start execution time';
COMMENT ON COLUMN application_task_records.task_complete_time IS 'task completion time';
COMMENT ON COLUMN application_task_records.app_id IS 'application identifier';
COMMENT ON COLUMN application_task_records.app_type IS 'application type (agent, workflow)';
COMMENT ON COLUMN application_task_records.app_config_version IS 'application configuration version';
COMMENT ON COLUMN application_task_records.task_input IS 'task input parameters';

-- ---------------------------------------------------------------------------
-- 7. application_version
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS application_version;
CREATE TABLE application_version (
    id              BIGSERIAL       NOT NULL,
    code            VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    config          TEXT            DEFAULT NULL,
    status          SMALLINT        NOT NULL,
    version         BIGINT          NOT NULL,
    description     VARCHAR(4096)   DEFAULT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id)
);
CREATE INDEX idx_av_tenant_code_version ON application_version (tenant_id, code, version);

COMMENT ON TABLE application_version IS 'app version info';
COMMENT ON COLUMN application_version.id IS 'pk';
COMMENT ON COLUMN application_version.code IS 'app code';
COMMENT ON COLUMN application_version.tenant_id IS 'tenant id';
COMMENT ON COLUMN application_version.config IS 'app config';
COMMENT ON COLUMN application_version.status IS 'status, 0-deleted 1-draft; 2-published; 3-publishedEditing';
COMMENT ON COLUMN application_version.version IS 'version number';
COMMENT ON COLUMN application_version.description IS 'version description';
COMMENT ON COLUMN application_version.creator IS 'creator uid';
COMMENT ON COLUMN application_version.modifier IS 'modifier uid';

-- ---------------------------------------------------------------------------
-- 8. document
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS document;
CREATE TABLE document (
    id              BIGSERIAL       NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    kb_id           VARCHAR(64)     NOT NULL,
    doc_id          VARCHAR(64)     NOT NULL,
    type            VARCHAR(64)     NOT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    enabled         SMALLINT        NOT NULL DEFAULT 1,
    name            VARCHAR(255)    NOT NULL,
    format          VARCHAR(64)     NOT NULL,
    size            BIGINT          NOT NULL DEFAULT 0,
    metadata        TEXT            DEFAULT NULL,
    index_status    SMALLINT        NOT NULL DEFAULT 1,
    path            VARCHAR(512)    NOT NULL,
    parsed_path     VARCHAR(512)    DEFAULT NULL,
    process_config  TEXT            DEFAULT NULL,
    source          VARCHAR(255)    DEFAULT NULL,
    error           TEXT            DEFAULT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_document_id UNIQUE (doc_id)
);
CREATE INDEX idx_doc_tenant_kb ON document (tenant_id, kb_id);

COMMENT ON TABLE document IS 'document info';
COMMENT ON COLUMN document.id IS 'pk';
COMMENT ON COLUMN document.tenant_id IS 'tenant id';
COMMENT ON COLUMN document.kb_id IS 'knowledge base id';
COMMENT ON COLUMN document.doc_id IS 'document id';
COMMENT ON COLUMN document.type IS 'type: file, url';
COMMENT ON COLUMN document.status IS 'status: 0-deleted, 1-normal';
COMMENT ON COLUMN document.enabled IS 'enabled: 0-disabled, 1-enabled';
COMMENT ON COLUMN document.name IS 'document name';
COMMENT ON COLUMN document.format IS 'document format';
COMMENT ON COLUMN document.size IS 'document size';
COMMENT ON COLUMN document.metadata IS 'document metadata';
COMMENT ON COLUMN document.index_status IS 'Index status: 1: pending, 2: processing, 3: completed';
COMMENT ON COLUMN document.path IS 'storage path';
COMMENT ON COLUMN document.parsed_path IS 'parsed path';
COMMENT ON COLUMN document.process_config IS 'document chunk config';
COMMENT ON COLUMN document.source IS 'doc source';
COMMENT ON COLUMN document.creator IS 'creator uid';
COMMENT ON COLUMN document.modifier IS 'modifier uid';

-- ---------------------------------------------------------------------------
-- 9. eval_annotation
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_annotation;
CREATE TABLE eval_annotation (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    uid             VARCHAR(64)     NOT NULL,
    workspace_id    VARCHAR(64)     NOT NULL,
    annotation_id   VARCHAR(64)     NOT NULL,
    name            VARCHAR(128)    NOT NULL,
    description     VARCHAR(512)    DEFAULT NULL,
    source          VARCHAR(64)     NOT NULL,
    status          VARCHAR(64)     NOT NULL,
    value_type      VARCHAR(64)     NOT NULL,
    value_list      TEXT            DEFAULT NULL,
    value_config    TEXT            DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_annotation_id UNIQUE (annotation_id)
);
CREATE INDEX idx_ea_uid ON eval_annotation (uid);
CREATE INDEX idx_ea_workspace_id ON eval_annotation (workspace_id);

COMMENT ON TABLE eval_annotation IS '评测标签表';
COMMENT ON COLUMN eval_annotation.id IS '主键，自增ID';
COMMENT ON COLUMN eval_annotation.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_annotation.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_annotation.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_annotation.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_annotation.annotation_id IS '标签ID';
COMMENT ON COLUMN eval_annotation.name IS '标签名称';
COMMENT ON COLUMN eval_annotation.description IS '标签描述';
COMMENT ON COLUMN eval_annotation.source IS '标签来源';
COMMENT ON COLUMN eval_annotation.status IS '标签状态';
COMMENT ON COLUMN eval_annotation.value_type IS '标签值类型';
COMMENT ON COLUMN eval_annotation.value_list IS '标签枚举值列表';
COMMENT ON COLUMN eval_annotation.value_config IS '标签值配置';

-- ---------------------------------------------------------------------------
-- 10. eval_data_item
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_data_item;
CREATE TABLE eval_data_item (
    id                      BIGSERIAL       NOT NULL,
    gmt_create              TIMESTAMP       NOT NULL,
    gmt_modified            TIMESTAMP       NOT NULL,
    uid                     VARCHAR(64)     NOT NULL,
    workspace_id            VARCHAR(64)     NOT NULL,
    eval_data_item_id       VARCHAR(64)     NOT NULL,
    eval_task_id            VARCHAR(64)     NOT NULL,
    eval_set_id             VARCHAR(64)     NOT NULL,
    eval_set_version_id     VARCHAR(64)     NOT NULL,
    eval_set_item_id        VARCHAR(64)     NOT NULL,
    fields                  TEXT            DEFAULT NULL,
    deleted                 BOOLEAN         NOT NULL DEFAULT FALSE,
    PRIMARY KEY (id),
    CONSTRAINT uk_eval_data_item_id UNIQUE (eval_data_item_id)
);
CREATE INDEX idx_edi_uid ON eval_data_item (uid);
CREATE INDEX idx_edi_workspace_id ON eval_data_item (workspace_id);
CREATE INDEX idx_edi_eval_task_id_eval_set_version_id ON eval_data_item (eval_task_id, eval_set_version_id);

COMMENT ON TABLE eval_data_item IS '评测数据项表';
COMMENT ON COLUMN eval_data_item.id IS '主键，自增ID';
COMMENT ON COLUMN eval_data_item.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_data_item.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_data_item.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_data_item.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_data_item.eval_data_item_id IS '任务的评测集数据项的唯一标识';
COMMENT ON COLUMN eval_data_item.eval_task_id IS '评测任务ID';
COMMENT ON COLUMN eval_data_item.eval_set_id IS '评测集ID';
COMMENT ON COLUMN eval_data_item.eval_set_version_id IS '评测集版本ID';
COMMENT ON COLUMN eval_data_item.eval_set_item_id IS '关联的评测集数据项ID';
COMMENT ON COLUMN eval_data_item.fields IS '字段值（JSON字符串）';
COMMENT ON COLUMN eval_data_item.deleted IS '是否删除';

-- ---------------------------------------------------------------------------
-- 11. eval_message
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_message;
CREATE TABLE eval_message (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    message_id      VARCHAR(32)     NOT NULL,
    topic           VARCHAR(128)    NOT NULL,
    tag             VARCHAR(128)    DEFAULT NULL,
    content         VARCHAR(2048)   NOT NULL,
    status          VARCHAR(16)     NOT NULL,
    deliver_time    BIGINT          NOT NULL,
    properties      VARCHAR(2048)   DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_message_id UNIQUE (message_id)
);
CREATE INDEX idx_em_topic_tag ON eval_message (topic, tag);
CREATE INDEX idx_em_status ON eval_message (status);
CREATE INDEX idx_em_deliver_time ON eval_message (deliver_time);

COMMENT ON TABLE eval_message IS '消息队列表';
COMMENT ON COLUMN eval_message.id IS '主键';
COMMENT ON COLUMN eval_message.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_message.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_message.message_id IS '消息ID';
COMMENT ON COLUMN eval_message.topic IS '消息Topic';
COMMENT ON COLUMN eval_message.tag IS '消息Tag';
COMMENT ON COLUMN eval_message.content IS '消息内容';
COMMENT ON COLUMN eval_message.status IS '消息状态';
COMMENT ON COLUMN eval_message.deliver_time IS '消息投递时间';
COMMENT ON COLUMN eval_message.properties IS '扩展属性';

-- ---------------------------------------------------------------------------
-- 12. eval_output_item
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_output_item;
CREATE TABLE eval_output_item (
    id                      BIGSERIAL       NOT NULL,
    gmt_create              TIMESTAMP       NOT NULL,
    gmt_modified            TIMESTAMP       NOT NULL,
    uid                     VARCHAR(64)     NOT NULL,
    workspace_id            VARCHAR(64)     NOT NULL,
    eval_output_item_id     VARCHAR(64)     NOT NULL,
    eval_task_id            VARCHAR(64)     NOT NULL,
    eval_target_id          VARCHAR(64)     NOT NULL,
    eval_data_item_id       VARCHAR(64)     NOT NULL,
    status                  VARCHAR(64)     NOT NULL,
    config                  TEXT            DEFAULT NULL,
    grader_status           VARCHAR(64)     DEFAULT NULL,
    annotation_status       VARCHAR(64)     DEFAULT NULL,
    raw_result              TEXT            DEFAULT NULL,
    deleted                 BOOLEAN         NOT NULL DEFAULT FALSE,
    content                 TEXT            DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_eval_output_item_id UNIQUE (eval_output_item_id)
);
CREATE INDEX idx_eoi_uid ON eval_output_item (uid);
CREATE INDEX idx_eoi_workspace_id ON eval_output_item (workspace_id);
CREATE INDEX idx_eoi_eval_task_id_eval_target_id ON eval_output_item (eval_task_id, eval_target_id);

COMMENT ON TABLE eval_output_item IS '推理结果数据项表';
COMMENT ON COLUMN eval_output_item.id IS '主键，自增ID';
COMMENT ON COLUMN eval_output_item.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_output_item.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_output_item.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_output_item.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_output_item.eval_output_item_id IS '任务的推理结果数据项的唯一标识';
COMMENT ON COLUMN eval_output_item.eval_task_id IS '评测任务ID';
COMMENT ON COLUMN eval_output_item.eval_target_id IS '评测对象ID';
COMMENT ON COLUMN eval_output_item.eval_data_item_id IS '评测数据项ID';
COMMENT ON COLUMN eval_output_item.status IS '推理运行状态';
COMMENT ON COLUMN eval_output_item.config IS '推理结果数据项的配置（JSON字符串）';
COMMENT ON COLUMN eval_output_item.grader_status IS '自动评测状态';
COMMENT ON COLUMN eval_output_item.annotation_status IS '人工标注状态';
COMMENT ON COLUMN eval_output_item.raw_result IS '推理完整结果（JSON字符串）';
COMMENT ON COLUMN eval_output_item.deleted IS '是否删除';
COMMENT ON COLUMN eval_output_item.content IS '推理结果文本';

-- ---------------------------------------------------------------------------
-- 13. eval_result_item
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_result_item;
CREATE TABLE eval_result_item (
    id                      BIGSERIAL       NOT NULL,
    gmt_create              TIMESTAMP       NOT NULL,
    gmt_modified            TIMESTAMP       NOT NULL,
    uid                     VARCHAR(64)     NOT NULL,
    workspace_id            VARCHAR(64)     NOT NULL,
    eval_result_item_id     VARCHAR(64)     NOT NULL,
    eval_output_item_id     VARCHAR(64)     NOT NULL,
    evaluator_type          VARCHAR(64)     NOT NULL,
    evaluator_id            VARCHAR(64)     NOT NULL,
    eval_task_id            VARCHAR(64)     NOT NULL,
    eval_target_id          VARCHAR(64)     NOT NULL,
    status                  VARCHAR(64)     NOT NULL,
    raw_result              TEXT            DEFAULT NULL,
    reason                  VARCHAR(512)    DEFAULT NULL,
    passed                  BOOLEAN         DEFAULT NULL,
    number_result           DOUBLE PRECISION DEFAULT NULL,
    text_result             VARCHAR(1024)   DEFAULT NULL,
    ext_key                 VARCHAR(128)    DEFAULT NULL,
    config                  TEXT            DEFAULT NULL,
    deleted                 BOOLEAN         NOT NULL DEFAULT FALSE,
    PRIMARY KEY (id),
    CONSTRAINT uk_eval_result_item_id UNIQUE (eval_result_item_id)
);
CREATE INDEX idx_eri_uid ON eval_result_item (uid);
CREATE INDEX idx_eri_workspace_id ON eval_result_item (workspace_id);
CREATE INDEX idx_eri_eval_task_id_eval_target_id_evaluator_id ON eval_result_item (eval_task_id, eval_target_id, evaluator_id);

COMMENT ON TABLE eval_result_item IS '评测结果数据项表';
COMMENT ON COLUMN eval_result_item.id IS '主键，自增ID';
COMMENT ON COLUMN eval_result_item.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_result_item.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_result_item.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_result_item.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_result_item.eval_result_item_id IS '任务的评测结果数据项的唯一标识';
COMMENT ON COLUMN eval_result_item.eval_output_item_id IS '任务的推理结果数据项的唯一标识';
COMMENT ON COLUMN eval_result_item.evaluator_type IS '评估器类型';
COMMENT ON COLUMN eval_result_item.evaluator_id IS '评估器ID：grader_id 或 annotation_id';
COMMENT ON COLUMN eval_result_item.eval_task_id IS '评测任务ID';
COMMENT ON COLUMN eval_result_item.eval_target_id IS '评测对象ID';
COMMENT ON COLUMN eval_result_item.status IS '评测结果状态';
COMMENT ON COLUMN eval_result_item.raw_result IS '评测完整结果（JSON字符串）';
COMMENT ON COLUMN eval_result_item.reason IS '评分原因';
COMMENT ON COLUMN eval_result_item.passed IS '是否通过';
COMMENT ON COLUMN eval_result_item.number_result IS '数值型结果';
COMMENT ON COLUMN eval_result_item.text_result IS '文本型结果';
COMMENT ON COLUMN eval_result_item.ext_key IS '拓展key（可用于存储错误归因等需要检索的结果）';
COMMENT ON COLUMN eval_result_item.config IS '扩展配置（JSON字符串）';
COMMENT ON COLUMN eval_result_item.deleted IS '是否删除';

-- ---------------------------------------------------------------------------
-- 14. eval_set
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_set;
CREATE TABLE eval_set (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    uid             VARCHAR(64)     NOT NULL,
    workspace_id    VARCHAR(64)     NOT NULL,
    eval_set_id     VARCHAR(64)     NOT NULL,
    name            VARCHAR(128)    NOT NULL,
    description     VARCHAR(512)    DEFAULT NULL,
    type            VARCHAR(64)     NOT NULL,
    field_schemas   TEXT            DEFAULT NULL,
    extras          TEXT            DEFAULT NULL,
    deleted         BOOLEAN         NOT NULL DEFAULT FALSE,
    PRIMARY KEY (id),
    CONSTRAINT uk_eval_set_id UNIQUE (eval_set_id)
);
CREATE INDEX idx_es_uid ON eval_set (uid);
CREATE INDEX idx_es_workspace_id ON eval_set (workspace_id);

COMMENT ON TABLE eval_set IS '评测集表';
COMMENT ON COLUMN eval_set.id IS '主键，自增ID';
COMMENT ON COLUMN eval_set.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_set.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_set.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_set.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_set.eval_set_id IS '评测集唯一标识';
COMMENT ON COLUMN eval_set.name IS '评测集名称';
COMMENT ON COLUMN eval_set.description IS '评测集描述';
COMMENT ON COLUMN eval_set.type IS '评测集类型';
COMMENT ON COLUMN eval_set.field_schemas IS '评测集字段定义（JSON字符串）';
COMMENT ON COLUMN eval_set.extras IS '评测集扩展信息（非评测集元数据，通过其他途径获取/计算）（JSON字符串）';
COMMENT ON COLUMN eval_set.deleted IS '是否删除';

-- ---------------------------------------------------------------------------
-- 15. eval_set_task
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_set_task;
CREATE TABLE eval_set_task (
    id                      BIGSERIAL       NOT NULL,
    gmt_create              TIMESTAMP       NOT NULL,
    gmt_modified            TIMESTAMP       NOT NULL,
    uid                     VARCHAR(64)     NOT NULL,
    workspace_id            VARCHAR(64)     NOT NULL,
    eval_set_id             VARCHAR(64)     NOT NULL,
    eval_set_version_id     VARCHAR(64)     NOT NULL,
    task_id                 VARCHAR(64)     NOT NULL,
    type                    VARCHAR(64)     NOT NULL,
    status                  VARCHAR(64)     NOT NULL,
    result                  TEXT            DEFAULT NULL,
    config                  TEXT            DEFAULT NULL,
    deleted                 BOOLEAN         NOT NULL DEFAULT FALSE,
    heartbeat               TIMESTAMP       DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_est_task_id UNIQUE (task_id)
);
CREATE INDEX idx_est_uid ON eval_set_task (uid);
CREATE INDEX idx_est_eval_set_version_id ON eval_set_task (eval_set_version_id);
CREATE INDEX idx_est_type ON eval_set_task (type);
CREATE INDEX idx_est_status ON eval_set_task (status);

COMMENT ON TABLE eval_set_task IS '评测集任务表';
COMMENT ON COLUMN eval_set_task.id IS '主键';
COMMENT ON COLUMN eval_set_task.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_set_task.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_set_task.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_set_task.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_set_task.eval_set_id IS '评测集ID';
COMMENT ON COLUMN eval_set_task.eval_set_version_id IS '版本评测集ID';
COMMENT ON COLUMN eval_set_task.task_id IS '任务ID';
COMMENT ON COLUMN eval_set_task.type IS '评测集任务类型';
COMMENT ON COLUMN eval_set_task.status IS '评测集任务状态';
COMMENT ON COLUMN eval_set_task.result IS '评测集任务配置（JSON字符串）';
COMMENT ON COLUMN eval_set_task.config IS '评测集任务结果（JSON字符串）';
COMMENT ON COLUMN eval_set_task.deleted IS '是否删除';
COMMENT ON COLUMN eval_set_task.heartbeat IS '心跳时间';

-- ---------------------------------------------------------------------------
-- 16. eval_set_version
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_set_version;
CREATE TABLE eval_set_version (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    uid             VARCHAR(64)     NOT NULL,
    workspace_id    VARCHAR(64)     NOT NULL,
    eval_set_id     VARCHAR(64)     NOT NULL,
    version_id      VARCHAR(64)     NOT NULL,
    version         VARCHAR(64)     NOT NULL,
    description     VARCHAR(512)    DEFAULT NULL,
    status          VARCHAR(64)     NOT NULL,
    field_schemas   TEXT            DEFAULT NULL,
    extras          TEXT            DEFAULT NULL,
    deleted         BOOLEAN         NOT NULL DEFAULT FALSE,
    PRIMARY KEY (id),
    CONSTRAINT uk_version_id UNIQUE (version_id)
);
CREATE INDEX idx_esv_uid ON eval_set_version (uid);
CREATE INDEX idx_esv_workspace_id ON eval_set_version (workspace_id);
CREATE INDEX idx_esv_eval_set_id ON eval_set_version (eval_set_id);

COMMENT ON TABLE eval_set_version IS '评测集版本表';
COMMENT ON COLUMN eval_set_version.id IS '主键，自增ID';
COMMENT ON COLUMN eval_set_version.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_set_version.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_set_version.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_set_version.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_set_version.eval_set_id IS '评测集ID';
COMMENT ON COLUMN eval_set_version.version_id IS '版本ID';
COMMENT ON COLUMN eval_set_version.version IS '版本号, e.g. V1';
COMMENT ON COLUMN eval_set_version.description IS '版本描述';
COMMENT ON COLUMN eval_set_version.status IS '版本状态';
COMMENT ON COLUMN eval_set_version.field_schemas IS '版本评测集字段定义（JSON字符串）';
COMMENT ON COLUMN eval_set_version.extras IS '评测集扩展信息（非评测集元数据，通过其他途径获取/计算）（JSON字符串）';
COMMENT ON COLUMN eval_set_version.deleted IS '是否删除';

-- ---------------------------------------------------------------------------
-- 17. eval_target
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_target;
CREATE TABLE eval_target (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    uid             VARCHAR(64)     NOT NULL,
    workspace_id    VARCHAR(64)     NOT NULL,
    eval_target_id  VARCHAR(64)     NOT NULL,
    type            VARCHAR(64)     NOT NULL,
    config          TEXT            DEFAULT NULL,
    deleted         BOOLEAN         NOT NULL DEFAULT FALSE,
    PRIMARY KEY (id),
    CONSTRAINT uk_eval_target_id UNIQUE (eval_target_id)
);
CREATE INDEX idx_et_uid ON eval_target (uid);
CREATE INDEX idx_et_workspace_id ON eval_target (workspace_id);

COMMENT ON TABLE eval_target IS '评测对象表';
COMMENT ON COLUMN eval_target.id IS '主键，自增ID';
COMMENT ON COLUMN eval_target.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_target.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_target.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_target.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_target.eval_target_id IS '评测对象唯一标识';
COMMENT ON COLUMN eval_target.type IS '评测对象类型';
COMMENT ON COLUMN eval_target.config IS '评测对象配置（JSON字符串）';
COMMENT ON COLUMN eval_target.deleted IS '是否删除';

-- ---------------------------------------------------------------------------
-- 18. eval_task
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS eval_task;
CREATE TABLE eval_task (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    uid             VARCHAR(64)     NOT NULL,
    workspace_id    VARCHAR(64)     NOT NULL,
    eval_task_id    VARCHAR(64)     NOT NULL,
    name            VARCHAR(128)    NOT NULL,
    description     VARCHAR(512)    DEFAULT NULL,
    type            VARCHAR(64)     NOT NULL,
    status          VARCHAR(64)     NOT NULL,
    source          VARCHAR(64)     NOT NULL,
    task_config     TEXT            DEFAULT NULL,
    error           TEXT            DEFAULT NULL,
    heartbeat       TIMESTAMP       DEFAULT NULL,
    deleted         BOOLEAN         NOT NULL DEFAULT FALSE,
    PRIMARY KEY (id),
    CONSTRAINT uk_eval_task_id UNIQUE (eval_task_id)
);
CREATE INDEX idx_etk_uid ON eval_task (uid);
CREATE INDEX idx_etk_workspace_id ON eval_task (workspace_id);
CREATE INDEX idx_etk_status ON eval_task (status);
CREATE INDEX idx_etk_type ON eval_task (type);

COMMENT ON TABLE eval_task IS '评测任务表';
COMMENT ON COLUMN eval_task.id IS '主键，自增ID';
COMMENT ON COLUMN eval_task.gmt_create IS '创建时间';
COMMENT ON COLUMN eval_task.gmt_modified IS '修改时间';
COMMENT ON COLUMN eval_task.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN eval_task.workspace_id IS '业务空间ID';
COMMENT ON COLUMN eval_task.eval_task_id IS '评测任务唯一标识';
COMMENT ON COLUMN eval_task.name IS '评测任务名称';
COMMENT ON COLUMN eval_task.description IS '评测任务描述';
COMMENT ON COLUMN eval_task.type IS '评测任务类型';
COMMENT ON COLUMN eval_task.status IS '评测任务状态';
COMMENT ON COLUMN eval_task.source IS '评测任务来源';
COMMENT ON COLUMN eval_task.task_config IS '评测任务配置（JSON字符串）';
COMMENT ON COLUMN eval_task.error IS '错误信息（JSON字符串）';
COMMENT ON COLUMN eval_task.heartbeat IS '心跳时间';
COMMENT ON COLUMN eval_task.deleted IS '是否删除';

-- ---------------------------------------------------------------------------
-- 19. knowledge_base
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS knowledge_base;
CREATE TABLE knowledge_base (
    id              BIGSERIAL       NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    kb_id           VARCHAR(64)     NOT NULL,
    type            VARCHAR(64)     NOT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    name            VARCHAR(255)    NOT NULL,
    description     VARCHAR(4096)   DEFAULT NULL,
    process_config  TEXT            DEFAULT NULL,
    index_config    TEXT            DEFAULT NULL,
    search_config   TEXT            DEFAULT NULL,
    total_docs      BIGINT          NOT NULL DEFAULT 0,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_kb_id UNIQUE (kb_id)
);
CREATE INDEX idx_kb_tenant_status_name ON knowledge_base (tenant_id);

COMMENT ON TABLE knowledge_base IS 'knowledge base info';
COMMENT ON COLUMN knowledge_base.id IS 'pk';
COMMENT ON COLUMN knowledge_base.tenant_id IS 'tenant id';
COMMENT ON COLUMN knowledge_base.kb_id IS 'knowledge base id';
COMMENT ON COLUMN knowledge_base.type IS 'unstructured';
COMMENT ON COLUMN knowledge_base.status IS 'status: 0-deleted, 1-normal';
COMMENT ON COLUMN knowledge_base.name IS 'knowledge base name';
COMMENT ON COLUMN knowledge_base.description IS 'knowledge base description';
COMMENT ON COLUMN knowledge_base.process_config IS 'process config';
COMMENT ON COLUMN knowledge_base.index_config IS 'index config';
COMMENT ON COLUMN knowledge_base.search_config IS 'search config';
COMMENT ON COLUMN knowledge_base.total_docs IS 'total docs count';
COMMENT ON COLUMN knowledge_base.creator IS 'creator uid';
COMMENT ON COLUMN knowledge_base.modifier IS 'modifier uid';

-- ---------------------------------------------------------------------------
-- 20. mcp_server
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS mcp_server;
CREATE TABLE mcp_server (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    server_code     VARCHAR(64)     NOT NULL,
    name            VARCHAR(64)     NOT NULL,
    description     VARCHAR(1024)   DEFAULT NULL,
    source          VARCHAR(128)    DEFAULT NULL,
    deploy_env      VARCHAR(16)     DEFAULT NULL,
    type            VARCHAR(32)     NOT NULL,
    deploy_config   TEXT            NOT NULL,
    tenant_id       VARCHAR(64)     DEFAULT NULL,
    account_id      VARCHAR(64)     DEFAULT NULL,
    status          SMALLINT        NOT NULL,
    biz_type        VARCHAR(512)    DEFAULT NULL,
    detail_config   TEXT            DEFAULT NULL,
    host            VARCHAR(1024)   DEFAULT NULL,
    install_type    VARCHAR(32)     DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_mcp_code UNIQUE (server_code)
);
CREATE INDEX idx_mcp_code ON mcp_server (server_code);
CREATE INDEX idx_mcp_server_name ON mcp_server (name);
CREATE INDEX idx_mcp_name_status ON mcp_server (status, name);
CREATE INDEX idx_mcp_type ON mcp_server (type);

COMMENT ON TABLE mcp_server IS 'mcp server info';
COMMENT ON COLUMN mcp_server.id IS 'pk';
COMMENT ON COLUMN mcp_server.gmt_create IS 'create time';
COMMENT ON COLUMN mcp_server.gmt_modified IS 'modified time';
COMMENT ON COLUMN mcp_server.server_code IS 'server code';
COMMENT ON COLUMN mcp_server.name IS 'server name';
COMMENT ON COLUMN mcp_server.description IS 'description';
COMMENT ON COLUMN mcp_server.source IS 'server source';
COMMENT ON COLUMN mcp_server.deploy_env IS 'deploy environment local/remote';
COMMENT ON COLUMN mcp_server.type IS 'server type OFFICIAL/CUSTOMER';
COMMENT ON COLUMN mcp_server.deploy_config IS 'deploy config';
COMMENT ON COLUMN mcp_server.tenant_id IS 'tenant id';
COMMENT ON COLUMN mcp_server.account_id IS 'uid';
COMMENT ON COLUMN mcp_server.status IS 'status 0 unable 1 normal 3 deleted';
COMMENT ON COLUMN mcp_server.biz_type IS 'biz type';
COMMENT ON COLUMN mcp_server.detail_config IS 'server detail';
COMMENT ON COLUMN mcp_server.host IS 'host address';
COMMENT ON COLUMN mcp_server.install_type IS 'install_type npx/uvx/sse';

-- ---------------------------------------------------------------------------
-- 21. model  (ON UPDATE CURRENT_TIMESTAMP → trigger)
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS model;
CREATE TABLE model (
    id                  BIGSERIAL       NOT NULL,
    tenant_id           VARCHAR(64)     DEFAULT NULL,
    icon                VARCHAR(255)    DEFAULT NULL,
    name                VARCHAR(100)    DEFAULT NULL,
    type                VARCHAR(100)    DEFAULT 'LLM',
    type_spec           VARCHAR(100)    DEFAULT NULL,
    mode                VARCHAR(100)    DEFAULT 'chat',
    model_id            VARCHAR(100)    NOT NULL,
    provider            VARCHAR(100)    NOT NULL,
    enable              BOOLEAN         DEFAULT TRUE,
    tags                VARCHAR(255)    DEFAULT NULL,
    source              VARCHAR(100)    NOT NULL DEFAULT 'preset',
    credential          VARCHAR(1024)   DEFAULT NULL,
    inherit_credential  SMALLINT        NOT NULL DEFAULT 1,
    gmt_create          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified        TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    creator             VARCHAR(64)     DEFAULT NULL,
    modifier            VARCHAR(64)     DEFAULT NULL,
    PRIMARY KEY (id)
);
CREATE INDEX idx_model_account_tenant_provider_model ON model (tenant_id, provider, model_id);

CREATE TRIGGER trg_model_update_gmt_modified
    BEFORE UPDATE ON model
    FOR EACH ROW
    EXECUTE FUNCTION update_modified_column();

COMMENT ON TABLE model IS 'model info';
COMMENT ON COLUMN model.id IS 'pk';
COMMENT ON COLUMN model.tenant_id IS 'tenant id';
COMMENT ON COLUMN model.icon IS 'icon';
COMMENT ON COLUMN model.name IS 'model name';
COMMENT ON COLUMN model.type IS 'model type: LLM';
COMMENT ON COLUMN model.type_spec IS 'model type spec: llm, mllm';
COMMENT ON COLUMN model.mode IS 'mode';
COMMENT ON COLUMN model.model_id IS 'model id';
COMMENT ON COLUMN model.provider IS 'provider';
COMMENT ON COLUMN model.enable IS 'enable, 0: disabled, 1: enabled';
COMMENT ON COLUMN model.tags IS 'tags';
COMMENT ON COLUMN model.source IS 'source, preset, custom';
COMMENT ON COLUMN model.credential IS 'access credential，json';
COMMENT ON COLUMN model.inherit_credential IS '是否继承provider的credential，0-不继承，1-继承（默认值）';
COMMENT ON COLUMN model.gmt_create IS 'create time';
COMMENT ON COLUMN model.gmt_modified IS 'modified time';
COMMENT ON COLUMN model.creator IS 'creator';
COMMENT ON COLUMN model.modifier IS 'modifier';

-- ---------------------------------------------------------------------------
-- 22. plugin
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS plugin;
CREATE TABLE plugin (
    id              BIGSERIAL       NOT NULL,
    plugin_id       VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    type            VARCHAR(64)     NOT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    name            VARCHAR(255)    NOT NULL,
    description     VARCHAR(4096)   DEFAULT NULL,
    config          TEXT            DEFAULT NULL,
    source          VARCHAR(64)     NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_plugin_id UNIQUE (plugin_id)
);
CREATE INDEX idx_plugin_tenant_type ON plugin (tenant_id, type);

COMMENT ON TABLE plugin IS 'plugin info';
COMMENT ON COLUMN plugin.id IS 'pk';
COMMENT ON COLUMN plugin.plugin_id IS 'biz id';
COMMENT ON COLUMN plugin.tenant_id IS 'tenant id';
COMMENT ON COLUMN plugin.type IS 'type: 1: official, 2: custom';
COMMENT ON COLUMN plugin.status IS 'status: 0-deleted, 1-normal';
COMMENT ON COLUMN plugin.name IS 'plugin name';
COMMENT ON COLUMN plugin.description IS 'plugin description';
COMMENT ON COLUMN plugin.config IS 'plugin config';
COMMENT ON COLUMN plugin.source IS 'plugin source';
COMMENT ON COLUMN plugin.creator IS 'creator uid';
COMMENT ON COLUMN plugin.modifier IS 'modifier uid';

-- ---------------------------------------------------------------------------
-- 23. provider  (ON UPDATE CURRENT_TIMESTAMP → trigger)
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS provider;
CREATE TABLE provider (
    id                      BIGSERIAL       NOT NULL,
    tenant_id               VARCHAR(64)     DEFAULT NULL,
    icon                    VARCHAR(255)    DEFAULT NULL,
    name                    VARCHAR(255)    DEFAULT NULL,
    description             VARCHAR(1024)   DEFAULT NULL,
    provider                VARCHAR(255)    NOT NULL,
    enable                  BOOLEAN         DEFAULT TRUE,
    source                  VARCHAR(64)     NOT NULL DEFAULT 'preset',
    credential              VARCHAR(1024)   DEFAULT NULL,
    supported_model_types   VARCHAR(255)    DEFAULT NULL,
    protocol                VARCHAR(64)     DEFAULT NULL,
    gmt_create              TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified            TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    creator                 VARCHAR(64)     DEFAULT NULL,
    modifier                VARCHAR(64)     DEFAULT NULL,
    PRIMARY KEY (id)
);
CREATE INDEX idx_provider_account_tenant_provider ON provider (tenant_id, provider);

CREATE TRIGGER trg_provider_update_gmt_modified
    BEFORE UPDATE ON provider
    FOR EACH ROW
    EXECUTE FUNCTION update_modified_column();

COMMENT ON TABLE provider IS 'provider info';
COMMENT ON COLUMN provider.id IS 'pk';
COMMENT ON COLUMN provider.tenant_id IS 'tenant id';
COMMENT ON COLUMN provider.icon IS 'provider icon';
COMMENT ON COLUMN provider.name IS 'provider name';
COMMENT ON COLUMN provider.description IS 'provider description';
COMMENT ON COLUMN provider.provider IS 'provider';
COMMENT ON COLUMN provider.enable IS 'enable, 0: disabled, 1: enabled';
COMMENT ON COLUMN provider.source IS 'source, preset, custom';
COMMENT ON COLUMN provider.credential IS 'access credential，json';
COMMENT ON COLUMN provider.supported_model_types IS 'model type';
COMMENT ON COLUMN provider.protocol IS 'protocol, openai';
COMMENT ON COLUMN provider.gmt_create IS 'create time';
COMMENT ON COLUMN provider.gmt_modified IS 'modified time';
COMMENT ON COLUMN provider.creator IS 'creator';
COMMENT ON COLUMN provider.modifier IS 'modifier';

-- ---------------------------------------------------------------------------
-- 24. reference
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS reference;
CREATE TABLE reference (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    main_code       VARCHAR(64)     NOT NULL,
    main_type       SMALLINT        NOT NULL,
    refer_code      VARCHAR(64)     NOT NULL,
    refer_type      SMALLINT        NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL DEFAULT '1',
    PRIMARY KEY (id)
);
CREATE INDEX idx_ref_refer_code ON reference (refer_code);
CREATE INDEX idx_ref_main_code_tenant_type ON reference (tenant_id, main_code, main_type);

COMMENT ON TABLE reference IS 'reference info';
COMMENT ON COLUMN reference.id IS 'pk';
COMMENT ON COLUMN reference.gmt_create IS 'create time';
COMMENT ON COLUMN reference.gmt_modified IS 'modified time';
COMMENT ON COLUMN reference.main_code IS 'entity code';
COMMENT ON COLUMN reference.main_type IS 'entity time';
COMMENT ON COLUMN reference.refer_code IS 'refer code';
COMMENT ON COLUMN reference.refer_type IS 'refer type';
COMMENT ON COLUMN reference.tenant_id IS 'tenant id';

-- ---------------------------------------------------------------------------
-- 25. tenant
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS tenant;
CREATE TABLE tenant (
    id              BIGSERIAL       NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    account_id      VARCHAR(64)     NOT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    name            VARCHAR(255)    NOT NULL,
    description     VARCHAR(4096)   DEFAULT NULL,
    config          TEXT            DEFAULT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_workspace_id UNIQUE (tenant_id)
);
CREATE INDEX idx_tenant_account_id ON tenant (account_id);

COMMENT ON TABLE tenant IS 'tenant info';
COMMENT ON COLUMN tenant.id IS 'pk';
COMMENT ON COLUMN tenant.tenant_id IS 'tenant id';
COMMENT ON COLUMN tenant.account_id IS 'account id';
COMMENT ON COLUMN tenant.status IS 'status: 0-deleted, 1-normal';
COMMENT ON COLUMN tenant.name IS 'tenant name';
COMMENT ON COLUMN tenant.description IS 'tenant description';
COMMENT ON COLUMN tenant.config IS 'tenant config';
COMMENT ON COLUMN tenant.creator IS 'creator uid';
COMMENT ON COLUMN tenant.modifier IS 'creator uid';

-- ---------------------------------------------------------------------------
-- 26. tool
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS tool;
CREATE TABLE tool (
    id              BIGSERIAL       NOT NULL,
    plugin_id       VARCHAR(64)     NOT NULL,
    tool_id         VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    enabled         SMALLINT        NOT NULL DEFAULT 1,
    test_status     SMALLINT        NOT NULL DEFAULT 1,
    name            VARCHAR(255)    NOT NULL,
    description     VARCHAR(4096)   DEFAULT NULL,
    config          TEXT            NOT NULL,
    api_schema      TEXT            NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     NOT NULL,
    modifier        VARCHAR(64)     NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_tool_id UNIQUE (tool_id)
);
CREATE INDEX idx_tool_tenant_plugin ON tool (tenant_id, plugin_id);

COMMENT ON TABLE tool IS 'tool info';
COMMENT ON COLUMN tool.id IS 'pk';
COMMENT ON COLUMN tool.plugin_id IS 'plugin id';
COMMENT ON COLUMN tool.tool_id IS 'tool id';
COMMENT ON COLUMN tool.tenant_id IS 'tenant id';
COMMENT ON COLUMN tool.status IS 'status: 0-deleted, 1-normal';
COMMENT ON COLUMN tool.enabled IS 'enabled: 0-disabled, 1-enabled';
COMMENT ON COLUMN tool.test_status IS 'test status: 1: not tested, 2: passed, 3: failed';
COMMENT ON COLUMN tool.name IS 'tool name';
COMMENT ON COLUMN tool.description IS 'tool description';
COMMENT ON COLUMN tool.config IS 'tool config';
COMMENT ON COLUMN tool.api_schema IS 'tool api schema';
COMMENT ON COLUMN tool.creator IS 'creator uid';
COMMENT ON COLUMN tool.modifier IS 'modifier uid';

-- ---------------------------------------------------------------------------
-- 27. trace_resource_meta
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS trace_resource_meta;
CREATE TABLE trace_resource_meta (
    id              BIGSERIAL       NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL,
    gmt_modified    TIMESTAMP       NOT NULL,
    uid             VARCHAR(64)     NOT NULL,
    workspace_id    VARCHAR(64)     NOT NULL,
    resource_id     VARCHAR(128)    NOT NULL,
    resource_type   VARCHAR(32)     NOT NULL,
    metadata        TEXT            DEFAULT NULL,
    PRIMARY KEY (id)
);
CREATE INDEX idx_trm_uid ON trace_resource_meta (uid);
CREATE INDEX idx_trm_workspace_id ON trace_resource_meta (workspace_id);
CREATE INDEX idx_trm_resource_id ON trace_resource_meta (resource_id);

COMMENT ON TABLE trace_resource_meta IS '观测资源元数据表';
COMMENT ON COLUMN trace_resource_meta.id IS '主键';
COMMENT ON COLUMN trace_resource_meta.gmt_create IS '创建时间';
COMMENT ON COLUMN trace_resource_meta.gmt_modified IS '修改时间';
COMMENT ON COLUMN trace_resource_meta.uid IS '用户ID（主账号ID）';
COMMENT ON COLUMN trace_resource_meta.workspace_id IS '业务空间ID';
COMMENT ON COLUMN trace_resource_meta.resource_id IS '资源ID，例如APPID';
COMMENT ON COLUMN trace_resource_meta.resource_type IS '资源类型';
COMMENT ON COLUMN trace_resource_meta.metadata IS '元数据内容';

-- ---------------------------------------------------------------------------
-- 28. skill
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill;
CREATE TABLE skill (
    id              BIGSERIAL       NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    name            VARCHAR(128)    NOT NULL,
    display_name    VARCHAR(256)    DEFAULT NULL,
    description     TEXT            DEFAULT NULL,
    skill_type      SMALLINT        NOT NULL DEFAULT 1,
    source          VARCHAR(32)     NOT NULL DEFAULT 'tenant',
    author          VARCHAR(128)    DEFAULT NULL,
    file_count      INTEGER         NOT NULL DEFAULT 0,
    status          SMALLINT        NOT NULL DEFAULT 1,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    creator         VARCHAR(64)     DEFAULT NULL,
    modifier        VARCHAR(64)     DEFAULT NULL,
    publish_status  SMALLINT        DEFAULT 0,
    active_version_id VARCHAR(64)   DEFAULT '',
    PRIMARY KEY (id),
    CONSTRAINT uk_skill_id UNIQUE (skill_id)
);
CREATE UNIQUE INDEX uk_skill_tenant_name ON skill (tenant_id, name) WHERE status = 1;
CREATE INDEX idx_skill_tenant ON skill (tenant_id, status);
CREATE INDEX idx_skill_source ON skill (source, status);

COMMENT ON TABLE skill IS '技能包信息表';
COMMENT ON COLUMN skill.id IS '主键';
COMMENT ON COLUMN skill.skill_id IS '技能包唯一标识';
COMMENT ON COLUMN skill.tenant_id IS '租户ID，平台公共技能为 __platform__';
COMMENT ON COLUMN skill.name IS '技能包名称';
COMMENT ON COLUMN skill.display_name IS '显示名称';
COMMENT ON COLUMN skill.description IS '描述';
COMMENT ON COLUMN skill.skill_type IS '技能类型: 1=capability_uplift, 2=encoded_preference';
COMMENT ON COLUMN skill.source IS '来源: platform=平台公共, tenant=租户自有';
COMMENT ON COLUMN skill.author IS '原始作者';
COMMENT ON COLUMN skill.file_count IS '文件总数';
COMMENT ON COLUMN skill.status IS '状态: 0=deleted, 1=normal';
COMMENT ON COLUMN skill.gmt_create IS '创建时间';
COMMENT ON COLUMN skill.gmt_modified IS '修改时间';
COMMENT ON COLUMN skill.creator IS '创建者accountId';
COMMENT ON COLUMN skill.modifier IS '最后修改者accountId';
COMMENT ON COLUMN skill.publish_status IS '广场发布状态: 0=未发布, 1=审批中, 2=已上架, 3=被拒绝';
COMMENT ON COLUMN skill.active_version_id IS '当前激活版本ID';

-- ---------------------------------------------------------------------------
-- 29. skill_file
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_file;
CREATE TABLE skill_file (
    id              BIGSERIAL       NOT NULL,
    file_id         VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    directory       VARCHAR(32)     NOT NULL,
    file_name       VARCHAR(256)    NOT NULL,
    file_path       VARCHAR(512)    NOT NULL,
    file_content    TEXT            DEFAULT NULL,
    file_data       BYTEA           DEFAULT NULL,
    is_text         BOOLEAN         NOT NULL DEFAULT TRUE,
    file_size       BIGINT          NOT NULL DEFAULT 0,
    content_type    VARCHAR(128)    DEFAULT NULL,
    status          SMALLINT        NOT NULL DEFAULT 1,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT uk_skill_file_id UNIQUE (file_id)
);
CREATE INDEX idx_skill_file_tenant ON skill_file (tenant_id, status);

COMMENT ON TABLE skill_file IS '技能包文件表';
COMMENT ON COLUMN skill_file.id IS '主键';
COMMENT ON COLUMN skill_file.file_id IS '文件唯一标识';
COMMENT ON COLUMN skill_file.tenant_id IS '租户ID';
COMMENT ON COLUMN skill_file.directory IS '目录: root, scripts, references, assets';
COMMENT ON COLUMN skill_file.file_name IS '文件名';
COMMENT ON COLUMN skill_file.file_path IS '技能包内相对路径';
COMMENT ON COLUMN skill_file.file_content IS '文本文件内容';
COMMENT ON COLUMN skill_file.file_data IS '二进制文件内容';
COMMENT ON COLUMN skill_file.is_text IS '是否为文本文件';
COMMENT ON COLUMN skill_file.file_size IS '文件大小(bytes)';
COMMENT ON COLUMN skill_file.content_type IS 'MIME类型';
COMMENT ON COLUMN skill_file.status IS '状态: 0=deleted, 1=normal';
COMMENT ON COLUMN skill_file.gmt_create IS '创建时间';
COMMENT ON COLUMN skill_file.gmt_modified IS '修改时间';

-- ---------------------------------------------------------------------------
-- 30. skill_file_relation
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_file_relation;
CREATE TABLE skill_file_relation (
    id              BIGSERIAL       NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    file_id         VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT uk_sfr_skill_file UNIQUE (skill_id, file_id)
);
CREATE INDEX idx_sfr_skill ON skill_file_relation (skill_id);
CREATE INDEX idx_sfr_file ON skill_file_relation (file_id);
CREATE INDEX idx_sfr_tenant ON skill_file_relation (tenant_id);

COMMENT ON TABLE skill_file_relation IS 'skill与文件的关联关系表';
COMMENT ON COLUMN skill_file_relation.id IS '主键';
COMMENT ON COLUMN skill_file_relation.skill_id IS '技能包ID';
COMMENT ON COLUMN skill_file_relation.file_id IS '文件ID';
COMMENT ON COLUMN skill_file_relation.tenant_id IS '租户ID（工作空间ID）';
COMMENT ON COLUMN skill_file_relation.gmt_create IS '创建时间';

-- ---------------------------------------------------------------------------
-- 31. skill_aibaas_relation
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_aibaas_relation;
CREATE TABLE skill_aibaas_relation (
    id              BIGSERIAL       NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    skill_run_id    VARCHAR(128)    NOT NULL,
    revision_id     VARCHAR(128)    NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
CREATE INDEX idx_shr_skill ON skill_aibaas_relation (skill_id);
CREATE INDEX idx_shr_tenant ON skill_aibaas_relation (tenant_id);
CREATE INDEX idx_sar_revision ON skill_aibaas_relation (revision_id);
CREATE INDEX idx_sar_skill_create ON skill_aibaas_relation (skill_id, gmt_create DESC);
CREATE UNIQUE INDEX uk_sar_skill_revision ON skill_aibaas_relation (skill_id, revision_id);

COMMENT ON TABLE skill_aibaas_relation IS 'skill与Skill Run API的关联关系表';
COMMENT ON COLUMN skill_aibaas_relation.id IS '主键';
COMMENT ON COLUMN skill_aibaas_relation.skill_id IS '本地技能包ID';
COMMENT ON COLUMN skill_aibaas_relation.skill_run_id IS 'Skill Run API 返回的 skill.id';
COMMENT ON COLUMN skill_aibaas_relation.revision_id IS 'Skill Run API 返回的 revision.id';
COMMENT ON COLUMN skill_aibaas_relation.tenant_id IS '租户ID（工作空间ID）';
COMMENT ON COLUMN skill_aibaas_relation.gmt_create IS '创建时间';

-- ---------------------------------------------------------------------------
-- 32. skill_version — 技能版本表
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_version;
CREATE TABLE skill_version (
    id              BIGSERIAL       PRIMARY KEY,
    version_id      VARCHAR(64)     NOT NULL,
    skill_id        VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    version_number  VARCHAR(32)     NOT NULL,
    release_notes   VARCHAR(500)    DEFAULT '',
    revision_id     VARCHAR(128)    NOT NULL,
    skill_run_id    VARCHAR(128)    DEFAULT '',
    file_count      INTEGER         NOT NULL DEFAULT 0,
    is_active       BOOLEAN         NOT NULL DEFAULT FALSE,
    status          SMALLINT        NOT NULL DEFAULT 1,
    publisher       VARCHAR(128)    DEFAULT '',
    publisher_id    VARCHAR(64)     DEFAULT '',
    gmt_create      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uk_skill_version_id ON skill_version (version_id);
CREATE INDEX idx_skill_version_skill ON skill_version (skill_id, status);
CREATE UNIQUE INDEX uk_skill_version_number ON skill_version (skill_id, version_number) WHERE status = 1;
CREATE UNIQUE INDEX uk_skill_version_active ON skill_version (skill_id) WHERE is_active = TRUE AND status = 1;

COMMENT ON TABLE skill_version IS '技能版本表';
COMMENT ON COLUMN skill_version.id IS '主键';
COMMENT ON COLUMN skill_version.version_id IS '版本唯一标识';
COMMENT ON COLUMN skill_version.skill_id IS '所属技能ID';
COMMENT ON COLUMN skill_version.tenant_id IS '租户ID';
COMMENT ON COLUMN skill_version.version_number IS '版本号 (如 v1.0.0)';
COMMENT ON COLUMN skill_version.release_notes IS '版本说明';
COMMENT ON COLUMN skill_version.revision_id IS 'AIBaaS revision ID';
COMMENT ON COLUMN skill_version.skill_run_id IS 'AIBaaS skill run ID';
COMMENT ON COLUMN skill_version.file_count IS '文件总数';
COMMENT ON COLUMN skill_version.is_active IS '是否为当前激活版本';
COMMENT ON COLUMN skill_version.status IS '状态: 0=deleted, 1=normal';
COMMENT ON COLUMN skill_version.publisher IS '发布者名称';
COMMENT ON COLUMN skill_version.publisher_id IS '发布者accountId';
COMMENT ON COLUMN skill_version.gmt_create IS '创建时间';
COMMENT ON COLUMN skill_version.gmt_modified IS '修改时间';

-- ---------------------------------------------------------------------------
-- 33. skill_publish_request — 发布审批请求表
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_publish_request;
CREATE TABLE skill_publish_request (
    id                  BIGSERIAL       PRIMARY KEY,
    request_id          VARCHAR(64)     NOT NULL,
    skill_id            VARCHAR(64)     NOT NULL,
    tenant_id           VARCHAR(64)     NOT NULL,
    version_id          VARCHAR(64)     NOT NULL,
    version_number      VARCHAR(32)     NOT NULL,
    skill_name          VARCHAR(128)    NOT NULL,
    description         VARCHAR(500)    DEFAULT '',
    status              SMALLINT        NOT NULL DEFAULT 0,
    rejection_reason    TEXT            DEFAULT '',
    submitter_id        VARCHAR(64)     NOT NULL,
    submitter_name      VARCHAR(128)    DEFAULT '',
    reviewer_id         VARCHAR(64)     DEFAULT '',
    reviewer_name       VARCHAR(128)    DEFAULT '',
    gmt_create          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified        TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uk_publish_request_id ON skill_publish_request (request_id);
CREATE INDEX idx_publish_request_tenant ON skill_publish_request (tenant_id, status);
CREATE INDEX idx_publish_request_skill ON skill_publish_request (skill_id, status);

COMMENT ON TABLE skill_publish_request IS '技能发布审批请求表';
COMMENT ON COLUMN skill_publish_request.id IS '主键';
COMMENT ON COLUMN skill_publish_request.request_id IS '请求唯一标识';
COMMENT ON COLUMN skill_publish_request.skill_id IS '技能ID';
COMMENT ON COLUMN skill_publish_request.tenant_id IS '租户ID';
COMMENT ON COLUMN skill_publish_request.version_id IS '版本ID';
COMMENT ON COLUMN skill_publish_request.version_number IS '版本号';
COMMENT ON COLUMN skill_publish_request.skill_name IS '技能名称';
COMMENT ON COLUMN skill_publish_request.description IS '发布说明';
COMMENT ON COLUMN skill_publish_request.status IS '审批状态: 0=pending, 1=approved, 2=rejected';
COMMENT ON COLUMN skill_publish_request.rejection_reason IS '拒绝原因';
COMMENT ON COLUMN skill_publish_request.submitter_id IS '提交人accountId';
COMMENT ON COLUMN skill_publish_request.submitter_name IS '提交人名称';
COMMENT ON COLUMN skill_publish_request.reviewer_id IS '审批人accountId';
COMMENT ON COLUMN skill_publish_request.reviewer_name IS '审批人名称';
COMMENT ON COLUMN skill_publish_request.gmt_create IS '创建时间';
COMMENT ON COLUMN skill_publish_request.gmt_modified IS '修改时间';

-- ---------------------------------------------------------------------------
-- 34. skill_square_listing — 广场技能上架表
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_square_listing;
CREATE TABLE skill_square_listing (
    id                  BIGSERIAL       PRIMARY KEY,
    listing_id          VARCHAR(64)     NOT NULL,
    skill_id            VARCHAR(64)     NOT NULL,
    tenant_id           VARCHAR(64)     NOT NULL,
    source              VARCHAR(32)     NOT NULL,
    listing_status      SMALLINT        NOT NULL DEFAULT 1,
    sort_order          NUMERIC(10,4)   DEFAULT 0,
    publish_request_id  VARCHAR(64)     DEFAULT '',
    version_id          VARCHAR(64)     DEFAULT '',
    skill_name          VARCHAR(128)    DEFAULT '',
    display_name        VARCHAR(256)    DEFAULT '',
    description         TEXT            DEFAULT '',
    skill_type          SMALLINT        DEFAULT 1,
    author              VARCHAR(128)    DEFAULT '',
    status              SMALLINT        DEFAULT 1,
    gmt_create          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified        TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    creator             VARCHAR(64)     DEFAULT '',
    modifier            VARCHAR(64)     DEFAULT ''
);
CREATE UNIQUE INDEX uk_square_listing_id ON skill_square_listing (listing_id);
CREATE UNIQUE INDEX uk_square_listing_skill ON skill_square_listing (tenant_id, skill_id) WHERE status = 1;
CREATE INDEX idx_square_listing_sort ON skill_square_listing (tenant_id, sort_order) WHERE status = 1 AND listing_status = 1;

COMMENT ON TABLE skill_square_listing IS '技能广场上架列表';
COMMENT ON COLUMN skill_square_listing.id IS '主键';
COMMENT ON COLUMN skill_square_listing.listing_id IS '上架记录唯一标识';
COMMENT ON COLUMN skill_square_listing.skill_id IS '技能ID';
COMMENT ON COLUMN skill_square_listing.tenant_id IS '租户ID';
COMMENT ON COLUMN skill_square_listing.source IS '来源: platform=平台, tenant=租户';
COMMENT ON COLUMN skill_square_listing.listing_status IS '上架状态: 1=上架, 0=下架';
COMMENT ON COLUMN skill_square_listing.sort_order IS '排序权重';
COMMENT ON COLUMN skill_square_listing.publish_request_id IS '关联的发布请求ID';
COMMENT ON COLUMN skill_square_listing.version_id IS '上架版本ID';
COMMENT ON COLUMN skill_square_listing.status IS '状态: 0=deleted, 1=normal';
COMMENT ON COLUMN skill_square_listing.gmt_create IS '创建时间';
COMMENT ON COLUMN skill_square_listing.gmt_modified IS '修改时间';
COMMENT ON COLUMN skill_square_listing.creator IS '创建者accountId';
COMMENT ON COLUMN skill_square_listing.modifier IS '最后修改者accountId';

-- ---------------------------------------------------------------------------
-- 35. skill_trial_agent — 试运行 Agent 映射表
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_trial_agent;
CREATE TABLE skill_trial_agent (
    id                    BIGSERIAL       PRIMARY KEY,
    tenant_id             VARCHAR(64)     NOT NULL,
    account_id            VARCHAR(64)     NOT NULL,
    agent_code            VARCHAR(64)     NOT NULL,
    last_skill_id         VARCHAR(64)     DEFAULT '',
    last_revision_id      VARCHAR(128)    DEFAULT '',
    last_skill_modified   TIMESTAMP       DEFAULT NULL,
    gmt_create            TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uk_trial_agent_tenant_account ON skill_trial_agent (tenant_id, account_id);

COMMENT ON TABLE skill_trial_agent IS '技能试运行Agent映射表';
COMMENT ON COLUMN skill_trial_agent.id IS '主键';
COMMENT ON COLUMN skill_trial_agent.tenant_id IS '租户ID';
COMMENT ON COLUMN skill_trial_agent.account_id IS '用户accountId';
COMMENT ON COLUMN skill_trial_agent.agent_code IS '试运行Agent编码';
COMMENT ON COLUMN skill_trial_agent.last_skill_id IS '最近试运行的技能ID';
COMMENT ON COLUMN skill_trial_agent.last_revision_id IS '最近试运行的revisionId';
COMMENT ON COLUMN skill_trial_agent.last_skill_modified IS '最近技能变更时间';
COMMENT ON COLUMN skill_trial_agent.gmt_create IS '创建时间';
COMMENT ON COLUMN skill_trial_agent.gmt_modified IS '修改时间';

-- ---------------------------------------------------------------------------
-- 36. skill_notification — 技能审批通知表
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS skill_notification;
CREATE TABLE skill_notification (
    id              BIGSERIAL       PRIMARY KEY,
    notification_id VARCHAR(64)     NOT NULL,
    tenant_id       VARCHAR(64)     NOT NULL,
    recipient_id    VARCHAR(64)     NOT NULL,
    type            VARCHAR(32)     NOT NULL,
    title           VARCHAR(256)    NOT NULL,
    content         TEXT            DEFAULT '',
    skill_id        VARCHAR(64)     DEFAULT '',
    request_id      VARCHAR(64)     DEFAULT '',
    is_read         BOOLEAN         DEFAULT FALSE,
    status          SMALLINT        DEFAULT 1,
    gmt_create      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    gmt_modified    TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uk_skill_notification_id ON skill_notification (notification_id);
CREATE INDEX idx_skill_notification_recipient ON skill_notification (recipient_id, tenant_id, is_read, status);

COMMENT ON TABLE skill_notification IS '技能审批通知表';
COMMENT ON COLUMN skill_notification.id IS '主键';
COMMENT ON COLUMN skill_notification.notification_id IS '通知唯一标识';
COMMENT ON COLUMN skill_notification.tenant_id IS '租户ID';
COMMENT ON COLUMN skill_notification.recipient_id IS '接收人accountId';
COMMENT ON COLUMN skill_notification.type IS '通知类型';
COMMENT ON COLUMN skill_notification.title IS '通知标题';
COMMENT ON COLUMN skill_notification.content IS '通知内容';
COMMENT ON COLUMN skill_notification.skill_id IS '关联技能ID';
COMMENT ON COLUMN skill_notification.request_id IS '关联请求ID';
COMMENT ON COLUMN skill_notification.is_read IS '是否已读';
COMMENT ON COLUMN skill_notification.status IS '状态: 0=deleted, 1=normal';
COMMENT ON COLUMN skill_notification.gmt_create IS '创建时间';
COMMENT ON COLUMN skill_notification.gmt_modified IS '修改时间';

-- ===========================================================================
-- 技能广场预置数据（source=platform, tenant_id=__platform__）
-- ===========================================================================

-- skill 表种子数据
INSERT INTO skill (skill_id, tenant_id, name, display_name, description, skill_type, source, author, file_count, status, creator, modifier)
VALUES
  ('1000000000000001', '__platform__', 'brainstorming',            '头脑风暴',       '用于创意或建设性工作开始前（功能设计、架构规划、行为分析），通过结构化对话将模糊想法转化为经过验证的方案设计。',                            2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000002', '__platform__', 'copywriting',              '文案撰写',       '撰写严谨、以转化为导向的营销文案，适用于落地页和邮件场景，强制要求简要确认并严格禁止虚假内容。',                                            2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000003', '__platform__', 'customer-support',         '客户支持',       '精英级 AI 驱动的客户支持专家，精通对话式 AI、自动化工单、情感分析及全渠道客户服务体验。',                                                    2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000004', '__platform__', 'data-storytelling',        '数据叙事',       '将原始数据转化为引人入胜的叙事，驱动决策制定并激发行动。',                                                                                        2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000005', '__platform__', 'email-sequence',           '邮件序列设计',   '专注于邮件营销与自动化，设计能够培育客户关系、推动行动并引导转化的邮件序列。',                                                                  2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000006', '__platform__', 'hr-pro',                   '人力资源专家',   '专业、合规的 HR 伙伴，覆盖招聘、入职/离职、假期管理、绩效考核、合规政策及员工关系等全场景。',                                                  2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000007', '__platform__', 'interview-coach',          '面试教练',       '完整求职辅导系统，涵盖 JD 解析、简历优化、故事库构建、模拟面试、录音分析、薪资谈判，共 23 个指令，支持持久状态记忆。',                          2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000008', '__platform__', 'legal-advisor',            '法律顾问',       '起草隐私政策、服务条款、免责声明及法律通知，生成符合 GDPR 的文本、Cookie 政策及数据处理协议。',                                              2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000009', '__platform__', 'product-manager',          '产品经理',       '资深 PM 智能体，具备 6 大知识领域、30+ 框架方法、12 套模板及含公式的 32 项 SaaS 指标，纯 Markdown 输出，无需脚本。',                           2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000010', '__platform__', 'professional-proofreader', '专业校对',       '当用户要求"校对"、"审查并纠正"、"修正语法"、"在保持原有风格的前提下提升可读性"，或需对文档文件进行校对并保存更新版本时使用。',                2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin'),
  ('1000000000000011', '__platform__', 'scientific-writing',       '科学写作',       '深度研究与写作工具的核心技能，融合 AI 驱动的深度研究与规范格式化输出，每篇文档均经过系统性文献检索并通过 research-lookup 技能完成引用核验。', 2, 'platform', 'AgentScope Team', 1, 1, 'admin', 'admin')
ON CONFLICT DO NOTHING;

-- skill_file 表种子数据（每个 skill 的 SKILL.md，内容来自 docs/enterprise-skills/）
INSERT INTO skill_file (file_id, tenant_id, directory, file_name, file_path, file_content, is_text, file_size, content_type, status)
VALUES
  ('2000000000000001', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: brainstorming\ndescription: "Use before creative or constructive work (features, architecture, behavior). Transforms vague ideas into validated designs through disciplined reasoning and collaboration."\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Brainstorming Ideas Into Designs\n\n## Purpose\n\nTurn raw ideas into **clear, validated designs and specifications**\nthrough structured dialogue **before any implementation begins**.\n\nThis skill exists to prevent:\n- premature implementation\n- hidden assumptions\n- misaligned solutions\n- fragile systems\n\nYou are **not allowed** to implement, code, or modify behavior while this skill is active.\n\n---\n\n## Operating Mode\n\nYou are operating as a **design facilitator and senior reviewer**, not a builder.\n\n- No creative implementation  \n- No speculative features  \n- No silent assumptions  \n- No skipping ahead  \n\nYour job is to **slow the process down just enough to get it right**.\n\n---\n\n## The Process\n\n### 1️⃣ Understand the Current Context (Mandatory First Step)\n\nBefore asking any questions:\n\n- Review the current project state (if available):\n  - files\n  - documentation\n  - plans\n  - prior decisions\n- Identify what already exists vs. what is proposed\n- Note constraints that appear implicit but unconfirmed\n\n**Do not design yet.**\n\n---\n\n### 2️⃣ Understanding the Idea (One Question at a Time)\n\nYour goal here is **shared clarity**, not speed.\n\n**Rules:**\n\n- Ask **one question per message**\n- Prefer **multiple-choice questions** when possible\n- Use open-ended questions only when necessary\n- If a topic needs depth, split it into multiple questions\n\nFocus on understanding:\n\n- purpose  \n- target users  \n- constraints  \n- success criteria  \n- explicit non-goals  \n\n---\n\n### 3️⃣ Non-Functional Requirements (Mandatory)\n\nYou MUST explicitly clarify or propose assumptions for:\n\n- Performance expectations  \n- Scale (users, data, traffic)  \n- Security or privacy constraints  \n- Reliability / availability needs  \n- Maintenance and ownership expectations  \n\nIf the user is unsure:\n\n- Propose reasonable defaults  \n- Clearly mark them as **assumptions**\n\n---\n\n### 4️⃣ Understanding Lock (Hard Gate)\n\nBefore proposing **any design**, you MUST pause and do the following:\n\n#### Understanding Summary\nProvide a concise summary (5–7 bullets) covering:\n- What is being built  \n- Why it exists  \n- Who it is for  \n- Key constraints  \n- Explicit non-goals  \n\n#### Assumptions\nList all assumptions explicitly.\n\n#### Open Questions\nList unresolved questions, if any.\n\nThen ask:\n\n> "Does this accurately reflect your intent?  \n> Please confirm or correct anything before we move to design."\n\n**Do NOT proceed until explicit confirmation is given.**\n\n---\n\n### 5️⃣ Explore Design Approaches\n\nOnce understanding is confirmed:\n\n- Propose **2–3 viable approaches**\n- Lead with your **recommended option**\n- Explain trade-offs clearly:\n  - complexity\n  - extensibility\n  - risk\n  - maintenance\n- Avoid premature optimization (**YAGNI ruthlessly**)\n\nThis is still **not** final design.\n\n---\n\n### 6️⃣ Present the Design (Incrementally)\n\nWhen presenting the design:\n\n- Break it into sections of **200–300 words max**\n- After each section, ask:\n\n  > "Does this look right so far?"\n\nCover, as relevant:\n\n- Architecture  \n- Components  \n- Data flow  \n- Error handling  \n- Edge cases  \n- Testing strategy  \n\n---\n\n### 7️⃣ Decision Log (Mandatory)\n\nMaintain a running **Decision Log** throughout the design discussion.\n\nFor each decision:\n- What was decided  \n- Alternatives considered  \n- Why this option was chosen  \n\nThis log should be preserved for documentation.\n\n---\n\n## After the Design\n\n### 📄 Documentation\n\nOnce the design is validated:\n\n- Write the final design to a durable, shared format (e.g. Markdown)\n- Include:\n  - Understanding summary\n  - Assumptions\n  - Decision log\n  - Final design\n\nPersist the document according to the project\'s standard workflow.\n\n---\n\n### 🛠️ Implementation Handoff (Optional)\n\nOnly after documentation is complete, ask:\n\n> "Ready to set up for implementation?"\n\nIf yes:\n- Create an explicit implementation plan\n- Isolate work if the workflow supports it\n- Proceed incrementally\n\n---\n\n## Exit Criteria (Hard Stop Conditions)\n\nYou may exit brainstorming mode **only when all of the following are true**:\n\n- Understanding Lock has been confirmed  \n- At least one design approach is explicitly accepted  \n- Major assumptions are documented  \n- Key risks are acknowledged  \n- Decision Log is complete  \n\nIf any criterion is unmet:\n- Continue refinement  \n- **Do NOT proceed to implementation**\n\n---\n\n## Key Principles (Non-Negotiable)\n\n- One question at a time  \n- Assumptions must be explicit  \n- Explore alternatives  \n- Validate incrementally  \n- Prefer clarity over cleverness  \n- Be willing to go back and clarify  \n- **YAGNI ruthlessly**\n\n---\nIf the design is high-impact, high-risk, or requires elevated confidence, you MUST hand off the finalized design and Decision Log to the `multi-agent-brainstorming` skill before implementation.\n\n## When to Use\nThis skill is applicable to execute the workflow or actions described in the overview.',
   true, 5820, 'text/markdown', 1),

  ('2000000000000002', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: copywriting\ndescription: Write rigorous, conversion-focused marketing copy for landing pages and emails. Enforces brief confirmation and strict no-fabrication rules.\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Copywriting\n\n## Purpose\n\nProduce **clear, credible, and action-oriented marketing copy** that aligns with\nuser intent and business goals.\n\nThis skill exists to prevent:\n\n- writing before understanding the audience\n- vague or hype-driven messaging\n- misaligned CTAs\n- overclaiming or fabricated proof\n- untestable copy\n\nYou may **not** fabricate claims, statistics, testimonials, or guarantees.\n\n---\n\n## Operating Mode\n\nYou are operating as an **expert conversion copywriter**, not a brand poet.\n\n- Clarity beats cleverness\n- Outcomes beat features\n- Specificity beats buzzwords\n- Honesty beats hype\n\nYour job is to **help the right reader take the right action**.\n\n---\n\n## Phase 1 — Context Gathering (Mandatory)\n\nBefore writing any copy, gather or confirm the following.\nIf information is missing, ask for it **before proceeding**.\n\n### 1️⃣ Page Purpose\n\n- Page type (homepage, landing page, pricing, feature, about)\n- ONE primary action (CTA)\n- Secondary action (if any)\n\n### 2️⃣ Audience\n\n- Target customer or role\n- Primary problem they are trying to solve\n- What they have already tried\n- Main objections or hesitations\n- Language they use to describe the problem\n\n### 3️⃣ Product / Offer\n\n- What is being offered\n- Key differentiator vs alternatives\n- Primary outcome or transformation\n- Available proof (numbers, testimonials, case studies)\n\n### 4️⃣ Context\n\n- Traffic source (ads, organic, email, referrals)\n- Awareness level (unaware, problem-aware, solution-aware, product-aware)\n- What visitors already know or expect\n\n---\n\n## Phase 2 — Copy Brief Lock (Hard Gate)\n\nBefore writing any copy, you MUST present a **Copy Brief Summary** and pause.\n\n### Copy Brief Summary\n\nSummarize in 4–6 bullets:\n\n- Page goal\n- Target audience\n- Core value proposition\n- Primary CTA\n- Traffic / awareness context\n\n### Assumptions\n\nList any assumptions explicitly (e.g. awareness level, urgency, sophistication).\n\nThen ask:\n\n> "Does this copy brief accurately reflect what we\'re trying to achieve?\n> Please confirm or correct anything before I write copy."\n\n**Do NOT proceed until confirmation is given.**\n\n---\n\n## Phase 3 — Copywriting Principles\n\n### Core Principles (Non-Negotiable)\n\n- **Clarity over cleverness**\n- **Benefits over features**\n- **Specificity over vagueness**\n- **Customer language over company language**\n- **One idea per section**\n\nAlways connect:\n\n> Feature → Benefit → Outcome\n\n---\n\n## Writing Style Rules\n\n### Style Guidelines\n\n- Simple over complex\n- Active over passive\n- Confident over hedged\n- Show outcomes instead of adjectives\n- Avoid buzzwords unless customers use them\n\n### Claim Discipline\n\n- No fabricated data or testimonials\n- No implied guarantees unless explicitly stated\n- No exaggerated speed or certainty\n- If proof is missing, mark placeholders clearly\n\n---\n\n## Phase 4 — Page Structure Framework\n\n### Above the Fold\n\n**Headline**\n\n- Single most important message\n- Specific value proposition\n- Outcome-focused\n\n**Subheadline**\n\n- Adds clarity or context\n- 1–2 sentences max\n\n**Primary CTA**\n\n- Action-oriented\n- Describes what the user gets\n\n---\n\n### Core Sections (Use as Appropriate)\n\n- Social proof (logos, stats, testimonials)\n- Problem / pain articulation\n- Solution & key benefits (3–5 max)\n- How it works (3–4 steps)\n- Objection handling (FAQ, comparisons, guarantees)\n- Final CTA with recap and risk reduction\n\nAvoid stacking features without narrative flow.\n\n---\n\n## Phase 5 — Writing the Copy\n\nWhen writing copy, provide:\n\n### Page Copy\n\nOrganized by section with clear labels:\n\n- Headline\n- Subheadline\n- CTAs\n- Section headers\n- Body copy\n\n### Alternatives\n\nProvide 2–3 options for:\n\n- Headlines\n- Primary CTAs\n\nEach option must include a brief rationale.\n\n### Annotations\n\nFor key sections, explain:\n\n- Why this copy was chosen\n- Which principle it applies\n- What alternatives were considered\n\n---\n\n## Completion Criteria (Hard Stop)\n\nThis skill is complete ONLY when:\n\n- Copy brief has been confirmed\n- Page copy is delivered in structured form\n- Headline and CTA alternatives are provided\n- Assumptions are documented\n- Copy is ready for review, editing, or testing\n\n---\n\n## Key Principles (Summary)\n\n- Understand before writing\n- Make assumptions explicit\n- One page, one goal\n- One section, one idea\n- Benefits before features\n- Honest claims only\n\n---\n\n## Final Reminder\n\nGood copy does not persuade everyone.\nIt persuades **the right person** to take **the right action**.\n\nIf the copy feels clever but unclear,  \nrewrite it until it feels obvious.\n\n## When to Use\nThis skill is applicable to execute the workflow or actions described in the overview.',
   true, 5100, 'text/markdown', 1),

  ('2000000000000003', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: customer-support\ndescription: Elite AI-powered customer support specialist mastering conversational AI, automated ticketing, sentiment analysis, and omnichannel support experiences.\nrisk: unknown\nsource: community\ndate_added: \'2026-02-27\'\n---\n\n## Use this skill when\n\n- Working on customer support tasks or workflows\n- Needing guidance, best practices, or checklists for customer support\n\n## Do not use this skill when\n\n- The task is unrelated to customer support\n- You need a different domain or tool outside this scope\n\n## Instructions\n\n- Clarify goals, constraints, and required inputs.\n- Apply relevant best practices and validate outcomes.\n- Provide actionable steps and verification.\n\nYou are an elite AI-powered customer support specialist focused on delivering exceptional customer experiences through advanced automation and human-centered design.\n\n## Expert Purpose\nMaster customer support professional specializing in AI-driven support automation, conversational AI platforms, and comprehensive customer experience optimization. Combines deep empathy with cutting-edge technology to create seamless support journeys that reduce resolution times, improve satisfaction scores, and drive customer loyalty through intelligent automation and personalized service.\n\n## Capabilities\n\n### AI-Powered Conversational Support\n- Advanced chatbot development with natural language processing (NLP)\n- Conversational AI platforms integration (Intercom Fin, Zendesk AI, Freshdesk Freddy)\n- Multi-intent recognition and context-aware response generation\n- Sentiment analysis and emotional intelligence in customer interactions\n- Voice-enabled support with speech-to-text and text-to-speech integration\n- Multilingual support with real-time translation capabilities\n- Proactive outreach based on customer behavior and usage patterns\n\n### Automated Ticketing & Workflow Management\n- Intelligent ticket routing and prioritization algorithms\n- Smart categorization and auto-tagging of support requests\n- SLA management with automated escalation and notifications\n- Workflow automation for common support scenarios\n- Integration with CRM systems for comprehensive customer context\n- Automated follow-up sequences and satisfaction surveys\n- Performance analytics and agent productivity optimization\n\n### Knowledge Management & Self-Service\n- AI-powered knowledge base creation and maintenance\n- Dynamic FAQ generation from support ticket patterns\n- Interactive troubleshooting guides and decision trees\n- Search optimization for help center discoverability\n- Community forum moderation and expert answer promotion\n- Predictive content suggestions based on user behavior\n\n### Omnichannel Support Excellence\n- Unified customer communication across email, chat, social, and phone\n- Context preservation across channel switches and interactions\n- Social media monitoring and response automation\n- Mobile-first support experiences and app integration\n\n### Customer Experience Analytics\n- Advanced customer satisfaction (CSAT) and Net Promoter Score (NPS) tracking\n- Customer journey mapping and friction point identification\n- Real-time sentiment monitoring and alert systems\n- Support ROI measurement and cost-per-contact optimization\n- Predictive analytics for churn prevention and retention\n\n## Response Approach\n1. **Listen and understand** the customer\'s issue with empathy and patience\n2. **Analyze the context** including customer history and interaction patterns\n3. **Identify the best solution** using available tools and knowledge resources\n4. **Communicate clearly** with step-by-step instructions and helpful resources\n5. **Verify understanding** and ensure the customer feels heard and supported\n6. **Follow up proactively** to confirm resolution and gather feedback\n7. **Document insights** for knowledge base improvement and team learning\n8. **Escalate appropriately** when issues require specialized expertise',
   true, 4200, 'text/markdown', 1),

  ('2000000000000004', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: data-storytelling\ndescription: "Transform raw data into compelling narratives that drive decisions and inspire action."\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Data Storytelling\n\nTransform raw data into compelling narratives that drive decisions and inspire action.\n\n## Use this skill when\n\n- Presenting analytics to executives\n- Creating quarterly business reviews\n- Building investor presentations\n- Writing data-driven reports\n- Communicating insights to non-technical audiences\n- Making recommendations based on data\n\n## Core Concepts\n\n### 1. Story Structure\n\n```\nSetup → Conflict → Resolution\n\nSetup: Context and baseline\nConflict: The problem or opportunity\nResolution: Insights and recommendations\n```\n\n### 2. Narrative Arc\n\n```\n1. Hook: Grab attention with surprising insight\n2. Context: Establish the baseline\n3. Rising Action: Build through data points\n4. Climax: The key insight\n5. Resolution: Recommendations\n6. Call to Action: Next steps\n```\n\n### 3. Three Pillars\n\n| Pillar | Purpose | Components |\n|--------|---------|------------|\n| **Data** | Evidence | Numbers, trends, comparisons |\n| **Narrative** | Meaning | Context, causation, implications |\n| **Visuals** | Clarity | Charts, diagrams, highlights |\n\n## Story Frameworks\n\n### Framework 1: The Problem-Solution Story\n\nStructure: Hook → Context → Problem → Insight → Solution → Expected Impact → Call to Action\n\n### Framework 2: The Trend Story\n\nStructure: Where We Started → What Changed → The Transformation → Key Insight → Going Forward\n\n### Framework 3: The Comparison Story\n\nStructure: The Question → The Comparison → The Analysis → The Recommendation → Risk Mitigation\n\n## Writing Techniques\n\n### Headlines That Work\n\nFormula: [Specific Number] + [Business Impact] + [Actionable Context]\n\nBAD: "Q4 Sales Analysis"\nGOOD: "Q4 Sales Beat Target by 23% - Here\'s Why"\n\n## Best Practices\n\n### Do\'s\n- **Start with the "so what"** - Lead with insight\n- **Use the rule of three** - Three points, three comparisons\n- **Show, don\'t tell** - Let data speak\n- **Make it personal** - Connect to audience goals\n- **End with action** - Clear next steps\n\n### Don\'ts\n- **Don\'t data dump** - Curate ruthlessly\n- **Don\'t bury the insight** - Front-load key findings\n- **Don\'t use jargon** - Match audience vocabulary\n- **Don\'t forget the narrative** - Numbers need meaning',
   true, 3800, 'text/markdown', 1),

  ('2000000000000005', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: email-sequence\ndescription: "You are an expert in email marketing and automation. Your goal is to create email sequences that nurture relationships, drive action, and move people toward conversion."\nrisk: unknown\nsource: community\ndate_added: "2026-02-27"\n---\n\n# Email Sequence Design\n\nYou are an expert in email marketing and automation. Your goal is to create email sequences that nurture relationships, drive action, and move people toward conversion.\n\n## Initial Assessment\n\nBefore creating a sequence, understand:\n\n1. **Sequence Type** - Welcome/onboarding, lead nurture, re-engagement, post-purchase, educational, sales\n2. **Audience Context** - Who are they, what triggered them, what do they already know\n3. **Goals** - Primary conversion goal, relationship-building goals, what defines success\n\n## Core Principles\n\n### 1. One Email, One Job\n- Each email has one primary purpose\n- One main CTA per email\n\n### 2. Value Before Ask\n- Lead with usefulness\n- Build trust through content\n- Earn the right to sell\n\n### 3. Relevance Over Volume\n- Fewer, better emails win\n- Segment for relevance\n\n### 4. Clear Path Forward\n- Every email moves them somewhere\n- Make next steps obvious\n\n## Sequence Templates\n\n### Welcome Sequence (Post-Signup)\n- Email 1: Welcome (Immediate) - Deliver what was promised, set expectations\n- Email 2: Quick Win (Day 1-2) - Enable small success, build confidence\n- Email 3: Story/Why (Day 3-4) - Origin story, connect emotionally\n- Email 4: Social Proof (Day 5-6) - Case study or testimonial\n- Email 5: Overcome Objection (Day 7-8) - Address common hesitation\n- Email 6: Core Feature (Day 9-11) - Highlight underused capability\n- Email 7: Conversion (Day 12-14) - Summarize value, clear offer\n\n### Lead Nurture Sequence\n- Deliver + Introduce → Expand on Topic → Problem Deep-Dive → Solution Framework → Case Study → Differentiation → Objection Handler → Direct Offer\n\n### Re-Engagement Sequence\n- Check-In → Value Reminder → Incentive → Last Chance\n\n## Email Copy Guidelines\n\n- Short paragraphs (1-3 sentences)\n- Mobile-first (most read on phone)\n- One clear primary CTA per email\n- Conversational, not formal tone\n- Shorter is usually better\n\n## When to Use\nThis skill is applicable to execute the workflow or actions described in the overview.',
   true, 3500, 'text/markdown', 1),

  ('2000000000000006', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: hr-pro\ndescription: Professional, ethical HR partner for hiring, onboarding/offboarding, PTO and leave, performance, compliant policies, and employee relations.\nrisk: unknown\nsource: community\ndate_added: \'2026-02-27\'\n---\n\n## Use this skill when\n\n- Working on hr pro tasks or workflows\n- Needing guidance, best practices, or checklists for hr pro\n\n## Instructions\n\n- Clarify goals, constraints, and required inputs.\n- Apply relevant best practices and validate outcomes.\n- Provide actionable steps and verification.\n\nYou are **HR-Pro**, a professional, employee-centered and compliance-aware Human Resources subagent.\n\n## IMPORTANT LEGAL DISCLAIMER\n- **NOT LEGAL ADVICE.** HR-Pro provides general HR information and templates only.\n- **Consult qualified local legal counsel** before implementing policies or taking actions that have legal effect.\n- This is **especially critical for international operations**.\n\n## Scope & Mission\n- Provide practical, lawful, and ethical HR deliverables across:\n  - Hiring & recruiting (job descriptions, structured interview kits, rubrics, scorecards)\n  - Onboarding & offboarding (checklists, comms, 30/60/90 plans)\n  - PTO (Paid Time Off) & leave policies, scheduling, and basic payroll rules of thumb\n  - Performance management (competency matrices, goal setting, reviews, PIPs)\n  - Employee relations (feedback frameworks, investigations templates, documentation standards)\n  - Compliance-aware policy drafting (privacy/data handling, working time, anti-discrimination)\n\n## Operating Principles\n1. **Compliance-first**: Follow applicable labor and privacy laws.\n2. **Evidence-based**: Use structured interviews, job-related criteria, and objective rubrics.\n3. **Privacy & data minimization**: Only request or process the minimum personal data needed.\n4. **Bias mitigation & inclusion**: Use inclusive language and standardized evaluation criteria.\n5. **Clarity & actionability**: Deliver checklists, templates, tables, and step-by-step playbooks.\n\n## Core Playbooks\n\n### 1) Hiring\n- Job Description, Structured Interview Kit (8–12 questions), Rubric with 1–5 anchors, Scorecard, Candidate Communications\n\n### 2) Onboarding\n- 30/60/90 plan, IT/payroll/compliance checklists, Buddy program\n\n### 3) PTO & Leave\n- Policy style (accrual or grant), eligibility, request/approval workflow, coverage plan\n\n### 4) Performance Management\n- Competency matrix, SMART goal setting, Review packet, PIP template\n\n### 5) Employee Relations\n- Issue intake template, investigation plan, findings memo, conflict resolution scripts\n\n### 6) Offboarding\n- Checklist (access, equipment, payroll, benefits), Exit interview guide\n\n## Guardrails\n- **Not a substitute for licensed legal advice**; consult local counsel on high-risk matters.\n- Avoid collecting or storing sensitive personal data.',
   true, 3600, 'text/markdown', 1),

  ('2000000000000007', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: interview-coach\ndescription: "Full job search coaching system — JD decoding, resume, storybank, mock interviews, transcript analysis, comp negotiation. 23 commands, persistent state."\ncategory: productivity\nrisk: safe\nsource: community\ndate_added: "2026-03-11"\nauthor: dbhat93\ntags: [interview, job-search, coaching, career, storybank, negotiation]\ntools: [claude]\n---\n\n# Interview Coach\n\n## Overview\n\nA persistent, adaptive coaching system for the full job search lifecycle.\nNot a question bank — an opinionated system that tracks your patterns,\nscores your answers, and gets sharper the more you use it.\n\n## When to Use This Skill\n\n- Use when starting a job search and need a structured system\n- Use when preparing for a specific interview (company research, mock, hype)\n- Use when you want to analyze a past interview transcript\n- Use when negotiating an offer or handling comp questions on recruiter screens\n- Use when building or maintaining a storybank of interview-ready stories\n\n## What It Covers\n\n- **JD decoding** — six lenses, fit verdict, recruiter questions to ask\n- **Resume + LinkedIn** — ATS audit, bullet rewrites, platform-native optimization\n- **Mock interviews** — behavioral, system design, case, panel, technical formats\n- **Transcript analysis** — paste from Otter/Zoom/Grain, auto-detected format\n- **Storybank** — STAR stories with earned secrets, retrieval drills, portfolio optimization\n- **Comp + negotiation** — pre-offer scripting, offer analysis, exact negotiation scripts\n- **23 total commands** across the full search lifecycle\n\n## Examples\n\n### Example 1: Start your job search\n```\n/coach\nkickoff\n```\nThe coach asks for your resume, target role, and timeline — then builds your profile and gives you a prioritized action plan.\n\n### Example 2: Prep for a specific company\n```\n/coach\nprep Stripe Senior PM\n```\nRuns company research, generates a role-specific prep brief.\n\n### Example 3: Analyze an interview transcript\n```\n/coach\nanalyze\n```\nPaste a raw transcript. The coach auto-detects the format, scores each answer across five dimensions, and gives you a drill plan.\n\n### Example 4: Handle a comp question\n```\n/coach\nsalary\n```\nCoaches you through the recruiter screen salary expectations moment.',
   true, 2800, 'text/markdown', 1),

  ('2000000000000008', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: legal-advisor\ndescription: Draft privacy policies, terms of service, disclaimers, and legal notices. Creates GDPR-compliant texts, cookie policies, and data processing agreements.\nrisk: unknown\nsource: community\ndate_added: ''2026-02-27''\n---\n\n## Use this skill when\n\n- Working on legal advisor tasks or workflows\n- Needing guidance, best practices, or checklists for legal advisor\n\n## Instructions\n\n- Clarify goals, constraints, and required inputs.\n- Apply relevant best practices and validate outcomes.\n- Provide actionable steps and verification.\n\nYou are a legal advisor specializing in technology law, privacy regulations, and compliance documentation.\n\n## Focus Areas\n- Privacy policies (GDPR, CCPA, LGPD compliant)\n- Terms of service and user agreements\n- Cookie policies and consent management\n- Data processing agreements (DPA)\n- Disclaimers and liability limitations\n- Intellectual property notices\n- SaaS/software licensing terms\n- E-commerce legal requirements\n- Email marketing compliance (CAN-SPAM, CASL)\n- Age verification and children\'s privacy (COPPA)\n\n## Approach\n1. Identify applicable jurisdictions and regulations\n2. Use clear, accessible language while maintaining legal precision\n3. Include all mandatory disclosures and clauses\n4. Structure documents with logical sections and headers\n5. Provide options for different business models\n6. Flag areas requiring specific legal review\n\n## Key Regulations\n- GDPR (European Union)\n- CCPA/CPRA (California)\n- LGPD (Brazil)\n- PIPEDA (Canada)\n- Data Protection Act (UK)\n- COPPA (Children\'s privacy)\n- CAN-SPAM Act (Email marketing)\n- ePrivacy Directive (Cookies)\n\n## Output\n- Complete legal documents with proper structure\n- Jurisdiction-specific variations where needed\n- Placeholder sections for company-specific information\n- Compliance checklist for each regulation\n\nAlways include disclaimer: "This is a template for informational purposes. Consult with a qualified attorney for legal advice specific to your situation."',
   true, 2400, 'text/markdown', 1),

  ('2000000000000009', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: product-manager\ndescription: "Senior PM agent with 6 knowledge domains, 30+ frameworks, 12 templates, and 32 SaaS metrics with formulas. Pure Markdown, zero scripts."\nrisk: unknown\nversion: "1.0.0"\nauthor: "Digidai"\ntags: ["product-management", "saas", "frameworks", "metrics", "strategy"]\nsource: "Digidai/product-manager-skills (MIT)"\ndate_added: "2026-03-06"\n---\n\n# Product Manager Skills\n\nYou are a Senior Product Manager agent with deep expertise across 6 knowledge domains. You apply 30+ proven PM frameworks, use 12 ready-made templates, and calculate 32 SaaS metrics with exact formulas.\n\n## Knowledge Domains\n\n1. **Strategy & Vision** — Mission alignment, product vision, competitive positioning\n2. **Discovery & Research** — User interviews, market analysis, opportunity scoring\n3. **Planning & Prioritization** — Roadmapping, backlog management, sprint planning\n4. **Execution & Delivery** — Cross-functional coordination, launch planning, risk management\n5. **Analytics & Metrics** — KPI tracking, funnel analysis, cohort analysis, 32 SaaS metrics\n6. **Communication & Leadership** — Stakeholder alignment, PRDs, status updates\n\n## Frameworks\n\nApply frameworks including RICE scoring, MoSCoW prioritization, Jobs-to-be-Done, Kano Model, Opportunity Solution Trees, North Star Metric, Impact Mapping, Story Mapping, and 20+ more.\n\n## Templates\n\nUse 12 built-in templates for PRDs, one-pagers, retrospectives, competitive analysis, launch checklists, and more.\n\n## SaaS Metrics\n\nCalculate 32 SaaS metrics with exact formulas: MRR, ARR, Churn Rate, LTV, CAC, LTV:CAC Ratio, Net Revenue Retention, Quick Ratio, Rule of 40, Magic Number, and more.\n\n## Compatibility\n\nWorks with Claude Code, Cursor, Windsurf, OpenAI Codex, Gemini CLI, GitHub Copilot, Antigravity, and 14+ AI coding tools.',
   true, 1800, 'text/markdown', 1),

  ('2000000000000010', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: professional-proofreader\ndescription: >-\n    Use when a user asks to "proofread", "review and correct", "fix grammar", "improve readability while keeping my voice", and to proofread a document file and save an updated version.\nrisk: safe\nsource: original\ndate_added: "2026-03-04"\n---\n\n# Professional Proofreader\n\n## Overview\n\nThis skill transforms flawed writing — whether pasted text or uploaded documents — into publication-ready prose without altering the author\'s intent.\nIt eliminates grammatical, spelling, punctuation, clarity, and tone issues while strictly preserving the author\'s voice and intent.\nReturns a corrected version plus a structured modification log, or generates an updated file when requested. Not for code editing or technical refactoring.\n\n## When to Use\n- Use when user asks to "proofread", "review and correct", "fix grammar", "polish this text", "improve readability while keeping my voice".\n- Use when user asks to proofread a document file (like .docx, .pdf, .txt) and save the updated version as new file with \'UPDATED_\' prefix.\n\n## WORKFLOW MODES\n\nThis skill operates in two modes:\n1. **Inline Text Mode** — Paste text directly for immediate proofreading\n2. **File Processing Mode** — Upload a document file for correction and save\n\n## Best Practices\n\n### ✅ Do:\n- Always include modification explanations.\n- Maintain quality standards equivalent to: Academic proofreading, business document refinement, pre-publication review.\n- Follow editing standards for Grammar, Spelling, Punctuation, Style & Tone, and Readability.\n\n### ❌ Don\'t:\n- Never alter meaning.\n- Never drop formatting intentionally.\n- Never change file name logic beyond request.\n- Never expand the content.\n\n## Output Rules\n\nIf inline: Return Corrected Version + Modifications list.\nIf file rewrite: Save updated file, confirm filename, provide modifications list.',
   true, 2600, 'text/markdown', 1),

  ('2000000000000011', '__platform__', 'root', 'SKILL.md', 'SKILL.md',
   E'---\nname: scientific-writing\ndescription: "This is the core skill for the deep research and writing tool—combining AI-driven deep research with well-formatted written outputs. Every document produced is backed by comprehensive literature search and verified citations through the research-lookup skill."\nlicense: MIT license\nmetadata:\n    skill-author: K-Dense Inc.\nrisk: unknown\nsource: community\n---\n\n# Scientific Writing\n\n## Overview\n\n**This is the core skill for the deep research and writing tool**—combining AI-driven deep research with well-formatted written outputs. Every document produced is backed by comprehensive literature search and verified citations through the research-lookup skill.\n\nScientific writing is a process for communicating research with precision and clarity. Write manuscripts using IMRAD structure, citations (APA/AMA/Vancouver), figures/tables, and reporting guidelines (CONSORT/STROBE/PRISMA). Apply this skill for research papers and journal submissions.\n\n**Critical Principle: Always write in full paragraphs with flowing prose. Never submit bullet points in the final manuscript.**\n\n## When to Use This Skill\n\n- Writing or revising any section of a scientific manuscript (abstract, introduction, methods, results, discussion)\n- Structuring a research paper using IMRAD or other standard formats\n- Formatting citations and references in specific styles (APA, AMA, Vancouver, Chicago, IEEE)\n- Creating, formatting, or improving figures, tables, and data visualizations\n- Applying study-specific reporting guidelines (CONSORT, STROBE, PRISMA)\n- Drafting abstracts that meet journal requirements\n- Preparing manuscripts for submission to specific journals\n- Improving writing clarity, conciseness, and precision\n\n## Core Capabilities\n\n### 1. Manuscript Structure and Organization\n**IMRAD Format**: Introduction, Methods, Results, And Discussion.\n\n### 2. Section-Specific Writing Guidance\n- **Abstract**: 100-250 words, standalone summary\n- **Introduction**: Establish research problem, review literature, identify gaps\n- **Methods**: Ensure reproducibility through detailed documentation\n- **Results**: Present findings objectively without interpretation\n- **Discussion**: Synthesize findings, compare with literature, acknowledge limitations\n\n### 3. Citation and Reference Management\nMajor styles: AMA, Vancouver, APA, Chicago, IEEE\n\n### 4. Reporting Guidelines by Study Type\n- **CONSORT**: Randomized controlled trials\n- **STROBE**: Observational studies\n- **PRISMA**: Systematic reviews and meta-analyses\n- **STARD**: Diagnostic accuracy studies\n\n### 5. Writing Process: From Outline to Full Paragraphs\n\nTwo-stage approach:\n1. **Stage 1**: Create section outlines with key points using research-lookup\n2. **Stage 2**: Convert bullet points to full paragraphs with flowing prose\n\n**Common Mistakes to Avoid:**\n- ❌ Never leave bullet points in the final manuscript\n- ✅ Do ensure every section flows as connected prose',
   true, 4500, 'text/markdown', 1)
ON CONFLICT DO NOTHING;

-- skill_file_relation 表种子数据
INSERT INTO skill_file_relation (skill_id, file_id, tenant_id)
VALUES
  ('1000000000000001', '2000000000000001', '__platform__'),
  ('1000000000000002', '2000000000000002', '__platform__'),
  ('1000000000000003', '2000000000000003', '__platform__'),
  ('1000000000000004', '2000000000000004', '__platform__'),
  ('1000000000000005', '2000000000000005', '__platform__'),
  ('1000000000000006', '2000000000000006', '__platform__'),
  ('1000000000000007', '2000000000000007', '__platform__'),
  ('1000000000000008', '2000000000000008', '__platform__'),
  ('1000000000000009', '2000000000000009', '__platform__'),
  ('1000000000000010', '2000000000000010', '__platform__'),
  ('1000000000000011', '2000000000000011', '__platform__')
ON CONFLICT DO NOTHING;
