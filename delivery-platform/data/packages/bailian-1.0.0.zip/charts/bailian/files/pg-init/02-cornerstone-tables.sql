-- =============================================================================
-- Cornerstone (beebot_platform) - PostgreSQL 16
-- 仅保留仍在使用的表: api_key, xspace_config
-- =============================================================================

\connect beebot_platform

-- ---------------------------------------------------------------------------
-- Shared trigger function for ON UPDATE CURRENT_TIMESTAMP emulation
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.gmt_modified = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- 1. api_key
--    (ON UPDATE CURRENT_TIMESTAMP → trigger)
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS api_key;
CREATE TABLE api_key (
    id BIGSERIAL NOT NULL,
    api_key varchar(128) NOT NULL,
    user_id BIGINT NOT NULL,
    workspace_id BIGINT NOT NULL,
    dept_id BIGINT DEFAULT NULL,
    outer_key varchar(128) DEFAULT NULL,
    parent_outer_key varchar(128) DEFAULT NULL,
    description varchar(255) DEFAULT NULL,
    gmt_create TIMESTAMP NOT NULL,
    gmt_modified TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gmt_expire TIMESTAMP NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_key UNIQUE (api_key)
);
CREATE INDEX idx_api_key_user_id ON api_key (user_id);
CREATE INDEX idx_api_key_workspace_id ON api_key (workspace_id);

COMMENT ON COLUMN api_key.id IS '主键';
COMMENT ON COLUMN api_key.api_key IS 'API密钥';
COMMENT ON COLUMN api_key.user_id IS '用户主键';
COMMENT ON COLUMN api_key.workspace_id IS '工作空间ID';
COMMENT ON COLUMN api_key.dept_id IS '部门ID';
COMMENT ON COLUMN api_key.outer_key IS '外部键';
COMMENT ON COLUMN api_key.parent_outer_key IS '父外部键';
COMMENT ON COLUMN api_key.description IS '描述信息';
COMMENT ON COLUMN api_key.gmt_create IS '创建时间';
COMMENT ON COLUMN api_key.gmt_modified IS '修改时间';
COMMENT ON COLUMN api_key.gmt_expire IS '过期时间';
COMMENT ON TABLE api_key IS 'API密钥表';

CREATE TRIGGER trg_api_key_update_gmt_modified
    BEFORE UPDATE ON api_key
    FOR EACH ROW
    EXECUTE FUNCTION update_modified_column();

-- ---------------------------------------------------------------------------
-- 2. xspace_config
-- ---------------------------------------------------------------------------
DROP TABLE IF EXISTS xspace_config;
CREATE TABLE xspace_config (
    id BIGSERIAL NOT NULL,
    gmt_modified TIMESTAMP NOT NULL,
    code varchar(512) DEFAULT NULL,
    config_value text,
    PRIMARY KEY (id)
);

COMMENT ON COLUMN xspace_config.id IS '主键';
COMMENT ON COLUMN xspace_config.gmt_modified IS '修改时间';
COMMENT ON COLUMN xspace_config.code IS 'config code';
COMMENT ON COLUMN xspace_config.config_value IS '配置项的值';
COMMENT ON TABLE xspace_config IS '系统配置项';

INSERT INTO xspace_config VALUES (1,'2025-12-02 17:23:11','CORNERSTONE_CONFIG','{"product": [{"p_efm": "product/p_efm.product.cfg"}],"goods": [{"g_efm": "goods/g_efm.goods.cfg"}],"module": [{"m_efm": "module/m_efm.module.cfg","m_authCenter": "module/m_authCenter.module.cfg"}]}'),(2,'2026-01-04 10:17:50','SSO','{"ssoEnable":1,"tokenUrl":"http://localhost:7001/api/auth/getUserInfo","autoCreateUser":1,"logoutUrl":"http://localhost:7001/api/auth/oidc/logout","ssoSingleDeptId":8002,"ssoSecret":"67318980703e48f884fcaeeb88a88fef","returnUrl":"http://8.136.35.64:7001/api/auth/isvCallback?from=http://118.178.188.162:31081/"}');
