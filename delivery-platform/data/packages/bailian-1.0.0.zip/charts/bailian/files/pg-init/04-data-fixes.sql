-- =============================================================================
-- 本地开发环境数据修复
-- 仅保留仍在使用的 xspace_config 相关修复
-- =============================================================================

\connect beebot_platform

-- =============================================================================
-- 1. 为 xspace_config.code 添加唯一约束（如不存在）
-- =============================================================================
CREATE UNIQUE INDEX IF NOT EXISTS uk_xspace_config_code ON xspace_config (code);

-- =============================================================================
-- 2. xspace_config: 更新 CORNERSTONE_CONFIG 为正确的本地配置文件路径
--    Cornerstone 通过此配置加载 product/goods/module 的 .cfg 文件
--    配置文件由 cornerstone 容器启动脚本创建在:
--    /home/admin/upload/CORNERSTONE_CONFIG/ 下
-- =============================================================================
UPDATE xspace_config
SET config_value = '{"product": [{"p_efm": "product/p_efm.product.cfg"}],"goods": [{"g_efm": "goods/g_efm.goods.cfg"}],"module": [{"m_efm": "module/m_efm.module.cfg","m_authCenter": "module/m_authCenter.module.cfg"}]}'
WHERE code = 'CORNERSTONE_CONFIG';

-- =============================================================================
-- 3. SSO 配置: 更新为本地环境地址
-- =============================================================================
INSERT INTO xspace_config (code, config_value, gmt_modified)
VALUES ('SSO', '{"ssoEnable":1,"tokenUrl":"http://localhost:7001/api/auth/getUserInfo","autoCreateUser":1,"logoutUrl":"http://localhost:7001/api/auth/oidc/logout","ssoSingleDeptId":8002,"ssoSecret":"67318980703e48f884fcaeeb88a88fef","returnUrl":"http://localhost:7001/api/auth/isvCallback"}', NOW())
ON CONFLICT (code) DO UPDATE SET
  config_value = EXCLUDED.config_value,
  gmt_modified = NOW();

-- =============================================================================
-- 4. Skill 表结构迁移（幂等，适用于已运行的生产库）
-- =============================================================================

-- 4a. skill_file_relation: 重命名 space_id / workspace_id → tenant_id
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'skill_file_relation' AND column_name = 'space_id'
    ) THEN
        ALTER TABLE skill_file_relation RENAME COLUMN space_id TO tenant_id;
    END IF;
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'skill_file_relation' AND column_name = 'workspace_id'
    ) THEN
        ALTER TABLE skill_file_relation RENAME COLUMN workspace_id TO tenant_id;
    END IF;
END $$;

-- 4b. skill_aibaas_relation: 重命名 space_id / workspace_id → tenant_id
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'skill_aibaas_relation' AND column_name = 'space_id'
    ) THEN
        ALTER TABLE skill_aibaas_relation RENAME COLUMN space_id TO tenant_id;
    END IF;
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'skill_aibaas_relation' AND column_name = 'workspace_id'
    ) THEN
        ALTER TABLE skill_aibaas_relation RENAME COLUMN workspace_id TO tenant_id;
    END IF;
END $$;

-- 4c. skill_file: 删除已废弃的 skill_id 列（若仍存在）
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'skill_file' AND column_name = 'skill_id'
    ) THEN
        ALTER TABLE skill_file DROP COLUMN skill_id;
    END IF;
END $$;

-- =============================================================================
-- 5. 重置所有 BIGSERIAL 序列到当前最大 ID
--    MySQL dump 导入时使用了显式 ID，PostgreSQL 的序列不会自动推进，
--    导致后续 INSERT 主键冲突: duplicate key value violates unique constraint
-- =============================================================================
DO $$
DECLARE
    r RECORD;
    max_val BIGINT;
BEGIN
    FOR r IN
        SELECT t.table_name,
               pg_get_serial_sequence(t.table_name, 'id') AS seq_name
        FROM information_schema.tables t
        JOIN information_schema.columns c
            ON t.table_name = c.table_name AND t.table_schema = c.table_schema
        WHERE t.table_schema = 'public'
          AND t.table_type = 'BASE TABLE'
          AND c.column_name = 'id'
          AND c.column_default LIKE 'nextval%'
    LOOP
        EXECUTE format('SELECT COALESCE(max(id), 0) FROM %I', r.table_name) INTO max_val;
        IF max_val > 0 THEN
            PERFORM setval(r.seq_name, max_val);
        END IF;
    END LOOP;
END $$;

-- =============================================================================
-- 11. pairag: Stamp Alembic migration head for RAG service
--     The RAG service's env.py calls create_all() to build the latest schema
--     on first start. Without a pre-stamped alembic_version, Alembic will try
--     to run ALL historical migrations against the already-up-to-date schema,
--     failing on operations like dropping non-existent constraints
--     (e.g. "pai_knowledgebase_name_key" does not exist).
--     Pre-stamping the head revision prevents this.
-- =============================================================================
\connect pairag

CREATE TABLE IF NOT EXISTS alembic_version (
    version_num VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- 将表所有权转给 bailian 用户，确保 RAG 服务在后续升级中可更新 alembic_version
ALTER TABLE alembic_version OWNER TO bailian;

INSERT INTO alembic_version (version_num)
SELECT '4fc61e385531'
WHERE NOT EXISTS (SELECT 1 FROM alembic_version);
