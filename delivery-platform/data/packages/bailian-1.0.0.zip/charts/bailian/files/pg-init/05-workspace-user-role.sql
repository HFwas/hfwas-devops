-- =============================================================================
-- workspace_user_role 表（仅 DDL，无种子数据）
-- 用户→空间→角色分配关系（配合 Keycloak 角色定义使用）
--
-- 角色类型:
--   SYSTEM: 系统预置角色（workspace-admin, plain-user），定义为 Keycloak Realm Role
--   CUSTOM: 自定义角色，定义为 Keycloak SubGroup（每空间独立）
--
-- 全局角色 system-admin 不需要此表记录，直接通过 Keycloak Role Mapping 判断。
--
-- 种子数据由 setup-admin-roles.sh 在 Keycloak 初始化完成后写入，
-- 使用真实 Keycloak user UUID，避免 legacy ID 占位。
-- =============================================================================

\connect beebot_platform

CREATE TABLE IF NOT EXISTS workspace_user_role (
    id              BIGSERIAL       PRIMARY KEY,
    user_id         VARCHAR(64)     NOT NULL,   -- Keycloak userId (UUID)
    role_id         VARCHAR(128)    NOT NULL,   -- 角色标识（Realm Role name 或 SubGroup name）
    type            VARCHAR(16)     NOT NULL,   -- SYSTEM: 系统预置角色; CUSTOM: 自定义角色
    workspace_id    VARCHAR(64)     NOT NULL,   -- agentId（= 顶级 Group name）
    created_at      TIMESTAMP       NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_wur_user_role_workspace UNIQUE (user_id, role_id, workspace_id)
);

CREATE INDEX IF NOT EXISTS idx_wur_user_workspace ON workspace_user_role(user_id, workspace_id);
CREATE INDEX IF NOT EXISTS idx_wur_workspace_role ON workspace_user_role(workspace_id, role_id);

COMMENT ON TABLE  workspace_user_role IS '用户-空间-角色分配表（配合 Keycloak 角色定义使用）';
COMMENT ON COLUMN workspace_user_role.user_id IS 'Keycloak 用户 UUID';
COMMENT ON COLUMN workspace_user_role.role_id IS '角色标识：Realm Role name（系统预置）或 SubGroup name（自定义）';
COMMENT ON COLUMN workspace_user_role.type IS '角色类型：SYSTEM=系统预置角色，CUSTOM=自定义角色';
COMMENT ON COLUMN workspace_user_role.workspace_id IS '工作空间ID（= Keycloak 顶级 Group name = agentId）';
COMMENT ON COLUMN workspace_user_role.created_at IS '创建时间';
