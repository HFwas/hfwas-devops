-- agentscope sequence bootstrap（随 pg-init 执行）
-- 部署前填写 VALUES（客户 v2 MAX(id)）；历史 data.sql import 之后禁止重跑
-- 目标路径：enterprise-agentscope-platform/docker/config/pg-init/
--           enterprise-agentscope-platform/helm/bailian/files/pg-init/

\connect agentscope

BEGIN;

DO $$
DECLARE
    r RECORD;
    seq_name TEXT;
    seq_rel TEXT;
    target BIGINT;
    current_last BIGINT;
    id_reserve BIGINT := 2000000;
BEGIN
    FOR r IN
        SELECT b.table_name,
               b.max_id,
               a.attname AS column_name,
               n.nspname AS schema_name
        FROM (VALUES
                  ('account',                      100000),
                  ('api_key',                      100000),
                  ('app_task_event',             100000),
                  ('application',             400000),
                  ('application_component',      100000),
                  ('application_execution_records', 700000),
                  ('application_personal_hint',   100000),
                  ('application_task_records', 700000),
                  ('application_version',       400000),
                  ('audit_log',                  100000),
                  ('category',                    100000),
                  ('chat_messages',              600000),
                  ('document',                     100000),
                  ('eval_annotation',              100000),
                  ('eval_data_item',              100000),
                  ('eval_message',                 100000),
                  ('eval_output_item',            100000),
                  ('eval_result_item',             100000),
                  ('eval_set',                    100000),
                  ('eval_set_task',               100000),
                  ('eval_set_version',            100000),
                  ('eval_target',                 100000),
                  ('eval_task',                   100000),
                  ('knowledge_base',               100000),
                  ('mcp_server',                 100000),
                  ('model',                      100000),
                  ('plugin',                       100000),
                  ('provider',                    100000),
                  ('reference',                  100000),
                  ('skill',                        100000),
                  ('skill_aibaas_relation',          100000),
                  ('skill_file',                  100000),
                  ('skill_file_relation',         100000),
                  ('skill_notification',           100000),
                  ('skill_publish_request',        100000),
                  ('skill_square_listing',         100000),
                  ('skill_trial_agent',            100000),
                  ('skill_trial_config',           100000),
                  ('skill_version',                100000),
                  ('tenant',                       100000),
                  ('tool',                         100000),
                  ('trace_resource_meta',          100000),
                  ('workspace',                 100000),
                  ('workspace_object',           100000),
                  ('reference_draft',           100000)
             ) AS b(table_name, max_id)
        JOIN pg_class c
          ON c.relname = b.table_name AND c.relkind = 'r'
        JOIN pg_namespace n
          ON n.oid = c.relnamespace AND n.nspname = 'public'
        JOIN pg_attribute a
          ON a.attrelid = c.oid
         AND a.attnum > 0
         AND NOT a.attisdropped
         AND pg_get_serial_sequence(
               quote_ident(n.nspname) || '.' || quote_ident(c.relname),
               a.attname) IS NOT NULL
    LOOP
        seq_name := pg_get_serial_sequence(
            quote_ident(r.schema_name) || '.' || quote_ident(r.table_name),
            r.column_name
        );
        seq_rel := split_part(seq_name, '.', 2);

        target := GREATEST(r.max_id + id_reserve, 1);

        SELECT s.last_value INTO current_last
        FROM pg_sequences s
        WHERE s.schemaname = r.schema_name
          AND s.sequencename = seq_rel;

        IF current_last IS NOT NULL AND current_last >= target THEN
            RAISE NOTICE 'skip %(last=% >= target=%)', seq_name, current_last, target;
            CONTINUE;
        END IF;

        PERFORM setval(seq_name, target, true);
        RAISE NOTICE 'setval(%) max=% reserve=% next=%',
            seq_name, r.max_id, id_reserve, target + 1;
    END LOOP;
END $$;

COMMIT;

SELECT sequencename, last_value
FROM pg_sequences
WHERE schemaname = 'public'
ORDER BY sequencename;
