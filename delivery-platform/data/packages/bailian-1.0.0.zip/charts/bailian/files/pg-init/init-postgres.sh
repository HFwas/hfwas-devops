#!/bin/bash
# =============================================================================
# PostgreSQL 数据库初始化脚本
# 等待 PG 就绪后，检查是否需要初始化，按顺序执行 SQL 脚本
# 环境变量 PGHOST / PGPORT / PGUSER / PGPASSWORD / PGDATABASE 由 Job 注入
# =============================================================================
set -e

MAX_RETRIES=30
RETRY_INTERVAL=5

echo "⏳ 等待 PostgreSQL ($PGHOST:$PGPORT) 就绪..."
for i in $(seq 1 $MAX_RETRIES); do
  if pg_isready -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" > /dev/null 2>&1; then
    echo "✅ PostgreSQL 已就绪"
    break
  fi
  if [ "$i" = "$MAX_RETRIES" ]; then
    echo "❌ PostgreSQL 未在 $((MAX_RETRIES * RETRY_INTERVAL))s 内就绪，退出"
    exit 1
  fi
  echo "  重试 $i/$MAX_RETRIES..."
  sleep $RETRY_INTERVAL
done

# ---------- 检查是否需要初始化 ----------
# 检查 agentscope 库中的 application 表是否存在（数据库可能已由 Terraform 创建但没有表）
TABLE_EXISTS=$(psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d agentscope -tAc \
  "SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='application'" 2>/dev/null || echo "")

if [ "$TABLE_EXISTS" = "1" ]; then
  echo "✅ 数据库 schema 已初始化（application 表已存在）"

  # ---------- 增量迁移：始终执行（所有语句均幂等） ----------
  # 无论表是否已存在，均执行 06-migrations.sql，确保新增字段、新表、种子数据更新在每次
  # helm upgrade 时都能应用。06-migrations.sql 中所有 DDL 使用 IF NOT EXISTS，
  # DML 使用 ON CONFLICT DO UPDATE / DO NOTHING，可安全重复执行。
  echo "📦 执行增量迁移（幂等，每次升级均运行）..."
  for f in /init/sql/06-migrations*.sql; do
    if [ -f "$f" ]; then
      echo "  ▶ $(basename "$f")"
      psql -v ON_ERROR_STOP=0 -v pg_user="$PGUSER" -f "$f"
    fi
  done
  echo "✅ 增量迁移完成"
  exit 0
fi

# ---------- 全量初始化 SQL ----------
echo "📦 开始执行数据库初始化脚本..."
for f in /init/sql/*.sql; do
  echo "  ▶ $(basename "$f")"
  psql -v ON_ERROR_STOP=1 -v pg_user="$PGUSER" -f "$f"
done

echo "✅ PostgreSQL 数据库初始化完成"
