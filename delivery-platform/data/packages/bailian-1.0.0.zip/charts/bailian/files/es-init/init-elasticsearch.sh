#!/bin/bash
# =============================================================================
# Elasticsearch 索引初始化脚本
# 等待 ES 就绪后创建 Telemetry 所需的 ingest pipeline、索引和别名
# =============================================================================
set -e

ES_URL="${ELASTICSEARCH_URL:-http://elasticsearch:9200}"
MAX_RETRIES=30
RETRY_INTERVAL=5

CURL_AUTH=""
if [ -n "$ELASTICSEARCH_USERNAME" ] && [ -n "$ELASTICSEARCH_PASSWORD" ]; then
  CURL_AUTH="-u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD}"
fi

echo "⏳ 等待 Elasticsearch ($ES_URL) 就绪..."
for i in $(seq 1 $MAX_RETRIES); do
  if curl -sf $CURL_AUTH "$ES_URL/_cluster/health" > /dev/null 2>&1; then
    echo "✅ Elasticsearch 已就绪"
    break
  fi
  if [ "$i" = "$MAX_RETRIES" ]; then
    echo "❌ Elasticsearch 未在 $((MAX_RETRIES * RETRY_INTERVAL))s 内就绪，退出"
    exit 1
  fi
  sleep $RETRY_INTERVAL
done

# ---------- 1. Ingest Pipeline ----------
if curl -sf $CURL_AUTH "$ES_URL/_ingest/pipeline/parsing_loongsuite_traces" > /dev/null 2>&1; then
  echo "✅ Pipeline parsing_loongsuite_traces 已存在，跳过"
else
  echo "📦 创建 ingest pipeline: parsing_loongsuite_traces"
  curl -sf $CURL_AUTH -X PUT "$ES_URL/_ingest/pipeline/parsing_loongsuite_traces" \
    -H 'Content-Type: application/json' \
    -d @/init/parsing_loongsuite_traces.json
  echo ""
fi

# ---------- 2. loongsuite_traces 索引 ----------
if curl -sf $CURL_AUTH "$ES_URL/loongsuite_traces" > /dev/null 2>&1; then
  echo "✅ Index loongsuite_traces 已存在，跳过"
else
  echo "📦 创建索引: loongsuite_traces"
  curl -sf $CURL_AUTH -X PUT "$ES_URL/loongsuite_traces" \
    -H 'Content-Type: application/json' \
    -d @/init/loongsuite_traces.json
  echo ""

  echo "📦 创建别名: loongsuite_traces_alias"
  curl -sf $CURL_AUTH -X POST "$ES_URL/_aliases" \
    -H 'Content-Type: application/json' \
    -d '{"actions":[{"add":{"index":"loongsuite_traces","alias":"loongsuite_traces_alias"}}]}'
  echo ""
fi

# ---------- 3. span_feedback 索引 ----------
if curl -sf $CURL_AUTH "$ES_URL/span_feedback" > /dev/null 2>&1; then
  echo "✅ Index span_feedback 已存在，跳过"
else
  echo "📦 创建索引: span_feedback"
  curl -sf $CURL_AUTH -X PUT "$ES_URL/span_feedback" \
    -H 'Content-Type: application/json' \
    -d @/init/span_feedback.json
  echo ""

  echo "📦 创建别名: span_feedback_alias"
  curl -sf $CURL_AUTH -X POST "$ES_URL/_aliases" \
    -H 'Content-Type: application/json' \
    -d '{"actions":[{"add":{"index":"span_feedback","alias":"span_feedback_alias"}}]}'
  echo ""
fi

echo "✅ Elasticsearch 索引初始化完成"
