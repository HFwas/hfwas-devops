{{/*
Expand the name of the chart.
*/}}
{{- define "bailian.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "bailian.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "bailian.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "bailian.labels" -}}
helm.sh/chart: {{ include "bailian.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: bailian
{{- end }}

{{/*
Selector labels for a specific component
Usage: {{ include "bailian.selectorLabels" (dict "component" "postgres" "Release" .Release) }}
*/}}
{{- define "bailian.selectorLabels" -}}
app.kubernetes.io/name: {{ .component }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Image pull secrets
*/}}
{{- define "bailian.imagePullSecrets" -}}
{{- if .Values.global.imagePullSecrets }}
imagePullSecrets:
{{- range .Values.global.imagePullSecrets }}
  - name: {{ . }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Registry prefix helper — returns "registry/" when set, "" when empty
*/}}
{{- define "bailian.registry" -}}
{{- if .Values.global.imageRegistry }}{{- .Values.global.imageRegistry }}/{{- end }}
{{- end }}

{{/*
Image tag helper — component tag > global.image.tag > fallback
用法: {{ include "bailian.imageTag" (dict "component" .Values.xxx.image.tag "global" .Values.global) }}
  - 优先使用组件级 tag（values 文件中显式指定的版本）
  - 回退到 global.image.tag（deploy-ci.sh 通过 --set 传入）
*/}}
{{- define "bailian.imageTag" -}}
{{- .component | default (dig "image" "tag" .component .global) -}}
{{- end }}


{{/*
Standard metadata for a component
Usage: {{ include "bailian.componentMeta" (dict "component" "postgres" "Chart" .Chart "Release" .Release) }}
*/}}
{{- define "bailian.componentMeta" -}}
labels:
  {{- include "bailian.labels" . | nindent 2 }}
  app.kubernetes.io/component: {{ .component }}
  {{- include "bailian.selectorLabels" (dict "component" .component "Release" .Release) | nindent 2 }}
{{- end }}

{{/* ================================================================
     Elasticsearch helpers
     ================================================================ */}}

{{/*
Resolved Elasticsearch URL.
Returns external ES URL when internal ES is disabled but external is enabled,
otherwise falls back to internal "http://elasticsearch:<port>".
*/}}
{{- define "bailian.esUrl" -}}
{{- if .Values.elasticsearch.enabled -}}
http://elasticsearch:{{ .Values.elasticsearch.port }}
{{- else if .Values.externalElasticsearch.enabled -}}
{{ .Values.externalElasticsearch.url }}
{{- else -}}
{{- end -}}
{{- end }}

{{- define "bailian.esUsername" -}}
{{- if and (not .Values.elasticsearch.enabled) .Values.externalElasticsearch.enabled -}}
{{ .Values.externalElasticsearch.username | default "" }}
{{- end -}}
{{- end }}

{{- define "bailian.esPassword" -}}
{{- if and (not .Values.elasticsearch.enabled) .Values.externalElasticsearch.enabled -}}
{{ .Values.externalElasticsearch.password | default "" }}
{{- end -}}
{{- end }}

{{/*
Env block: EXTERNAL_ELASTICSEARCH_URIS / USERNAME / PASSWORD.
Used by Java services (console, infrastructure, workflow) and loongcollector.
Usage: {{ include "bailian.env.elasticsearch" . | nindent 12 }}
*/}}
{{- define "bailian.env.elasticsearch" -}}
- name: EXTERNAL_ELASTICSEARCH_URIS
  value: {{ include "bailian.esUrl" . | quote }}
- name: EXTERNAL_ELASTICSEARCH_USERNAME
  value: {{ include "bailian.esUsername" . | quote }}
- name: EXTERNAL_ELASTICSEARCH_PASSWORD
  value: {{ include "bailian.esPassword" . | quote }}
{{- end }}

{{/*
Env block: ELASTICSEARCH_URL / USER / PASSWORD for RAG service.
Falls back to "elastic" for user/password when using internal ES.
Usage: {{ include "bailian.env.elasticsearch.rag" . | nindent 12 }}
*/}}
{{- define "bailian.env.elasticsearch.rag" -}}
- name: ELASTICSEARCH_URL
  value: {{ include "bailian.esUrl" . | quote }}
- name: ELASTICSEARCH_USER
  value: {{ if and (not .Values.elasticsearch.enabled) .Values.externalElasticsearch.enabled }}{{ .Values.externalElasticsearch.username | default "elastic" | quote }}{{ else }}"elastic"{{ end }}
- name: ELASTICSEARCH_PASSWORD
  value: {{ if and (not .Values.elasticsearch.enabled) .Values.externalElasticsearch.enabled }}{{ .Values.externalElasticsearch.password | default "elastic" | quote }}{{ else }}"elastic"{{ end }}
{{- end }}

{{/* ================================================================
     LoongCollector / Tracing helpers
     ================================================================ */}}

{{/*
Resolved LoongCollector OTLP endpoint (empty string when disabled).
*/}}
{{- define "bailian.loongcollectorEndpoint" -}}
{{- if .Values.loongcollector.enabled -}}
http://loongcollector:{{ .Values.loongcollector.port }}
{{- end -}}
{{- end }}

{{/*
Whether tracing should be enabled (ES available + collector available).
Returns "true" or "false".
*/}}
{{- define "bailian.traceEnabled" -}}
{{- if and .Values.loongcollector.enabled (or .Values.elasticsearch.enabled .Values.externalElasticsearch.enabled) -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Env block: Python service tracing (agent-runtime, protocol).
TRACE_ENABLE_REPORT + TRACE_ENDPOINT.
Usage: {{ include "bailian.env.tracing.python" . | nindent 12 }}
*/}}
{{- define "bailian.env.tracing.python" -}}
- name: TRACE_ENABLE_REPORT
  value: {{ include "bailian.traceEnabled" . | quote }}
- name: TRACE_ENDPOINT
  value: {{ include "bailian.loongcollectorEndpoint" . | quote }}
{{- end }}

{{/*
Env block: Java Agent tracing (console, infrastructure, workflow).
OTEL_EXPORTER_OTLP_PROTOCOL + OTEL_EXPORTER_OTLP_ENDPOINT + OTEL_LOGS_EXPORTER.
Usage: {{ include "bailian.env.tracing.java" . | nindent 12 }}
*/}}
{{- define "bailian.env.tracing.java" -}}
- name: OTEL_EXPORTER_OTLP_PROTOCOL
  value: {{ if .Values.loongcollector.enabled }}"http/protobuf"{{ else }}""{{ end }}
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: {{ include "bailian.loongcollectorEndpoint" . | quote }}
- name: OTEL_LOGS_EXPORTER
  value: "none"
{{- end }}

{{/*
Env block: RAG service tracing.
TRACE_ENDPOINT + TRACE_EXPORTER_TYPE.
Usage: {{ include "bailian.env.tracing.rag" . | nindent 12 }}
*/}}
{{- define "bailian.env.tracing.rag" -}}
- name: TRACE_ENDPOINT
  value: {{ include "bailian.loongcollectorEndpoint" . | quote }}
- name: TRACE_EXPORTER_TYPE
  value: "http"
{{- end }}

{{/*
Env block: Workflow tracing (needs both Python-style + Java Agent).
Usage: {{ include "bailian.env.tracing.workflow" . | nindent 12 }}
*/}}
{{- define "bailian.env.tracing.workflow" -}}
{{ include "bailian.env.tracing.python" . }}
{{ include "bailian.env.tracing.java" . }}
{{- end }}

{{/*
workflow / workflow-worker / workflow-worker-async 共用的环境变量。
含节点执行会读到的配置。WORKFLOW_JAVA_OPTS、LOG_FILE_PREFIX（各角色后缀不同）
以及仅主进程使用的 JWT_* / GITHUB_* / KEYCLOAK_* 不要放进这里。
Usage: {{ include "workflow.env.common" . | nindent 12 }}
*/}}
{{- define "workflow.env.common" -}}
- name: JAVA_OPTS
  value: >-
    -Xms{{ .Values.workflow.jvm.xms }} -Xmx{{ .Values.workflow.jvm.xmx }}
    --add-opens jdk.naming.rmi/com.sun.jndi.rmi.registry=ALL-UNNAMED
    --add-opens java.base/java.net=ALL-UNNAMED
    --add-opens java.base/java.lang=ALL-UNNAMED
    --add-opens java.base/java.lang.reflect=ALL-UNNAMED
    --add-opens java.base/java.math=ALL-UNNAMED
    --add-opens java.base/java.util=ALL-UNNAMED
    --add-opens java.base/java.text=ALL-UNNAMED
    --add-opens java.base/java.time=ALL-UNNAMED
    --add-opens java.base/sun.security.action=ALL-UNNAMED
    --add-opens java.base/sun.net=ALL-UNNAMED
    -Dsun.misc.URLClassPath.disableJarChecking=true
- name: MALLOC_ARENA_MAX
  value: "2"
- name: STORAGE_PATH
  value: {{ .Values.workflow.storagePath | quote }}
- name: DEFAULT_WORKSPACE_ID
  value: {{ .Values.workflow.defaultWorkspaceId | quote }}
- name: CORNERSTONE_BASE_URL
  value: {{ .Values.workflow.cornerstoneBaseUrl | quote }}
- name: LOG_DIR
  value: {{ .Values.workflow.logging.dir | quote }}
- name: LOG_MAX_HISTORY_DAYS
  value: {{ .Values.workflow.logging.maxHistoryDays | quote }}
- name: LOG_FILE_MAX_SIZE
  value: {{ .Values.workflow.logging.fileMaxSize | quote }}
- name: LOG_TOTAL_SIZE_CAP
  value: {{ .Values.workflow.logging.totalSizeCap | quote }}
- name: LOG_NACOS_LEVEL
  value: {{ .Values.workflow.logging.nacosLevel | quote }}
- name: LOGGING_LEVEL_ROOT
  value: {{ .Values.workflow.logging.rootLevel | quote }}
- name: INVOKE_TIMEOUT_CONSOLE
  value: {{ .Values.workflow.invokeTimeouts.console | quote }}
- name: INVOKE_TIMEOUT_CONSOLE_ASYNC
  value: {{ .Values.workflow.invokeTimeouts.consoleAsync | quote }}
- name: INVOKE_TIMEOUT_API
  value: {{ .Values.workflow.invokeTimeouts.api | quote }}
- name: INVOKE_TIMEOUT_API_ASYNC
  value: {{ .Values.workflow.invokeTimeouts.apiAsync | quote }}
- name: AGENTSCOPE_WORKFLOW_MAXNODERESULTBYTES
  value: {{ .Values.workflow.sizeLimits.maxNodeResultBytes | quote }}
- name: AGENTSCOPE_WORKFLOW_MAXCONTEXTBYTES
  value: {{ .Values.workflow.sizeLimits.maxContextBytes | quote }}
- name: AGENTSCOPE_WORKFLOW_MAXLOOPCUMULATIVEBYTES
  value: {{ .Values.workflow.sizeLimits.maxLoopCumulativeBytes | quote }}
- name: AGENTSCOPE_WORKFLOW_CONTEXTDEBUGFIELDMAXBYTES
  value: {{ .Values.workflow.sizeLimits.contextDebugFieldMaxBytes | quote }}
- name: AGENTSCOPE_WORKFLOW_MAXPARALLELBATCHSIZE
  value: {{ .Values.workflow.sizeLimits.maxParallelBatchSize | quote }}
- name: AGENTSCOPE_WORKFLOW_TASK_POOL_CORE
  value: {{ .Values.workflow.threadPools.task.core | quote }}
- name: AGENTSCOPE_WORKFLOW_TASK_POOL_MAX
  value: {{ .Values.workflow.threadPools.task.max | quote }}
- name: AGENTSCOPE_WORKFLOW_TASK_POOL_QUEUE
  value: {{ .Values.workflow.threadPools.task.queue | quote }}
- name: AGENTSCOPE_WORKFLOW_MONITOR_POOL_CORE
  value: {{ .Values.workflow.threadPools.monitor.core | quote }}
- name: AGENTSCOPE_WORKFLOW_MONITOR_POOL_MAX
  value: {{ .Values.workflow.threadPools.monitor.max | quote }}
- name: AGENTSCOPE_WORKFLOW_MONITOR_POOL_QUEUE
  value: {{ .Values.workflow.threadPools.monitor.queue | quote }}
- name: AGENTSCOPE_WORKFLOW_PARALLEL_POOL_CORE
  value: {{ .Values.workflow.threadPools.parallel.core | quote }}
- name: AGENTSCOPE_WORKFLOW_PARALLEL_POOL_MAX
  value: {{ .Values.workflow.threadPools.parallel.max | quote }}
- name: AGENTSCOPE_WORKFLOW_PARALLEL_POOL_QUEUE
  value: {{ .Values.workflow.threadPools.parallel.queue | quote }}
- name: AGENTSCOPE_WORKFLOW_NODE_POOL_CORE
  value: {{ .Values.workflow.threadPools.node.core | quote }}
- name: AGENTSCOPE_WORKFLOW_NODE_POOL_MAX
  value: {{ .Values.workflow.threadPools.node.max | quote }}
- name: AGENTSCOPE_WORKFLOW_NODE_POOL_QUEUE
  value: {{ .Values.workflow.threadPools.node.queue | quote }}
- name: AGENTSCOPE_WORKFLOW_NODE_SUBMIT_RETRY_ATTEMPTS
  value: {{ .Values.workflow.nodeSubmitRetry.attempts | quote }}
- name: AGENTSCOPE_WORKFLOW_NODE_SUBMIT_RETRY_INTERVAL_MS
  value: {{ .Values.workflow.nodeSubmitRetry.intervalMs | quote }}
- name: AGENTSCOPE_SETTINGS_FILE_PARSE_TIMEOUT
  value: {{ .Values.workflow.fileParse.parseTimeoutSeconds | quote }}
- name: DEFAULT_MAX_PARSE_LENGTH
  value: {{ .Values.workflow.fileParse.defaultMaxParseLength | quote }}
- name: FILE_UPLOAD_SIZE_LIMIT
  value: {{ .Values.workflow.fileUploadSizeLimit | quote }}
- name: AGENTSCOPE_MARKDOWN_RENDER_MAX_CHARS
  value: {{ .Values.workflow.markdownRenderMaxChars | quote }}
- name: AGENTSCOPE_MARKDOWN_RENDER_MAX_IMAGE_BYTES
  value: {{ .Values.workflow.markdownRenderMaxImageBytes | quote }}
- name: AGENTSCOPE_MARKDOWN_RENDER_IMAGE_SPILL_BYTES
  value: {{ .Values.workflow.markdownRenderImageSpillBytes | quote }}
- name: DOC_SPLIT_MAX_OUTPUT_FILES_AUTO
  value: {{ .Values.workflow.documentSplit.maxOutputFilesAuto | quote }}
- name: DOC_SPLIT_MAX_OUTPUT_FILES_MANUAL
  value: {{ .Values.workflow.documentSplit.maxOutputFilesManual | quote }}
- name: MODEL_LVM_BASE_PROVIDER
  value: {{ .Values.workflow.lvmBase.provider | quote }}
- name: MODEL_LVM_MODEL_ID
  value: {{ .Values.workflow.lvmBase.modelId | quote }}
- name: MODEL_LLM_BASE_PROVIDER
  value: {{ .Values.workflow.llmBase.provider | quote }}
- name: MODEL_LLM_MODEL_ID
  value: {{ .Values.workflow.llmBase.modelId | quote }}
- name: APP_NAME
  value: {{ .Values.workflow.appName | quote }}
- name: WORKFLOW_SCRIPT_CLUSTER_HOST
  value: {{ .Values.workflow.scriptCluster.host | quote }}
- name: WORKFLOW_SCRIPT_CLUSTER_FORWARD_TIMEOUT_MS
  value: {{ .Values.workflow.scriptCluster.forwardTimeoutMs | quote }}
- name: WORKFLOW_SCRIPT_NODE_ENABLED
  value: {{ .Values.workflow.scriptNode.enabled | quote }}
- name: WORKFLOW_SCRIPT_NODE_MAX_CONCURRENCY
  value: {{ .Values.workflow.scriptNode.maxConcurrency | quote }}
- name: WORKFLOW_SCRIPT_NODE_ACQUIRE_TIMEOUT_MS
  value: {{ .Values.workflow.scriptNode.acquireTimeoutMs | quote }}
- name: WORKFLOW_SCRIPT_FORBIDDEN_LIB_ENABLED
  value: {{ .Values.workflow.scriptSecurity.forbiddenLib.enabled | quote }}
- name: WORKFLOW_SCRIPT_FORBIDDEN_LIB_MAX_CONTENT_BYTES
  value: {{ .Values.workflow.scriptSecurity.forbiddenLib.maxContentBytes | quote }}
- name: WORKFLOW_SCRIPT_FORBIDDEN_PYTHON_LIBS
  value: {{ .Values.workflow.scriptSecurity.forbiddenLib.pythonLibs | quote }}
- name: WORKFLOW_SCRIPT_FORBIDDEN_JAVASCRIPT_LIBS
  value: {{ .Values.workflow.scriptSecurity.forbiddenLib.javascriptLibs | quote }}
- name: PYTHON_USE_EXTERNAL_PYTHON
  value: {{ .Values.workflow.python.useExternalPython | quote }}
- name: PYTHON_EXECUTABLE
  value: {{ .Values.workflow.python.executable | quote }}
- name: PYTHON_EXECUTION_TIMEOUT
  value: {{ .Values.workflow.python.executionTimeout | quote }}
- name: PYTHON_TEMP_DIR
  value: {{ .Values.workflow.python.tempDir | quote }}
- name: MCP_CONNECT_TIMEOUT
  value: {{ .Values.workflow.mcp.connectTimeoutSeconds | quote }}
- name: MCP_REQUEST_TIMEOUT_MS
  value: {{ .Values.workflow.mcp.requestTimeoutMs | quote }}
- name: MCP_INITIALIZATION_TIMEOUT
  value: {{ .Values.workflow.mcp.initializationTimeoutSeconds | quote }}
- name: MCP_GET_TOOLS_TIMEOUT
  value: {{ .Values.workflow.mcp.getToolsTimeoutSeconds | quote }}
- name: AIBAAS_SANDBOX_REMOTE_ENABLED
  value: {{ .Values.workflow.sandbox.remote.enabled | quote }}
- name: AIBAAS_SANDBOX_REMOTE_ENDPOINT
  value: {{ .Values.workflow.sandbox.remote.endpoint | quote }}
- name: AIBAAS_SANDBOX_REMOTE_TIMEOUT_S
  value: {{ .Values.workflow.sandbox.remote.timeoutSeconds | quote }}
{{- include "bailian.env.postgres" . | nindent 0 }}
{{- include "bailian.env.redis" . | nindent 0 }}
{{- include "bailian.env.elasticsearch" . | nindent 0 }}
- name: ROCKETMQ_ENDPOINTS
  value: ""
{{- include "bailian.env.oss" (dict "oss" .Values.workflow.oss "fullname" (include "bailian.fullname" .)) | nindent 0 }}
- name: OSS_ENDPOINT
  value: {{ .Values.workflow.oss.endpoint | quote }}
- name: OSS_INTERNAL_ENDPOINT
  value: {{ .Values.workflow.oss.internalEndpoint | quote }}
- name: OSS_ACCESS_KEY_ID
  valueFrom:
    secretKeyRef:
      name: {{ include "bailian.fullname" . }}-secrets
      key: OSS_ACCESS_KEY_ID
- name: OSS_ACCESS_KEY_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ include "bailian.fullname" . }}-secrets
      key: OSS_ACCESS_KEY_SECRET
- name: OSS_BUCKET
  value: {{ .Values.workflow.oss.bucket | quote }}
- name: OSS_REGION
  value: {{ .Values.workflow.oss.region | quote }}
- name: OSS_PROTOCOL
  value: {{ .Values.workflow.oss.protocol | quote }}
- name: OSS_DOWNLOAD_URL
  value: {{ .Values.workflow.oss.downloadUrl | quote }}
- name: AGENTSCOPE_UPLOAD_METHOD
  value: {{ .Values.workflow.uploadMethod | quote }}
- name: AUDIO_PARSE_APP_ID
  value: {{ .Values.workflow.audioParse.appId | quote }}
- name: AUDIO_PARSE_APP_SECRET
  value: {{ .Values.workflow.audioParse.appSecret | quote }}
- name: AUDIO_PARSE_ACCESS_KEY
  value: {{ .Values.workflow.audioParse.accessKey | quote }}
- name: AUDIO_PARSE_P9USD_BUS_TYPE
  value: {{ .Values.workflow.audioParse.busType | quote }}
- name: AUDIO_PARSE_P9USD_SYS_KEY
  value: {{ .Values.workflow.audioParse.sysKey | quote }}
- name: AUDIO_PARSE_DYNAMIC_PASSWORD_URL
  value: {{ .Values.workflow.audioParse.dynamicPasswordUrl | quote }}
- name: AUDIO_PARSE_CONVERT_URL
  value: {{ .Values.workflow.audioParse.convertUrl | quote }}
- name: AUDIO_PARSE_QUERY_URL
  value: {{ .Values.workflow.audioParse.queryUrl | quote }}
- name: AUDIO_PARSE_SCENE
  value: {{ .Values.workflow.audioParse.scene | quote }}
- name: AUDIO_PARSE_MAX_CONCURRENT
  value: {{ .Values.workflow.audioParse.maxConcurrent | quote }}
- name: AUDIO_PARSE_CONCURRENCY_WAIT_SECONDS
  value: {{ .Values.workflow.audioParse.concurrencyWaitSeconds | quote }}
- name: AUDIO_PARSE_CONCURRENCY_LEASE_SECONDS
  value: {{ .Values.workflow.audioParse.concurrencyLeaseSeconds | quote }}
- name: AUDIO_PARSE_POLL_INTERVAL_MS
  value: {{ .Values.workflow.audioParse.pollIntervalMs | quote }}
- name: AUDIO_PARSE_POLL_TIMEOUT_MS
  value: {{ .Values.workflow.audioParse.pollTimeoutMs | quote }}
- name: KNOWLEDGE_APP_KEY
  value: {{ .Values.workflow.knowledge.appKey | quote }}
- name: KNOWLEDGE_RMRK
  value: {{ .Values.workflow.knowledge.rmrk | quote }}
- name: KNOWLEDGE_LOCAL
  value: {{ .Values.workflow.knowledge.local | quote }}
- name: KNOWLEDGE_ATTRDATA_URL
  value: {{ .Values.workflow.knowledge.attrData.url | quote }}
- name: KNOWLEDGE_ATTRDATA_GROUP
  value: {{ .Values.workflow.knowledge.attrData.group | quote }}
- name: KNOWLEDGE_ATTRDATA_APP_ID
  value: {{ .Values.workflow.knowledge.attrData.appId | quote }}
- name: KNOWLEDGE_ATTRDATA_RMRK
  value: {{ .Values.workflow.knowledge.attrData.rmrk | quote }}
- name: KNOWLEDGE_ATTRDATA_TPCD
  value: {{ .Values.workflow.knowledge.attrData.tpcd | quote }}
- name: KNOWLEDGE_TREE_URL
  value: {{ .Values.workflow.knowledge.tree.url | quote }}
- name: KNOWLEDGE_RETRIEVAL_URL
  value: {{ .Values.workflow.knowledge.retrieval.url | quote }}
- name: KNOWLEDGE_RAG_MODEL
  value: {{ .Values.workflow.knowledge.rag.model | quote }}
- name: KNOWLEDGE_RAG_URL
  value: {{ .Values.workflow.knowledge.rag.url | quote }}
- name: KNOWLEDGE_RAG_TX_CODE
  value: {{ .Values.workflow.knowledge.rag.txCode | quote }}
- name: KNOWLEDGE_RAG_SEC_NODE_NO
  value: {{ .Values.workflow.knowledge.rag.secNodeNo | quote }}
- name: KNOWLEDGE_RAG_TX_SERIAL_NO
  value: {{ .Values.workflow.knowledge.rag.txSerialNo | quote }}
- name: KNOWLEDGE_KN11_URL
  value: {{ .Values.workflow.knowledge.kn11.url | quote }}
- name: KNOWLEDGE_KN11_HOST
  value: {{ .Values.workflow.knowledge.kn11.host | quote }}
- name: KNOWLEDGE_KN11_APP_KEY
  value: {{ .Values.workflow.knowledge.kn11.appKey | quote }}
- name: KNOWLEDGE_KN11_SCENE_ID
  value: {{ .Values.workflow.knowledge.kn11.sceneId | quote }}
- name: KNOWLEDGE_DEFAULT_SOURCE_SYSTEMS
  value: {{ .Values.workflow.knowledge.defaultSourceSystems | quote }}
- name: KNOWLEDGE_LEGAL_NO_URL
  value: {{ .Values.workflow.knowledge.legalNo.url | quote }}
- name: KNOWLEDGE_LEGAL_NO_HOST
  value: {{ .Values.workflow.knowledge.legalNo.host | quote }}
- name: KNOWLEDGE_EMP_INFO_URL
  value: {{ .Values.workflow.knowledge.empInfo.url | quote }}
- name: P9USD_UPLOAD
  value: {{ .Values.workflow.p9usd.upload | quote }}
- name: P9USD_DOWNLOAD
  value: {{ .Values.workflow.p9usd.download | quote }}
- name: P9USD_PATH
  value: {{ .Values.workflow.p9usd.path | quote }}
- name: ICR_PARSE_CALL_TOOL_URL
  value: {{ .Values.workflow.icrParse.callToolUrl | quote }}
- name: ICR_PARSE_TOOL_NAME
  value: {{ .Values.workflow.icrParse.toolName | quote }}
- name: ICR_PARSE_P9USD_BUS_TYPE
  value: {{ .Values.workflow.icrParse.busType | quote }}
- name: ICR_PARSE_P9USD_SYS_KEY
  value: {{ .Values.workflow.icrParse.sysKey | quote }}
- name: ICR_PARSE_MAX_FILE_BYTES
  value: {{ .Values.workflow.icrParse.maxFileBytes | quote }}
- name: ICR_PARSE_MAX_PAGES
  value: {{ .Values.workflow.icrParse.maxPages | quote }}
- name: ICR_PARSE_CONN_TIME_OUT
  value: {{ .Values.workflow.icrParse.connTimeOut | quote }}
- name: ICR_PARSE_FALLBACK_MIN_CHARS_PER_PAGE
  value: {{ .Values.workflow.icrParse.fallbackMinCharsPerPage | quote }}
- name: EMAIL_BASE_URL
  value: {{ .Values.workflow.email.baseUrl | quote }}
- name: EMAIL_SUBSIDIARY_BASE_URL
  value: {{ .Values.workflow.email.subsidiaryBaseUrl | quote }}
- name: EMAIL_OVERSEAS_BASE_URL
  value: {{ .Values.workflow.email.overseasBaseUrl | quote }}
- name: EMAIL_STUDIO_USER_INFO_URL
  value: {{ .Values.workflow.email.studioUserInfoUrl | quote }}
- name: EMAIL_INBOX_FOLDER_ID
  value: {{ .Values.workflow.email.inboxFolderId | quote }}
- name: EMAIL_DOMAIN
  value: {{ .Values.workflow.email.domain | quote }}
- name: EMAIL_TEMP_FILE_PATH
  value: {{ .Values.workflow.email.tempFilePath | quote }}
- name: EMAIL_API_KEY
  value: {{ .Values.workflow.email.apiKey | quote }}
- name: EMAIL_API_SECRET
  value: {{ .Values.workflow.email.apiSecret | quote }}
- name: EMAIL_SUBSIDIARY_API_KEY
  value: {{ .Values.workflow.email.subsidiaryApiKey | quote }}
- name: EMAIL_SUBSIDIARY_API_SECRET
  value: {{ .Values.workflow.email.subsidiaryApiSecret | quote }}
- name: EMAIL_OVERSEAS_API_KEY
  value: {{ .Values.workflow.email.overseasApiKey | quote }}
- name: EMAIL_OVERSEAS_API_SECRET
  value: {{ .Values.workflow.email.overseasApiSecret | quote }}
- name: EMAIL_PERMITS_PER_SECOND
  value: {{ .Values.workflow.email.permitsPerSecond | quote }}
- name: EMAIL_WAIT_TIME
  value: {{ .Values.workflow.email.waitTime | quote }}
- name: EMAIL_MAX_ATTACHMENT_BYTES
  value: {{ .Values.workflow.email.maxAttachmentBytes | quote }}
- name: EMAIL_MAX_ATTACHMENT_TOTAL_BYTES
  value: {{ .Values.workflow.email.maxAttachmentTotalBytes | quote }}
- name: EMAIL_MAX_ATTACHMENT_VARIABLES
  value: {{ .Values.workflow.email.maxAttachmentVariables | quote }}
- name: TRUSTED_URL
  value: {{ .Values.workflow.trusted.url | quote }}
- name: TRUSTED_APP_ID
  value: {{ .Values.workflow.trusted.appId | quote }}
- name: TRUSTED_ACS_ID
  value: {{ .Values.workflow.trusted.acsId | quote }}
- name: TRUSTED_ACS_KEY
  value: {{ .Values.workflow.trusted.acsKey | quote }}
- name: INNER_RAG_BASE_URL
  value: {{ .Values.workflow.innerRagBaseUrl | default (ternary (printf "http://rag:%v" (int .Values.rag.port)) "" .Values.rag.enabled) | quote }}
- name: INNER_AGENT_BASE_URL
  value: {{ .Values.workflow.innerAgentBaseUrl | default (printf "http://agentscope-protocol:%v" (int .Values.protocol.port)) | quote }}
{{/* AGENT_ROUTER_*：组件(应用组件作为工作流节点)执行时 AgentAPIManager 需路由到 platform-api；
     与 infrastructure 一致从 aibaas-config 读取，否则回退 protocol 导致 Agent 组件失败 */}}
- name: AGENT_ROUTER_TARGET
  valueFrom:
    configMapKeyRef:
      name: {{ include "bailian.fullname" . }}-aibaas-config
      key: AGENT_ROUTER_TARGET
      optional: true
- name: PLATFORM_API_BASE_URL
  valueFrom:
    configMapKeyRef:
      name: {{ include "bailian.fullname" . }}-aibaas-config
      key: PLATFORM_API_BASE_URL
      optional: true
- name: AGENT_ROUTER_AGENT_ID
  valueFrom:
    configMapKeyRef:
      name: {{ include "bailian.fullname" . }}-aibaas-config
      key: AGENT_ROUTER_AGENT_ID
      optional: true
- name: AGENT_ROUTER_TENANT_ID
  valueFrom:
    configMapKeyRef:
      name: {{ include "bailian.fullname" . }}-aibaas-config
      key: AGENT_ROUTER_TENANT_ID
      optional: true
- name: INNER_MCP_LOCALSERVER
  value: {{ .Values.workflow.innerMcpLocalServer | default (printf "http://platform-infrastructure.%s.svc.cluster.local:%v" .Release.Namespace (int .Values.infrastructure.port)) | quote }}
- name: INNER_INFRA_BASE_URL
  value: {{ printf "http://platform-infrastructure.%s.svc.cluster.local:%v" .Release.Namespace (int .Values.infrastructure.port) | quote }}
- name: INNER_INFRASTRUCTURE_BASE_URL
  value: {{ printf "http://platform-infrastructure.%s.svc.cluster.local:%v" .Release.Namespace (int .Values.infrastructure.port) | quote }}
{{- include "bailian.env.tracing.workflow" . | nindent 0 }}
{{- end }}

{{/* ================================================================
     PostgreSQL helpers
     ================================================================ */}}

{{/*
Env block: EXTERNAL_PG_* for Java services (console, infrastructure, workflow).
Usage: {{ include "bailian.env.postgres" . | nindent 12 }}
*/}}
{{- define "bailian.env.postgres" -}}
- name: EXTERNAL_PG_HOST
  {{- if and (not .Values.postgres.enabled) .Values.externalPostgresql .Values.externalPostgresql.host }}
  value: {{ .Values.externalPostgresql.host | quote }}
  {{- else }}
  value: postgres
  {{- end }}
- name: EXTERNAL_PG_PORT
  {{- if and (not .Values.postgres.enabled) .Values.externalPostgresql .Values.externalPostgresql.port }}
  value: {{ .Values.externalPostgresql.port | quote }}
  {{- else }}
  value: {{ .Values.postgres.port | quote }}
  {{- end }}
- name: EXTERNAL_PG_DATABASE
  value: agentscope
- name: EXTERNAL_PG_USERNAME
  valueFrom:
    secretKeyRef:
      name: {{ include "bailian.fullname" . }}-secrets
      key: POSTGRES_USER
- name: EXTERNAL_PG_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "bailian.fullname" . }}-secrets
      key: POSTGRES_PASSWORD
{{- end }}

{{/* ================================================================
     Redis helpers
     ================================================================ */}}

{{/*
Env block: EXTERNAL_REDIS_* for Java services (console, infrastructure, workflow).
Usage: {{ include "bailian.env.redis" . | nindent 12 }}
*/}}
{{- define "bailian.env.redis" -}}
{{- $redisMode := .Values.externalRedis.mode | default "standalone" -}}
{{- if not (has $redisMode (list "standalone" "cluster")) -}}
{{- fail "externalRedis.mode must be standalone or cluster" -}}
{{- end -}}
{{- if and (not .Values.redis.enabled) (eq $redisMode "cluster") -}}
{{- $_ := required "externalRedis.host is required when externalRedis.mode=cluster" .Values.externalRedis.host -}}
{{- $_ := required "externalRedis.cluster.nodes is required when externalRedis.mode=cluster" .Values.externalRedis.cluster.nodes -}}
{{- end -}}
- name: EXTERNAL_REDIS_MODE
  {{- if not .Values.redis.enabled }}
  value: {{ .Values.externalRedis.mode | default "standalone" | quote }}
  {{- else }}
  value: "standalone"
  {{- end }}
- name: EXTERNAL_REDIS_HOST
  {{- if and (not .Values.redis.enabled) .Values.externalRedis .Values.externalRedis.host }}
  value: {{ .Values.externalRedis.host | quote }}
  {{- else }}
  value: redis
  {{- end }}
- name: EXTERNAL_REDIS_PORT
  {{- if and (not .Values.redis.enabled) .Values.externalRedis .Values.externalRedis.port }}
  value: {{ .Values.externalRedis.port | quote }}
  {{- else }}
  value: {{ .Values.redis.port | quote }}
  {{- end }}
- name: EXTERNAL_REDIS_DATABASE
  {{- if and (not .Values.redis.enabled) (eq (.Values.externalRedis.mode | default "standalone") "cluster") }}
  value: "0"
  {{- else if and (not .Values.redis.enabled) .Values.externalRedis }}
  value: {{ .Values.externalRedis.db | default 0 | quote }}
  {{- else }}
  value: {{ .Values.redis.db | default 0 | quote }}
  {{- end }}
- name: EXTERNAL_REDIS_USERNAME
  value: ""
- name: EXTERNAL_REDIS_CLUSTER_NODES
  {{- if not .Values.redis.enabled }}
  value: {{ .Values.externalRedis.cluster.nodes | default "" | quote }}
  {{- else }}
  value: ""
  {{- end }}
- name: EXTERNAL_REDIS_CLUSTER_SCAN_INTERVAL
  {{- if not .Values.redis.enabled }}
  value: {{ .Values.externalRedis.cluster.scanInterval | default 2000 | quote }}
  {{- else }}
  value: "2000"
  {{- end }}
- name: EXTERNAL_REDIS_CLUSTER_MAX_REDIRECTS
  {{- if not .Values.redis.enabled }}
  value: {{ .Values.externalRedis.cluster.maxRedirects | default 3 | quote }}
  {{- else }}
  value: "3"
  {{- end }}
- name: EXTERNAL_REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "bailian.fullname" . }}-secrets
      key: REDIS_PASSWORD
{{- end }}

{{/*
Env block: AGENT_SETTINGS_REDIS_* for Python protocol (rate limit / session).
Usage: {{ include "bailian.env.redis.protocol" . | nindent 12 }}
*/}}
{{- define "bailian.env.redis.protocol" -}}
- name: AGENT_SETTINGS_REDIS_HOST
  {{- if and (not .Values.redis.enabled) .Values.externalRedis .Values.externalRedis.host }}
  value: {{ .Values.externalRedis.host | quote }}
  {{- else }}
  value: redis
  {{- end }}
- name: AGENT_SETTINGS_REDIS_PORT
  {{- if and (not .Values.redis.enabled) .Values.externalRedis .Values.externalRedis.port }}
  value: {{ .Values.externalRedis.port | quote }}
  {{- else }}
  value: {{ .Values.redis.port | quote }}
  {{- end }}
- name: AGENT_SETTINGS_REDIS_DB
  {{- if and (not .Values.redis.enabled) .Values.externalRedis }}
  value: {{ .Values.externalRedis.db | default 0 | quote }}
  {{- else }}
  value: {{ .Values.redis.db | default 0 | quote }}
  {{- end }}
- name: AGENT_SETTINGS_REDIS_USERNAME
  value: {{ .Values.protocol.settings.redisUsername | default "" | quote }}
- name: AGENT_SETTINGS_REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "bailian.fullname" . }}-secrets
      key: REDIS_PASSWORD
- name: AGENT_SETTINGS_REDIS_MAX_CONNECTIONS
  value: {{ .Values.protocol.settings.redisMaxConnections | default 20 | quote }}
- name: AGENT_SETTINGS_REDIS_SOCKET_KEEPALIVE
  value: {{ .Values.protocol.settings.redisSocketKeepalive | default true | quote }}
- name: AGENT_SETTINGS_REDIS_SOCKET_TIMEOUT
  value: {{ .Values.protocol.settings.redisSocketTimeout | default 5.0 | quote }}
{{- end }}

{{/* ================================================================
     OSS helpers
     ================================================================ */}}

{{/*
Env block: AGENTSCOPE_OSS_* for Java services.
Accepts a dict with "oss" (the component's .Values.<comp>.oss) and "fullname".
Usage: {{ include "bailian.env.oss" (dict "oss" .Values.workflow.oss "fullname" (include "bailian.fullname" .)) | nindent 12 }}
*/}}
{{- define "bailian.env.oss" -}}
- name: AGENTSCOPE_OSS_ENDPOINT
  value: {{ .oss.endpoint | quote }}
- name: AGENTSCOPE_OSS_INTERNALENDPOINT
  value: {{ .oss.internalEndpoint | quote }}
- name: AGENTSCOPE_OSS_REGION
  value: {{ .oss.region | default "" | quote }}
- name: AGENTSCOPE_OSS_PROTOCOL
  value: {{ .oss.protocol | default "" | quote }}
- name: AGENTSCOPE_OSS_ACCESSKEYID
  valueFrom:
    secretKeyRef:
      name: {{ .fullname }}-secrets
      key: OSS_ACCESS_KEY_ID
- name: AGENTSCOPE_OSS_ACCESSKEYSECRET
  valueFrom:
    secretKeyRef:
      name: {{ .fullname }}-secrets
      key: OSS_ACCESS_KEY_SECRET
- name: AGENTSCOPE_OSS_BUCKET
  value: {{ .oss.bucket | quote }}
- name: AGENTSCOPE_OSS_TYPE
  value: {{ .oss.type | quote }}
{{- end }}

{{/*
Shared application log volume.
One ReadWriteMany PVC (or hostPath in localMode). Each service mounts a
subdirectory with subPath so files land in <service>/ on the volume.
Usage: {{ include "bailian.logs.volume" . | nindent 8 }}
*/}}
{{- define "bailian.logs.volume" -}}
- name: service-logs
  {{- if .Values.global.localMode }}
  hostPath:
    path: {{ .Values.global.logStorage.hostPath | quote }}
    type: DirectoryOrCreate
  {{- else }}
  persistentVolumeClaim:
    claimName: {{ include "bailian.fullname" . }}-logs
  {{- end }}
{{- end }}

{{/*
Usage: {{ include "bailian.logs.volumeMount" (dict "mountPath" "/app/logs" "subPath" "console") | nindent 12 }}
*/}}
{{- define "bailian.logs.volumeMount" -}}
- name: service-logs
  mountPath: {{ .mountPath | quote }}
  subPath: {{ .subPath | quote }}
{{- end }}

{{/*
subPath is created as root:root 0755, and fsGroup is not applied to subPath mounts.
chmod the service directory so non-root processes (protocol/rag uid 1501, kong uid 1001) can write.
Usage: {{ include "bailian.logs.initContainer" (dict "root" . "subPath" "console" "mountPath" "/app/logs") | nindent 8 }}
*/}}
{{- define "bailian.logs.initContainer" -}}
- name: init-log-dir
  image: "{{ include "bailian.registry" .root }}{{ .root.Values.global.utilImages.busybox }}"
  imagePullPolicy: {{ .root.Values.global.imagePullPolicy }}
  securityContext:
    runAsUser: 0
  command: ["sh", "-c", "chmod 777 {{ .mountPath }}"]
  volumeMounts:
    - name: service-logs
      mountPath: {{ .mountPath | quote }}
      subPath: {{ .subPath | quote }}
{{- end }}

{{/* ================================================================
     InitContainer helpers
     ================================================================ */}}

{{/*
InitContainer: wait-for-postgres.
Usage: {{ include "bailian.initContainer.waitForPostgres" . | nindent 8 }}
*/}}
{{- define "bailian.initContainer.waitForPostgres" -}}
- name: wait-for-postgres
  image: "{{ include "bailian.registry" . }}{{ .Values.postgres.image.repository }}:{{ .Values.postgres.image.tag }}"
  command:
    - sh
    - -c
    - |
      {{- if and (not .Values.postgres.enabled) .Values.externalPostgresql .Values.externalPostgresql.host }}
      PG_HOST="{{ .Values.externalPostgresql.host }}"
      PG_PORT="{{ .Values.externalPostgresql.port | default 5432 }}"
      {{- else }}
      PG_HOST="postgres"
      PG_PORT="{{ .Values.postgres.port }}"
      {{- end }}
      # 必须带 -U：postgres 镜像里空 PGUSER 会导致 pg_isready 报 "no attempt" 且永不成功
      PG_USER="{{ .Values.secrets.postgres.user | default "bailian" }}"
      echo "Waiting for PostgreSQL at ${PG_HOST}:${PG_PORT} (user=${PG_USER})..."
      until pg_isready -h "${PG_HOST}" -p "${PG_PORT}" -U "${PG_USER}"; do sleep 3; done
      echo "PostgreSQL ready"
{{- end }}

{{/*
InitContainer: wait-for-temporal。
Temporal 是工作流的唯一执行后端，TemporalWorkflowLauncher 在 @PostConstruct 即建连，
故 web / worker 两个 Pod 均需等 Temporal Server 就绪后再启动，否则容器会启动失败。
Usage: {{ include "bailian.initContainer.waitForTemporal" . | nindent 8 }}
*/}}
{{- define "bailian.initContainer.waitForTemporal" -}}
- name: wait-for-temporal
  image: "{{ include "bailian.registry" . }}{{ .Values.temporal.image.repository }}:{{ .Values.temporal.image.tag }}"
  command:
    - sh
    - -c
    - |
      ADDR="{{ .Values.workflow.temporal.serverAddress }}"
      TEMPORAL_HOST="${ADDR%%:*}"
      TEMPORAL_PORT="${ADDR##*:}"
      echo "Waiting for Temporal Server at ${TEMPORAL_HOST}:${TEMPORAL_PORT}..."
      until nc -z "${TEMPORAL_HOST}" "${TEMPORAL_PORT}"; do sleep 3; done
      echo "Temporal Server ready"
{{- end }}

{{/*
InitContainer: wait-for-redis.
Usage: {{ include "bailian.initContainer.waitForRedis" . | nindent 8 }}
*/}}
{{- define "bailian.initContainer.waitForRedis" -}}
- name: wait-for-redis
  image: "{{ include "bailian.registry" . }}{{ .Values.redis.image.repository }}:{{ .Values.redis.image.tag }}"
  command:
    - sh
    - -c
    - |
      {{- if and (not .Values.redis.enabled) .Values.externalRedis .Values.externalRedis.host }}
      REDIS_HOST="{{ .Values.externalRedis.host }}"
      REDIS_PORT="{{ .Values.externalRedis.port | default 6379 }}"
      {{- else }}
      REDIS_HOST="redis"
      REDIS_PORT="{{ .Values.redis.port }}"
      {{- end }}
      echo "Waiting for Redis at ${REDIS_HOST}:${REDIS_PORT}..."
      {{- if and (not .Values.redis.enabled) (eq (.Values.externalRedis.mode | default "standalone") "cluster") }}
      until redis-cli -c -h "${REDIS_HOST}" -p "${REDIS_PORT}" -a "$REDIS_PASSWORD" ping | grep -q PONG; do sleep 3; done
      {{- else }}
      until redis-cli -h "${REDIS_HOST}" -p "${REDIS_PORT}" -a "$REDIS_PASSWORD" ping | grep -q PONG; do sleep 3; done
      {{- end }}
      echo "Redis ready"
  env:
    - name: REDIS_PASSWORD
      valueFrom:
        secretKeyRef:
          name: {{ include "bailian.fullname" . }}-secrets
          key: REDIS_PASSWORD
{{- end }}

{{/*
AIBaaS AgentSpec extraEnv：仅注入 aibaas.agent.extraEnv 中的非空值。
*/}}
{{- define "bailian.aibaasExtraEnvJsonSuffix" -}}
{{- range $k, $v := .Values.aibaas.agent.extraEnv }}
{{- if and $v (ne (printf "%v" $v) "") -}}
,{{ $k | toJson }}:{{ $v | toJson }}
{{- end }}
{{- end }}
{{- end }}

{{- define "bailian.aibaasExtraEnvPrettySuffix" -}}
{{- range $k, $v := .Values.aibaas.agent.extraEnv }}
{{- if and $v (ne (printf "%v" $v) "") -}}
,
                    {{ $k | toJson }}: {{ $v | toJson }}
{{- end }}
{{- end }}
{{- end }}

{{/*
AIBaaS AgentSpec deployment 整段 JSON（CREATE/PATCH 共用）。
合并规则与 bailian.scheduling 一致：map=mergeOverwrite(global, agent)，tolerations=concat。
tolerations 空 list 强制为 []，避免 concat+toJson 变成 null。
*/}}
{{- define "bailian.aibaasAgentDeploymentJson" -}}
{{- $agent := .Values.aibaas.agent | default dict -}}
{{- $nsG := .Values.global.nodeSelector | default dict -}}
{{- $nsL := $agent.nodeSelector | default dict -}}
{{- if not (kindIs "map" $nsG) }}{{- $nsG = dict -}}{{- end -}}
{{- if not (kindIs "map" $nsL) }}{{- $nsL = dict -}}{{- end -}}
{{- $ns := mergeOverwrite (deepCopy $nsG) $nsL -}}
{{- $afG := .Values.global.affinity | default dict -}}
{{- $afL := $agent.affinity | default dict -}}
{{- if not (kindIs "map" $afG) }}{{- $afG = dict -}}{{- end -}}
{{- if not (kindIs "map" $afL) }}{{- $afL = dict -}}{{- end -}}
{{- $af := mergeOverwrite (deepCopy $afG) $afL -}}
{{- $tolG := .Values.global.tolerations | default list -}}
{{- $tolL := $agent.tolerations | default list -}}
{{- if not (kindIs "slice" $tolG) }}{{- $tolG = list -}}{{- end -}}
{{- if not (kindIs "slice" $tolL) }}{{- $tolL = list -}}{{- end -}}
{{- $tol := concat $tolG $tolL | default list -}}
{{- if not (kindIs "slice" $tol) }}{{- $tol = list -}}{{- end -}}
{"scheduling":{"strategy":"shared","max_sessions_per_replica":{{ .Values.aibaas.agent.execution.maxSessionsPerPod }},"node_selector":{{ $ns | toJson }},"tolerations":{{ $tol | toJson }},"affinity":{{ $af | toJson }}},"scaling":{"min_replicas":{{ .Values.aibaas.agent.pool.minSize }},"max_replicas":{{ .Values.aibaas.agent.pool.maxSize }}},"warm_pool":{"enabled":true,"idle_timeout_seconds":{{ .Values.aibaas.agent.pool.idleTimeout }}},"session_release_policy":"release_on_idle"}
{{- end }}

{{/*
Pod scheduling — aligned with agentbaas global merge.
Maps (nodeSelector / affinity): mergeOverwrite(global, component), component wins.
tolerations: concat(global, component).
Usage: {{- include "bailian.scheduling" (dict "root" . "component" .Values.console) | nindent 6 }}
*/}}
{{- define "bailian.mergeMap" -}}
{{- $g := .global | default dict -}}
{{- $l := .local | default dict -}}
{{- if not (kindIs "map" $g) }}{{- $g = dict -}}{{- end -}}
{{- if not (kindIs "map" $l) }}{{- $l = dict -}}{{- end -}}
{{- $m := mergeOverwrite (deepCopy $g) $l -}}
{{- if gt (len $m) 0 -}}
{{- toYaml $m -}}
{{- end -}}
{{- end }}

{{- define "bailian.mergeTolerations" -}}
{{- $g := .global | default list -}}
{{- $l := .local | default list -}}
{{- if not (kindIs "slice" $g) }}{{- $g = list -}}{{- end -}}
{{- if not (kindIs "slice" $l) }}{{- $l = list -}}{{- end -}}
{{- $t := concat $g $l -}}
{{- if gt (len $t) 0 -}}
{{- toYaml $t -}}
{{- end -}}
{{- end }}

{{- define "bailian.scheduling" -}}
{{- $root := .root -}}
{{- $c := .component | default dict -}}
{{- $ns := include "bailian.mergeMap" (dict "global" $root.Values.global.nodeSelector "local" $c.nodeSelector) -}}
{{- if $ns }}
nodeSelector:
  {{- nindent 2 $ns }}
{{- end }}
{{- $af := include "bailian.mergeMap" (dict "global" $root.Values.global.affinity "local" $c.affinity) -}}
{{- if $af }}
affinity:
  {{- nindent 2 $af }}
{{- end }}
{{- $tol := include "bailian.mergeTolerations" (dict "global" $root.Values.global.tolerations "local" $c.tolerations) -}}
{{- if $tol }}
tolerations:
  {{- nindent 2 $tol }}
{{- end }}
{{- end }}

