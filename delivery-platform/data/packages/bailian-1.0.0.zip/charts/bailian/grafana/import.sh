#!/usr/bin/env bash
set -euo pipefail

#
# 将 dashboards/ 目录下的大盘模板导入 Grafana。
# 在本地或 CI/CD 环境执行（集群内网络不可达 Grafana）。
#
# 用法:
#   ./import.sh \
#       --grafana-url  https://grafana-xxx.grafana.aliyuncs.com \
#       --api-key      glsa_xxxx \
#       --cluster-id   c38a665cc45ac4af3b915abd6f83e5b29 \
#       --folder-name  "Bailian / ACK-Wulanchabu"
#
# 也可通过环境变量:
#   GRAFANA_URL, GRAFANA_API_KEY, CLUSTER_ID, FOLDER_NAME
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DASHBOARD_DIR="${SCRIPT_DIR}/dashboards"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --grafana-url)  GRAFANA_URL="$2";      shift 2;;
        --api-key)      GRAFANA_API_KEY="$2";   shift 2;;
        --cluster-id)   CLUSTER_ID="$2";        shift 2;;
        --folder-name)  FOLDER_NAME="$2";       shift 2;;
        *) echo "Unknown option: $1"; exit 1;;
    esac
done

GRAFANA_URL="${GRAFANA_URL:?Error: --grafana-url or GRAFANA_URL required}"
GRAFANA_API_KEY="${GRAFANA_API_KEY:?Error: --api-key or GRAFANA_API_KEY required}"
CLUSTER_ID="${CLUSTER_ID:?Error: --cluster-id or CLUSTER_ID required}"
FOLDER_NAME="${FOLDER_NAME:-Bailian / ACK-Cluster}"

AUTH="Authorization: Bearer ${GRAFANA_API_KEY}"

echo "==> Grafana: ${GRAFANA_URL}"
echo "==> Cluster: ${CLUSTER_ID}"
echo "==> Folder:  ${FOLDER_NAME}"
echo ""

# --- 1. 创建或获取 folder ---
FOLDER_UID=$(curl -sf -H "${AUTH}" "${GRAFANA_URL}/api/folders" | \
    python3 -c "
import sys,json
for f in json.load(sys.stdin):
    if f['title']=='${FOLDER_NAME}':
        print(f['uid']); break
" 2>/dev/null || true)

if [[ -z "$FOLDER_UID" ]]; then
    echo "Creating folder: ${FOLDER_NAME}"
    FOLDER_UID=$(curl -sf -X POST -H "${AUTH}" -H "Content-Type: application/json" \
        -d "{\"title\":\"${FOLDER_NAME}\"}" \
        "${GRAFANA_URL}/api/folders" | python3 -c "import sys,json; print(json.load(sys.stdin)['uid'])")
    echo "Created folder uid: ${FOLDER_UID}"
else
    echo "Folder exists, uid: ${FOLDER_UID}"
fi
echo ""

# --- 2. 逐个导入大盘 ---
OK=0
FAIL=0

for f in "${DASHBOARD_DIR}"/*.json; do
    [[ -f "$f" ]] || continue
    BASENAME="$(basename "$f")"

    DASHBOARD_JSON=$(sed "s/\${CLUSTER_ID}/${CLUSTER_ID}/g" "$f")

    TITLE=$(echo "$DASHBOARD_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin).get('title','unknown'))")

    PAYLOAD=$(python3 -c "
import sys, json
dash = json.loads(sys.stdin.read())
dash.pop('id', None)
dash.pop('uid', None)
payload = {
    'dashboard': dash,
    'folderUid': '${FOLDER_UID}',
    'overwrite': True,
    'message': 'imported by helm/grafana/import.sh'
}
print(json.dumps(payload))
" <<< "$DASHBOARD_JSON")

    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
        -H "${AUTH}" -H "Content-Type: application/json" \
        -d "$PAYLOAD" \
        "${GRAFANA_URL}/api/dashboards/db")

    if [[ "$HTTP_CODE" == "200" ]]; then
        echo "  [OK]   ${TITLE} (${BASENAME})"
        ((OK++))
    else
        echo "  [FAIL] ${TITLE} (${BASENAME}) HTTP=${HTTP_CODE}"
        ((FAIL++))
    fi
done

echo ""
echo "==> Done. OK=${OK}, FAIL=${FAIL}"
[[ $FAIL -eq 0 ]] || exit 1
